import { createHash, randomBytes } from "crypto";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { SignJWT, jwtVerify } from "jose";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import type { SessionUser } from "@/lib/types";

const COOKIE = "mz_session";
const MAX_AGE = 60 * 60 * 24 * 14;

function secretKey() {
  const secret = process.env.AUTH_SECRET;
  if (!secret) throw new Error("AUTH_SECRET is required");
  return new TextEncoder().encode(secret);
}

export async function hashPassword(password: string): Promise<string> {
  const { hash } = await import("bcryptjs");
  return hash(password, 12);
}

export async function verifyPassword(password: string, passwordHash: string): Promise<boolean> {
  const { compare } = await import("bcryptjs");
  return compare(password, passwordHash);
}

export function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString("hex");
}

export async function createSession(user: SessionUser): Promise<string> {
  const token = randomToken();
  const expiresAt = new Date(Date.now() + MAX_AGE * 1000);
  await db.insert(sessions).values({
    userId: user.id,
    token: sha256(token),
    expiresAt,
  });
  const jwt = await new SignJWT({
    sub: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    permissions: user.permissions,
    sid: token,
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${MAX_AGE}s`)
    .sign(secretKey());

  const store = await cookies();
  store.set(COOKIE, jwt, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: MAX_AGE,
  });
  return jwt;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const jwt = store.get(COOKIE)?.value;
  if (jwt) {
    try {
      const { payload } = await jwtVerify(jwt, secretKey());
      if (typeof payload.sid === "string") {
        await db.delete(sessions).where(eq(sessions.token, sha256(payload.sid)));
      }
    } catch {
      // ignore invalid cookie
    }
  }
  store.set(COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const jwt = store.get(COOKIE)?.value;
  if (!jwt) return null;
  try {
    const { payload } = await jwtVerify(jwt, secretKey());
    if (!payload.sub || typeof payload.sid !== "string") return null;
    const [session] = await db
      .select()
      .from(sessions)
      .where(eq(sessions.token, sha256(payload.sid)))
      .limit(1);
    if (!session || session.expiresAt.getTime() < Date.now()) return null;
    const [user] = await db.select().from(users).where(eq(users.id, payload.sub)).limit(1);
    if (!user || user.status !== "active") return null;
    return {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      permissions: user.permissions || [],
    };
  } catch {
    return null;
  }
}

export function isStaff(user: SessionUser | null): boolean {
  return !!user && (user.role === "admin" || user.role === "staff");
}

export function can(user: SessionUser | null, permission: string): boolean {
  if (!user) return false;
  if (user.role === "admin") return true;
  if (user.role !== "staff") return false;
  return user.permissions.includes(permission);
}

export function toPublicUser(user: SessionUser) {
  return { id: user.id, email: user.email, name: user.name, role: user.role };
}
