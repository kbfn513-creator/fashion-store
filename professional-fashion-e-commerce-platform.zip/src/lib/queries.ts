import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  categories,
  collections,
  productCollections,
  productImages,
  products,
  productVariants,
  reviews,
} from "@/db/schema";
import { effectivePrice } from "@/lib/utils";

export type ProductListParams = {
  categorySlug?: string;
  collectionSlug?: string;
  q?: string;
  size?: string;
  color?: string;
  brand?: string;
  inStock?: boolean;
  minPrice?: number;
  maxPrice?: number;
  sort?: string;
  page?: number;
  pageSize?: number;
  featured?: boolean;
  newArrival?: boolean;
  bestSeller?: boolean;
};

export async function getProductCardData(productIds: string[]) {
  if (!productIds.length) return [];
  const rows = await db.select().from(products).where(inArray(products.id, productIds));
  const images = await db.select().from(productImages).where(inArray(productImages.productId, productIds));
  const variants = await db.select().from(productVariants).where(inArray(productVariants.productId, productIds));
  const reviewRows = await db
    .select({
      productId: reviews.productId,
      avg: sql<number>`avg(${reviews.rating})`,
      count: sql<number>`count(*)::int`,
    })
    .from(reviews)
    .where(and(inArray(reviews.productId, productIds), eq(reviews.status, "approved")))
    .groupBy(reviews.productId);

  return rows.map((p) => {
    const pImages = images.filter((i) => i.productId === p.id).sort((a, b) => a.sortOrder - b.sortOrder);
    const pVariants = variants.filter((v) => v.productId === p.id && v.isActive);
    const prices = pVariants.map((v) =>
      effectivePrice({
        price: v.price ?? p.price,
        salePrice: v.salePrice ?? p.salePrice,
        saleStartsAt: p.saleStartsAt,
        saleEndsAt: p.saleEndsAt,
      }),
    );
    const minPrice = prices.length ? Math.min(...prices.map((x) => x.price)) : p.price;
    const compare = prices.find((x) => x.compareAt)?.compareAt ?? null;
    const sizes = [...new Set(pVariants.map((v) => v.size).filter(Boolean))] as string[];
    const colors = [
      ...new Map(
        pVariants
          .filter((v) => v.color)
          .map((v) => [v.color, { color: v.color!, hex: v.colorHex || "#ccc" }]),
      ).values(),
    ];
    const stock = pVariants.reduce((s, v) => s + v.stock, 0);
    const rating = reviewRows.find((r) => r.productId === p.id);
    return {
      product: p,
      image: pImages.find((i) => i.isMain)?.url || pImages[0]?.url || null,
      images: pImages,
      minPrice,
      compareAt: compare && compare > minPrice ? compare : null,
      sizes,
      colors,
      stock,
      ratingAvg: rating ? Number(rating.avg) : 0,
      ratingCount: rating ? Number(rating.count) : 0,
      variants: pVariants,
    };
  });
}

export async function listProducts(params: ProductListParams) {
  const page = Math.max(1, params.page || 1);
  const pageSize = Math.min(48, params.pageSize || 12);
  const conditions = [eq(products.status, "published")];

  if (params.categorySlug) {
    const [cat] = await db.select().from(categories).where(eq(categories.slug, params.categorySlug)).limit(1);
    if (cat) conditions.push(eq(products.categoryId, cat.id));
    else return { items: [], total: 0, page, pageSize };
  }
  if (params.featured) conditions.push(eq(products.featured, true));
  if (params.newArrival) conditions.push(eq(products.newArrival, true));
  if (params.bestSeller) conditions.push(eq(products.bestSeller, true));
  if (params.brand) conditions.push(eq(products.brand, params.brand));

  let collectionProductIds: string[] | null = null;
  if (params.collectionSlug) {
    const [col] = await db.select().from(collections).where(eq(collections.slug, params.collectionSlug)).limit(1);
    if (!col) return { items: [], total: 0, page, pageSize };
    const links = await db.select().from(productCollections).where(eq(productCollections.collectionId, col.id));
    collectionProductIds = links.map((l) => l.productId);
    if (!collectionProductIds.length) return { items: [], total: 0, page, pageSize };
    conditions.push(inArray(products.id, collectionProductIds));
  }

  let rows = await db
    .select()
    .from(products)
    .where(and(...conditions));

  if (params.q) {
    const q = params.q.toLowerCase();
    rows = rows.filter((p) => {
      const hay = `${p.slug} ${p.sku} ${p.brand} ${p.name.en} ${p.name.fr} ${p.name.ar} ${(p.tags || []).join(" ")}`.toLowerCase();
      return hay.includes(q) || q.split(/\s+/).every((t) => hay.includes(t));
    });
  }

  const cards = await getProductCardData(rows.map((r) => r.id));
  let filtered = cards;
  if (params.size) filtered = filtered.filter((c) => c.sizes.includes(params.size!));
  if (params.color) filtered = filtered.filter((c) => c.colors.some((x) => x.color === params.color));
  if (params.inStock) filtered = filtered.filter((c) => c.stock > 0);
  if (typeof params.minPrice === "number") filtered = filtered.filter((c) => c.minPrice >= params.minPrice!);
  if (typeof params.maxPrice === "number") filtered = filtered.filter((c) => c.minPrice <= params.maxPrice!);

  switch (params.sort) {
    case "price-asc":
      filtered.sort((a, b) => a.minPrice - b.minPrice);
      break;
    case "price-desc":
      filtered.sort((a, b) => b.minPrice - a.minPrice);
      break;
    case "latest":
      filtered.sort((a, b) => b.product.createdAt.getTime() - a.product.createdAt.getTime());
      break;
    case "popularity":
      filtered.sort((a, b) => Number(b.product.bestSeller) - Number(a.product.bestSeller) || b.ratingCount - a.ratingCount);
      break;
    default:
      filtered.sort((a, b) => Number(b.product.featured) - Number(a.product.featured) || b.product.createdAt.getTime() - a.product.createdAt.getTime());
  }

  const total = filtered.length;
  const items = filtered.slice((page - 1) * pageSize, page * pageSize);
  return { items, total, page, pageSize };
}

export async function getFilterFacets(productIds?: string[]) {
  const variants = productIds?.length
    ? await db.select().from(productVariants).where(inArray(productVariants.productId, productIds))
    : await db.select().from(productVariants);
  const sizes = [...new Set(variants.map((v) => v.size).filter(Boolean))] as string[];
  const colors = [
    ...new Map(
      variants.filter((v) => v.color).map((v) => [v.color, { color: v.color!, hex: v.colorHex || "#ccc" }]),
    ).values(),
  ];
  const brands = [...new Set((await db.select({ brand: products.brand }).from(products)).map((p) => p.brand))];
  return { sizes: sizes.sort(), colors, brands };
}

export async function getNavData() {
  const cats = await db.select().from(categories).where(eq(categories.isActive, true)).orderBy(asc(categories.sortOrder));
  const cols = await db.select().from(collections).where(eq(collections.isActive, true)).orderBy(asc(collections.sortOrder));
  return { categories: cats, collections: cols };
}
