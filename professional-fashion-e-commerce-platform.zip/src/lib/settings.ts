import { eq } from "drizzle-orm";
import { db } from "@/db";
import { storeSettings } from "@/db/schema";
import type { StoreSettingsData } from "@/lib/types";

export const defaultSettings: StoreSettingsData = {
  storeName: "Maison Zahra",
  tagline: {
    en: "Quiet luxury from Casablanca.",
    fr: "Le luxe silencieux, depuis Casablanca.",
    ar: "فخامة هادئة من الدار البيضاء.",
  },
  logoText: "Maison Zahra",
  logoUrl: null,
  faviconUrl: null,
  announcement: {
    en: "Complimentary delivery in Morocco from 800 MAD · Autumn atelier drop now online",
    fr: "Livraison offerte au Maroc dès 800 MAD · Nouvelle collection d’automne",
    ar: "توصيل مجاني في المغرب ابتداءً من 800 درهم · مجموعة الخريف متاحة الآن",
  },
  announcementEnabled: true,
  primaryColor: "#1c1917",
  accentColor: "#b0894f",
  backgroundColor: "#f6f1ea",
  mutedColor: "#e8dfd2",
  textColor: "#1c1917",
  defaultLocale: "fr",
  locales: ["fr", "ar", "en"],
  currency: "MAD",
  country: "Morocco",
  timezone: "Africa/Casablanca",
  taxInclusive: true,
  taxRateBps: 2000,
  freeShippingThreshold: 80000,
  contactEmail: "atelier@maisonzahra.ma",
  contactPhone: "+212 522 00 00 00",
  whatsapp: "+212661000000",
  address: "12 Rue de l’Atelier, Gauthier",
  city: "Casablanca",
  businessHours: {
    en: "Monday–Saturday, 10:00–19:00",
    fr: "Lundi–samedi, 10h00–19h00",
    ar: "الاثنين–السبت، 10:00–19:00",
  },
  instagram: "https://instagram.com",
  facebook: "https://facebook.com",
  tiktok: "https://tiktok.com",
  maintenanceMode: false,
  orderPrefix: "MZ",
  invoiceFooter: {
    en: "Maison Zahra SARL · ICE 000000000000000 · Casablanca, Morocco",
    fr: "Maison Zahra SARL · ICE 000000000000000 · Casablanca, Maroc",
    ar: "ميزون زهرة ش.ذ.م.م · الدار البيضاء، المغرب",
  },
  codEnabled: true,
  cardEnabled: false,
  cardProvider: "none",
  lowStockThreshold: 5,
  restoreStockOnCancel: true,
  restoreStockOnRefund: true,
  allowOversell: false,
  seoTitle: {
    en: "Maison Zahra — Premium Moroccan fashion",
    fr: "Maison Zahra — Mode marocaine d’exception",
    ar: "ميزون زهرة — أزياء مغربية راقية",
  },
  seoDescription: {
    en: "Premium clothing, shoes and accessories designed in Casablanca. Arabic, French and English. Cash on delivery across Morocco.",
    fr: "Prêt-à-porter, chaussures et accessoires dessinés à Casablanca. Arabe, français et anglais. Paiement à la livraison partout au Maroc.",
    ar: "ملابس وأحذية وإكسسوارات راقية من الدار البيضاء. العربية والفرنسية والإنجليزية. الدفع عند الاستلام في جميع أنحاء المغرب.",
  },
  heroImage: "/images/hero.jpg",
  footerNote: {
    en: "Crafted in small quantities. Made to be kept.",
    fr: "Pièces en quantités limitées. Conçues pour durer.",
    ar: "قطع محدودة الكمية. صُنعت لتُحفظ.",
  },
};

let cache: { data: StoreSettingsData; at: number } | null = null;

export async function getSettings(): Promise<StoreSettingsData> {
  if (cache && Date.now() - cache.at < 15_000) return cache.data;
  const [row] = await db.select().from(storeSettings).where(eq(storeSettings.id, 1)).limit(1);
  const data = { ...defaultSettings, ...((row?.data as StoreSettingsData) || {}) };
  cache = { data, at: Date.now() };
  return data;
}

export function invalidateSettingsCache() {
  cache = null;
}

export async function saveSettings(patch: Partial<StoreSettingsData>): Promise<StoreSettingsData> {
  const current = await getSettings();
  const next = { ...current, ...patch };
  await db
    .insert(storeSettings)
    .values({ id: 1, data: next, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: storeSettings.id,
      set: { data: next, updatedAt: new Date() },
    });
  invalidateSettingsCache();
  return next;
}
