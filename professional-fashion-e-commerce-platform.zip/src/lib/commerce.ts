import { and, eq, inArray, sql } from "drizzle-orm";
import { cookies } from "next/headers";
import { db } from "@/db";
import {
  cartItems,
  carts,
  couponRedemptions,
  coupons,
  inventoryMovements,
  notifications,
  orderItems,
  orderStatusHistory,
  orders,
  payments,
  productImages,
  products,
  productVariants,
  shippingZones,
} from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import type { CartView, CartViewItem, Locale } from "@/lib/types";
import { effectivePrice, loc, moroccoPhoneValid, uniqueOrderNumber } from "@/lib/utils";

const CART_COOKIE = "mz_cart";

export async function getCartSessionId(): Promise<string> {
  const store = await cookies();
  let id = store.get(CART_COOKIE)?.value;
  if (!id) {
    id = crypto.randomUUID();
    store.set(CART_COOKIE, id, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 90,
    });
  }
  return id;
}

export async function getOrCreateCart() {
  const sessionId = await getCartSessionId();
  const user = await getSessionUser();
  const [existing] = await db.select().from(carts).where(eq(carts.sessionId, sessionId)).limit(1);
  if (existing) {
    if (user && existing.userId !== user.id) {
      await db.update(carts).set({ userId: user.id, updatedAt: new Date() }).where(eq(carts.id, existing.id));
    }
    return existing;
  }
  if (user) {
    const [userCart] = await db.select().from(carts).where(eq(carts.userId, user.id)).limit(1);
    if (userCart) {
      await db.update(carts).set({ sessionId, updatedAt: new Date() }).where(eq(carts.id, userCart.id));
      return { ...userCart, sessionId };
    }
  }
  const [created] = await db
    .insert(carts)
    .values({ sessionId, userId: user?.id || null })
    .returning();
  return created;
}

export async function addToCart(variantId: string, quantity: number) {
  if (quantity < 1 || quantity > 20) throw new Error("Invalid quantity");
  const cart = await getOrCreateCart();
  const [variant] = await db.select().from(productVariants).where(eq(productVariants.id, variantId)).limit(1);
  if (!variant || !variant.isActive) throw new Error("Variant unavailable");
  const [product] = await db.select().from(products).where(eq(products.id, variant.productId)).limit(1);
  if (!product || product.status !== "published") throw new Error("Product unavailable");
  const [existing] = await db
    .select()
    .from(cartItems)
    .where(and(eq(cartItems.cartId, cart.id), eq(cartItems.variantId, variantId)))
    .limit(1);
  const nextQty = (existing?.quantity || 0) + quantity;
  if (nextQty > variant.stock) throw new Error("Insufficient stock");
  if (existing) {
    await db.update(cartItems).set({ quantity: nextQty }).where(eq(cartItems.id, existing.id));
  } else {
    await db.insert(cartItems).values({ cartId: cart.id, variantId, quantity });
  }
  await db.update(carts).set({ updatedAt: new Date() }).where(eq(carts.id, cart.id));
  return getCartView();
}

export async function updateCartItem(itemId: string, quantity: number) {
  const cart = await getOrCreateCart();
  if (quantity <= 0) {
    await db.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id)));
    return getCartView();
  }
  const [item] = await db
    .select()
    .from(cartItems)
    .where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id)))
    .limit(1);
  if (!item) throw new Error("Item not found");
  const [variant] = await db.select().from(productVariants).where(eq(productVariants.id, item.variantId)).limit(1);
  if (!variant || quantity > variant.stock) throw new Error("Insufficient stock");
  await db.update(cartItems).set({ quantity }).where(eq(cartItems.id, itemId));
  return getCartView();
}

export async function applyCoupon(code: string) {
  const cart = await getOrCreateCart();
  const normalized = code.trim().toUpperCase();
  if (!normalized) {
    await db.update(carts).set({ couponCode: null, updatedAt: new Date() }).where(eq(carts.id, cart.id));
    return getCartView();
  }
  const [coupon] = await db.select().from(coupons).where(eq(coupons.code, normalized)).limit(1);
  if (!coupon || !coupon.isActive) throw new Error("Invalid coupon");
  await db.update(carts).set({ couponCode: normalized, updatedAt: new Date() }).where(eq(carts.id, cart.id));
  return getCartView();
}

export async function shippingFeeForCity(city: string, subtotalAfterDiscount: number) {
  const settings = await getSettings();
  if (subtotalAfterDiscount >= settings.freeShippingThreshold) return 0;
  const zones = await db.select().from(shippingZones);
  const match = zones.find(
    (z) => z.isActive && z.cities.some((c) => c.toLowerCase() === city.trim().toLowerCase()),
  );
  if (match) return match.fee;
  const fallback = zones.find((z) => z.isActive && z.cities.length === 0);
  return fallback?.fee ?? 4500;
}

export function evaluateCoupon(params: {
  coupon: typeof coupons.$inferSelect;
  subtotal: number;
  email?: string | null;
  usedByEmail?: number;
}): { ok: boolean; discount: number; freeShipping: boolean; message?: string } {
  const now = Date.now();
  if (!params.coupon.isActive) return { ok: false, discount: 0, freeShipping: false, message: "Inactive" };
  if (params.coupon.startsAt && params.coupon.startsAt.getTime() > now)
    return { ok: false, discount: 0, freeShipping: false, message: "Not started" };
  if (params.coupon.endsAt && params.coupon.endsAt.getTime() < now)
    return { ok: false, discount: 0, freeShipping: false, message: "Expired" };
  if (params.coupon.maxUses != null && params.coupon.usedCount >= params.coupon.maxUses)
    return { ok: false, discount: 0, freeShipping: false, message: "Limit reached" };
  if (params.coupon.perCustomerLimit && params.usedByEmail && params.usedByEmail >= params.coupon.perCustomerLimit)
    return { ok: false, discount: 0, freeShipping: false, message: "Already used" };
  if (params.subtotal < params.coupon.minOrder)
    return { ok: false, discount: 0, freeShipping: false, message: "Minimum not met" };
  if (params.coupon.type === "free_shipping") return { ok: true, discount: 0, freeShipping: true };
  if (params.coupon.type === "percent") {
    const discount = Math.round((params.subtotal * params.coupon.value) / 10000);
    return { ok: true, discount: Math.min(discount, params.subtotal), freeShipping: false };
  }
  return { ok: true, discount: Math.min(params.coupon.value, params.subtotal), freeShipping: false };
}

export async function getCartView(city?: string): Promise<CartView> {
  const cart = await getOrCreateCart();
  const items = await db.select().from(cartItems).where(eq(cartItems.cartId, cart.id));
  const viewItems: CartViewItem[] = [];
  for (const item of items) {
    const [variant] = await db.select().from(productVariants).where(eq(productVariants.id, item.variantId)).limit(1);
    if (!variant) continue;
    const [product] = await db.select().from(products).where(eq(products.id, variant.productId)).limit(1);
    if (!product) continue;
    const [image] = await db
      .select()
      .from(productImages)
      .where(eq(productImages.productId, product.id))
      .orderBy(productImages.sortOrder)
      .limit(1);
    const priced = effectivePrice({
      price: variant.price ?? product.price,
      salePrice: variant.salePrice ?? product.salePrice,
      saleStartsAt: product.saleStartsAt,
      saleEndsAt: product.saleEndsAt,
    });
    viewItems.push({
      id: item.id,
      variantId: variant.id,
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: image?.url || null,
      size: variant.size,
      color: variant.color,
      sku: variant.sku,
      quantity: item.quantity,
      unitPrice: priced.price,
      compareAt: priced.compareAt,
      stock: variant.stock,
      lineTotal: priced.price * item.quantity,
    });
  }
  const subtotal = viewItems.reduce((s, i) => s + i.lineTotal, 0);
  let discount = 0;
  let couponMessage: string | null = null;
  let freeShippingApplied = false;
  if (cart.couponCode) {
    const [coupon] = await db.select().from(coupons).where(eq(coupons.code, cart.couponCode)).limit(1);
    if (coupon) {
      const user = await getSessionUser();
      let usedByEmail = 0;
      if (user?.email) {
        const redemptions = await db
          .select()
          .from(couponRedemptions)
          .where(and(eq(couponRedemptions.couponId, coupon.id), eq(couponRedemptions.email, user.email)));
        usedByEmail = redemptions.length;
      }
      const result = evaluateCoupon({ coupon, subtotal, email: user?.email, usedByEmail });
      if (result.ok) {
        discount = result.discount;
        freeShippingApplied = result.freeShipping;
      } else {
        couponMessage = result.message || "Invalid";
      }
    } else {
      couponMessage = "Invalid";
    }
  }
  const settings = await getSettings();
  const afterDiscount = Math.max(0, subtotal - discount);
  let shippingFee = 0;
  if (city) {
    shippingFee = freeShippingApplied ? 0 : await shippingFeeForCity(city, afterDiscount);
  } else if (afterDiscount >= settings.freeShippingThreshold || freeShippingApplied) {
    shippingFee = 0;
  } else {
    shippingFee = 0;
  }
  const tax = settings.taxInclusive ? 0 : Math.round((afterDiscount * settings.taxRateBps) / 10000);
  const total = afterDiscount + shippingFee + tax;
  return {
    id: cart.id,
    items: viewItems,
    subtotal,
    discount,
    shippingFee,
    tax,
    total,
    couponCode: cart.couponCode,
    couponMessage,
    freeShippingApplied,
  };
}

export type CheckoutInput = {
  name: string;
  email: string;
  phone: string;
  street: string;
  city: string;
  region: string;
  postalCode?: string;
  country?: string;
  note?: string;
  paymentMethod: "cod" | "card";
  idempotencyKey: string;
  locale: Locale;
};

export async function placeOrder(input: CheckoutInput) {
  const settings = await getSettings();
  if (input.paymentMethod === "cod" && !settings.codEnabled) throw new Error("COD is disabled");
  if (input.paymentMethod === "card") throw new Error("Card payments are not configured");
  if (!input.name.trim() || !input.email.trim() || !input.phone.trim()) throw new Error("Missing contact");
  if (!moroccoPhoneValid(input.phone)) throw new Error("Invalid phone");
  if (!input.street.trim() || !input.city.trim() || !input.region.trim()) throw new Error("Missing address");
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.email)) throw new Error("Invalid email");

  const user = await getSessionUser();
  const cart = await getOrCreateCart();

  const [existing] = await db
    .select()
    .from(orders)
    .where(eq(orders.idempotencyKey, input.idempotencyKey))
    .limit(1);
  if (existing) return existing;

  const result = await db.transaction(async (tx) => {
    const items = await tx.select().from(cartItems).where(eq(cartItems.cartId, cart.id));
    if (items.length === 0) throw new Error("Cart is empty");

    const snapshot: Array<{
      item: typeof cartItems.$inferSelect;
      variant: typeof productVariants.$inferSelect;
      product: typeof products.$inferSelect;
      unitPrice: number;
      image: string | null;
    }> = [];

    for (const item of items) {
      const [variant] = await tx
        .select()
        .from(productVariants)
        .where(eq(productVariants.id, item.variantId))
        .for("update")
        .limit(1);
      if (!variant || !variant.isActive) throw new Error("Variant unavailable");
      if (variant.stock < item.quantity) throw new Error("Insufficient stock");
      const [product] = await tx.select().from(products).where(eq(products.id, variant.productId)).limit(1);
      if (!product || product.status !== "published") throw new Error("Product unavailable");
      const priced = effectivePrice({
        price: variant.price ?? product.price,
        salePrice: variant.salePrice ?? product.salePrice,
        saleStartsAt: product.saleStartsAt,
        saleEndsAt: product.saleEndsAt,
      });
      const [image] = await tx
        .select()
        .from(productImages)
        .where(eq(productImages.productId, product.id))
        .limit(1);
      snapshot.push({ item, variant, product, unitPrice: priced.price, image: image?.url || null });
    }

    const subtotal = snapshot.reduce((s, row) => s + row.unitPrice * row.item.quantity, 0);
    let discount = 0;
    let freeShipping = false;
    let couponRow: typeof coupons.$inferSelect | null = null;
    if (cart.couponCode) {
      const [coupon] = await tx.select().from(coupons).where(eq(coupons.code, cart.couponCode)).limit(1);
      if (coupon) {
        const redemptions = await tx
          .select()
          .from(couponRedemptions)
          .where(
            and(eq(couponRedemptions.couponId, coupon.id), eq(couponRedemptions.email, input.email.toLowerCase())),
          );
        const evaluated = evaluateCoupon({
          coupon,
          subtotal,
          email: input.email,
          usedByEmail: redemptions.length,
        });
        if (evaluated.ok) {
          discount = evaluated.discount;
          freeShipping = evaluated.freeShipping;
          couponRow = coupon;
        }
      }
    }
    const afterDiscount = Math.max(0, subtotal - discount);
    const shippingFee = freeShipping ? 0 : await shippingFeeForCity(input.city, afterDiscount);
    const tax = settings.taxInclusive ? 0 : Math.round((afterDiscount * settings.taxRateBps) / 10000);
    const total = afterDiscount + shippingFee + tax;

    const [{ count }] = await tx.select({ count: sql<number>`count(*)::int` }).from(orders);
    const orderNumber = uniqueOrderNumber(settings.orderPrefix, Number(count) + 1);

    const [order] = await tx
      .insert(orders)
      .values({
        orderNumber,
        userId: user?.id || null,
        email: input.email.toLowerCase(),
        phone: input.phone,
        customerName: input.name.trim(),
        status: "pending",
        paymentStatus: input.paymentMethod === "cod" ? "pending" : "pending",
        paymentMethod: input.paymentMethod,
        subtotal,
        discount,
        shippingFee,
        tax,
        total,
        currency: settings.currency,
        couponCode: couponRow?.code || null,
        shippingAddress: {
          fullName: input.name.trim(),
          phone: input.phone,
          street: input.street.trim(),
          city: input.city.trim(),
          region: input.region.trim(),
          postalCode: input.postalCode || "",
          country: input.country || settings.country,
        },
        customerNote: input.note || null,
        idempotencyKey: input.idempotencyKey,
      })
      .returning();

    for (const row of snapshot) {
      await tx.insert(orderItems).values({
        orderId: order.id,
        productId: row.product.id,
        variantId: row.variant.id,
        name: loc(row.product.name, input.locale),
        sku: row.variant.sku,
        size: row.variant.size,
        color: row.variant.color,
        image: row.image,
        unitPrice: row.unitPrice,
        quantity: row.item.quantity,
        total: row.unitPrice * row.item.quantity,
      });
      await tx
        .update(productVariants)
        .set({ stock: row.variant.stock - row.item.quantity })
        .where(eq(productVariants.id, row.variant.id));
      await tx.insert(inventoryMovements).values({
        variantId: row.variant.id,
        quantity: -row.item.quantity,
        reason: "sale",
        orderId: order.id,
        note: `Order ${order.orderNumber}`,
      });
    }

    await tx.insert(orderStatusHistory).values({
      orderId: order.id,
      status: "pending",
      note: "Order placed (cash on delivery)",
      actorId: user?.id || null,
    });
    await tx.insert(payments).values({
      orderId: order.id,
      provider: "cod",
      method: "cod",
      status: "pending",
      amount: total,
      currency: settings.currency,
      providerRef: order.orderNumber,
    });
    if (couponRow) {
      await tx.insert(couponRedemptions).values({
        couponId: couponRow.id,
        userId: user?.id || null,
        orderId: order.id,
        email: input.email.toLowerCase(),
      });
      await tx
        .update(coupons)
        .set({ usedCount: couponRow.usedCount + 1 })
        .where(eq(coupons.id, couponRow.id));
    }
    await tx.delete(cartItems).where(eq(cartItems.cartId, cart.id));
    await tx.update(carts).set({ couponCode: null, updatedAt: new Date() }).where(eq(carts.id, cart.id));
    await tx.insert(notifications).values({
      type: "order",
      title: `New order ${order.orderNumber}`,
      body: `${input.name} · ${settings.currency} ${(total / 100).toFixed(2)} · ${input.city}`,
    });
    return order;
  });

  return result;
}

export async function restoreStockForOrder(orderId: string, reason: "cancellation" | "return") {
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  for (const item of items) {
    if (!item.variantId) continue;
    const [variant] = await db.select().from(productVariants).where(eq(productVariants.id, item.variantId)).limit(1);
    if (!variant) continue;
    await db
      .update(productVariants)
      .set({ stock: variant.stock + item.quantity })
      .where(eq(productVariants.id, variant.id));
    await db.insert(inventoryMovements).values({
      variantId: variant.id,
      quantity: item.quantity,
      reason: reason === "cancellation" ? "cancellation" : "return",
      orderId,
    });
  }
}

export async function searchProducts(query: string, limit = 8) {
  const q = query.trim().toLowerCase();
  if (q.length < 2) return [];
  const published = await db.select().from(products).where(eq(products.status, "published"));
  const scored = published
    .map((p) => {
      const hay = `${p.slug} ${p.sku} ${p.brand} ${p.name.en} ${p.name.fr} ${p.name.ar} ${(p.tags || []).join(" ")}`.toLowerCase();
      let score = 0;
      if (hay.includes(q)) score += 5;
      const tokens = q.split(/\s+/);
      for (const token of tokens) {
        if (hay.includes(token)) score += 2;
        if (p.sku.toLowerCase().includes(token)) score += 4;
      }
      return { product: p, score };
    })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
  const ids = scored.map((s) => s.product.id);
  const images = ids.length
    ? await db.select().from(productImages).where(inArray(productImages.productId, ids))
    : [];
  return scored.map((s) => ({
    ...s.product,
    image: images.find((i) => i.productId === s.product.id && i.isMain)?.url || images.find((i) => i.productId === s.product.id)?.url || null,
  }));
}
