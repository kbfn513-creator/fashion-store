import type { Localized } from "@/db/schema";
import type { Locale } from "@/lib/types";

export function loc(value: Localized | null | undefined, locale: Locale): string {
  if (!value) return "";
  return value[locale] || value.fr || value.en || value.ar || "";
}

export function slugify(input: string): string {
  return input
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 80);
}

export function formatMoney(centimes: number, locale: Locale, currency = "MAD"): string {
  const amount = centimes / 100;
  const localeTag = locale === "ar" ? "ar-MA" : locale === "fr" ? "fr-MA" : "en-MA";
  try {
    return new Intl.NumberFormat(localeTag, {
      style: "currency",
      currency,
      maximumFractionDigits: 2,
    }).format(amount);
  } catch {
    return `${amount.toFixed(2)} ${currency}`;
  }
}

export function formatDate(value: Date | string, locale: Locale): string {
  const date = typeof value === "string" ? new Date(value) : value;
  const localeTag = locale === "ar" ? "ar-MA" : locale === "fr" ? "fr-MA" : "en-MA";
  return new Intl.DateTimeFormat(localeTag, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(date);
}

export function parseLocale(value: string | undefined | null): Locale {
  if (value === "ar" || value === "fr" || value === "en") return value;
  return "fr";
}

export async function getRequestLocale(defaultLocale: Locale = "fr"): Promise<Locale> {
  const { cookies } = await import("next/headers");
  const store = await cookies();
  return parseLocale(store.get("locale")?.value || defaultLocale);
}

export function effectivePrice(params: {
  price: number;
  salePrice?: number | null;
  saleStartsAt?: Date | null;
  saleEndsAt?: Date | null;
}): { price: number; compareAt: number | null; onSale: boolean } {
  const now = Date.now();
  const startsOk = !params.saleStartsAt || params.saleStartsAt.getTime() <= now;
  const endsOk = !params.saleEndsAt || params.saleEndsAt.getTime() >= now;
  const onSale =
    typeof params.salePrice === "number" &&
    params.salePrice > 0 &&
    params.salePrice < params.price &&
    startsOk &&
    endsOk;
  return {
    price: onSale ? params.salePrice! : params.price,
    compareAt: onSale ? params.price : null,
    onSale,
  };
}

export function discountPercent(price: number, compareAt: number | null): number | null {
  if (!compareAt || compareAt <= price) return null;
  return Math.round(((compareAt - price) / compareAt) * 100);
}

export function moroccoPhoneValid(phone: string): boolean {
  const cleaned = phone.replace(/[\s-]/g, "");
  return /^(\+212|0)[5-7]\d{8}$/.test(cleaned);
}

export function normalizePhone(phone: string): string {
  const cleaned = phone.replace(/[\s-]/g, "");
  if (cleaned.startsWith("0") && cleaned.length === 10) {
    return `+212${cleaned.slice(1)}`;
  }
  return cleaned;
}

export async function getClientIp(): Promise<string> {
  const { headers } = await import("next/headers");
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || "unknown";
}

export function cn(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(" ");
}

export function uniqueOrderNumber(prefix: string, seq: number): string {
  return `${prefix}${String(seq).padStart(6, "0")}`;
}

export function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function csvEscape(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}
