import type { Localized } from "@/db/schema";

export type Locale = "en" | "fr" | "ar";

export type StoreSettingsData = {
  storeName: string;
  tagline: Localized;
  logoText: string;
  logoUrl: string | null;
  faviconUrl: string | null;
  announcement: Localized;
  announcementEnabled: boolean;
  primaryColor: string;
  accentColor: string;
  backgroundColor: string;
  mutedColor: string;
  textColor: string;
  defaultLocale: Locale;
  locales: Locale[];
  currency: string;
  country: string;
  timezone: string;
  taxInclusive: boolean;
  taxRateBps: number;
  freeShippingThreshold: number;
  contactEmail: string;
  contactPhone: string;
  whatsapp: string;
  address: string;
  city: string;
  businessHours: Localized;
  instagram: string;
  facebook: string;
  tiktok: string;
  maintenanceMode: boolean;
  orderPrefix: string;
  invoiceFooter: Localized;
  codEnabled: boolean;
  cardEnabled: boolean;
  cardProvider: string;
  lowStockThreshold: number;
  restoreStockOnCancel: boolean;
  restoreStockOnRefund: boolean;
  allowOversell: boolean;
  seoTitle: Localized;
  seoDescription: Localized;
  heroImage: string;
  footerNote: Localized;
};

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: "customer" | "admin" | "staff";
  permissions: string[];
};

export type CartViewItem = {
  id: string;
  variantId: string;
  productId: string;
  slug: string;
  name: Localized;
  image: string | null;
  size: string | null;
  color: string | null;
  sku: string;
  quantity: number;
  unitPrice: number;
  compareAt: number | null;
  stock: number;
  lineTotal: number;
};

export type CartView = {
  id: string;
  items: CartViewItem[];
  subtotal: number;
  discount: number;
  shippingFee: number;
  tax: number;
  total: number;
  couponCode: string | null;
  couponMessage: string | null;
  freeShippingApplied: boolean;
};

export const STAFF_PERMISSIONS = [
  "dashboard",
  "products",
  "inventory",
  "orders",
  "customers",
  "promotions",
  "content",
  "reviews",
  "messages",
  "settings",
] as const;

export type StaffPermission = (typeof STAFF_PERMISSIONS)[number];
