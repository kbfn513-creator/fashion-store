import { cookies } from "next/headers";
import Link from "next/link";
import { CheckoutForm } from "@/components/client-ui";
import { getSessionUser } from "@/lib/auth";
import { getCartView } from "@/lib/commerce";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { formatMoney, loc, parseLocale } from "@/lib/utils";
import { db } from "@/db";
import { shippingZones } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function CheckoutPage() {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const cart = await getCartView();
  const user = await getSessionUser();
  const zones = await db.select().from(shippingZones);
  const cities = [...new Set(zones.flatMap((z) => z.cities))].sort();
  if (!cities.includes("Casablanca")) cities.unshift("Casablanca");
  if (cart.items.length === 0) {
    return (
      <main className="container-mz py-20 text-center">
        <p>{dict.cart.empty}</p>
        <Link href="/shop" className="mt-4 inline-block underline">
          {dict.cart.continue}
        </Link>
      </main>
    );
  }
  return (
    <main className="container-mz grid gap-12 py-12 lg:grid-cols-2">
      <div>
        <h1 className="font-serif text-4xl">{dict.checkout.title}</h1>
        {!user && <p className="mt-2 text-sm text-stone-500">{dict.checkout.guest}</p>}
        <div className="mt-8">
          <CheckoutForm
            locale={locale}
            cities={cities}
            defaultName={user?.name}
            defaultEmail={user?.email}
            labels={{
              contact: dict.checkout.contact,
              delivery: dict.checkout.delivery,
              method: dict.checkout.method,
              name: dict.checkout.name,
              email: dict.checkout.email,
              phone: dict.checkout.phone,
              street: dict.checkout.street,
              city: dict.checkout.city,
              region: dict.checkout.region,
              postal: dict.checkout.postal,
              note: dict.checkout.note,
              cod: dict.checkout.cod,
              codHint: dict.checkout.codHint,
              cardUnavailable: dict.checkout.cardUnavailable,
              terms: dict.checkout.terms,
              placeOrder: dict.checkout.placeOrder,
              placing: dict.checkout.placing,
            }}
          />
        </div>
      </div>
      <aside className="h-fit border border-[var(--mz-line)] p-6">
        <h2 className="font-serif text-2xl">{dict.checkout.review}</h2>
        <ul className="mt-4 space-y-3 text-sm">
          {cart.items.map((item) => (
            <li key={item.id} className="flex justify-between gap-3">
              <span>
                {loc(item.name, locale)} × {item.quantity}
              </span>
              <span>{formatMoney(item.lineTotal, locale)}</span>
            </li>
          ))}
        </ul>
        <dl className="mt-6 space-y-2 text-sm">
          <div className="flex justify-between">
            <dt>{dict.cart.subtotal}</dt>
            <dd>{formatMoney(cart.subtotal, locale)}</dd>
          </div>
          <div className="flex justify-between">
            <dt>{dict.cart.discount}</dt>
            <dd>-{formatMoney(cart.discount, locale)}</dd>
          </div>
          <div className="flex justify-between">
            <dt>{dict.cart.shipping}</dt>
            <dd>{locale === "ar" ? "يُحتسب حسب المدينة" : locale === "fr" ? "Selon la ville" : "Calculated by city"}</dd>
          </div>
        </dl>
        {!settings.codEnabled && <p className="mt-4 text-sm text-red-800">COD disabled</p>}
      </aside>
    </main>
  );
}
