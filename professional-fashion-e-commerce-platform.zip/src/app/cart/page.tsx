import Link from "next/link";
import { cookies } from "next/headers";
import { CartControls, CouponForm } from "@/components/client-ui";
import { getCartView } from "@/lib/commerce";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { formatMoney, loc, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function CartPage() {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const cart = await getCartView();
  const remaining = Math.max(0, settings.freeShippingThreshold - (cart.subtotal - cart.discount));
  return (
    <main className="container-mz py-12">
      <h1 className="font-serif text-4xl">{dict.cart.title}</h1>
      {cart.items.length === 0 ? (
        <div className="py-16 text-center">
          <p>{dict.cart.empty}</p>
          <Link href="/shop" className="mt-6 inline-block underline">
            {dict.cart.continue}
          </Link>
        </div>
      ) : (
        <div className="mt-10 grid gap-12 lg:grid-cols-[1.4fr_0.8fr]">
          <ul className="space-y-6">
            {cart.items.map((item) => (
              <li key={item.id} className="flex gap-4 border-b border-[var(--mz-line)] pb-6">
                {item.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.image} alt="" className="h-28 w-20 object-cover" />
                )}
                <div className="flex-1">
                  <Link href={`/products/${item.slug}`}>{loc(item.name, locale)}</Link>
                  <p className="text-sm text-stone-500">
                    {[item.color, item.size, item.sku].filter(Boolean).join(" · ")}
                  </p>
                  <p className="mt-1 text-sm">{formatMoney(item.unitPrice, locale)}</p>
                  <CartControls itemId={item.id} quantity={item.quantity} stock={item.stock} />
                </div>
                <p>{formatMoney(item.lineTotal, locale)}</p>
              </li>
            ))}
          </ul>
          <aside className="h-fit border border-[var(--mz-line)] p-6">
            {remaining > 0 ? (
              <p className="text-sm">{dict.cart.freeShippingHint.replace("{amount}", formatMoney(remaining, locale))}</p>
            ) : (
              <p className="text-sm">{dict.cart.freeShipping}</p>
            )}
            <CouponForm label={dict.cart.apply} current={cart.couponCode} />
            {cart.couponMessage && <p className="mt-2 text-sm text-red-800">{dict.cart.invalidCoupon}</p>}
            <dl className="mt-6 space-y-2 text-sm">
              <div className="flex justify-between">
                <dt>{dict.cart.subtotal}</dt>
                <dd>{formatMoney(cart.subtotal, locale)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>{dict.cart.discount}</dt>
                <dd>-{formatMoney(cart.discount, locale)}</dd>
              </div>
              <div className="flex justify-between font-medium">
                <dt>{dict.cart.total}</dt>
                <dd>{formatMoney(cart.subtotal - cart.discount, locale)}</dd>
              </div>
            </dl>
            <Link
              href="/checkout"
              className="mt-6 block bg-[var(--mz-ink)] py-3 text-center text-[12px] tracking-[0.2em] text-[var(--mz-bg)] uppercase"
            >
              {dict.cart.checkout}
            </Link>
          </aside>
        </div>
      )}
    </main>
  );
}
