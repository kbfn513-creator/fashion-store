import { cookies } from "next/headers";
import { and, eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/db";
import { categories, productImages, products, productVariants, reviews, shippingZones } from "@/db/schema";
import { AddToCartForm, Gallery, ReviewForm, WishlistButton } from "@/components/client-ui";
import { ProductGrid, Stars } from "@/components/catalog";
import { t } from "@/lib/i18n";
import { listProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { discountPercent, effectivePrice, formatMoney, loc, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const [product] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  if (!product) return { title: "Product" };
  return { title: product.name.fr, description: product.description.fr.slice(0, 160) };
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [product] = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  if (!product || product.status !== "published") notFound();
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const images = await db.select().from(productImages).where(eq(productImages.productId, product.id));
  const variants = await db.select().from(productVariants).where(eq(productVariants.productId, product.id));
  const approved = await db
    .select()
    .from(reviews)
    .where(and(eq(reviews.productId, product.id), eq(reviews.status, "approved")));
  const [category] = product.categoryId
    ? await db.select().from(categories).where(eq(categories.id, product.categoryId)).limit(1)
    : [null];
  const related = await listProducts({ categorySlug: category?.slug, pageSize: 4 });
  const priced = effectivePrice({
    price: product.price,
    salePrice: product.salePrice,
    saleStartsAt: product.saleStartsAt,
    saleEndsAt: product.saleEndsAt,
  });
  const pct = discountPercent(priced.price, priced.compareAt);
  const stock = variants.reduce((s, v) => s + v.stock, 0);
  const avg = approved.length ? approved.reduce((s, r) => s + r.rating, 0) / approved.length : 0;
  const zones = await db.select().from(shippingZones);
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: loc(product.name, locale),
    description: loc(product.description, locale),
    sku: product.sku,
    brand: product.brand,
    image: images.map((i) => i.url),
    offers: {
      "@type": "Offer",
      priceCurrency: settings.currency,
      price: (priced.price / 100).toFixed(2),
      availability: stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
    ...(approved.length
      ? { aggregateRating: { "@type": "AggregateRating", ratingValue: avg.toFixed(1), reviewCount: approved.length } }
      : {}),
  };

  return (
    <main className="container-mz py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <div className="grid gap-10 lg:grid-cols-2">
        <Gallery images={images.map((i) => ({ url: i.url, alt: i.alt || loc(product.name, locale) }))} />
        <div>
          <p className="text-[11px] tracking-[0.2em] uppercase text-stone-500">{product.brand}</p>
          <h1 className="mt-2 font-serif text-4xl">{loc(product.name, locale)}</h1>
          {approved.length > 0 && (
            <p className="mt-2 text-sm">
              <Stars value={avg} /> {avg.toFixed(1)} ({approved.length})
            </p>
          )}
          <p className="mt-4 text-xl">
            {priced.compareAt && (
              <span className="me-3 text-stone-400 line-through">{formatMoney(priced.compareAt, locale)}</span>
            )}
            {formatMoney(priced.price, locale)}
            {pct && <span className="ms-3 text-sm text-[var(--mz-accent)]">-{pct}%</span>}
          </p>
          <p className="mt-2 text-sm text-stone-500">
            {stock < 1 ? dict.product.outOfStock : stock <= product.lowStockThreshold ? dict.product.lowStock : dict.product.inStock}
          </p>
          <AddToCartForm
            variants={variants.map((v) => ({
              id: v.id,
              size: v.size,
              color: v.color,
              colorHex: v.colorHex,
              stock: v.stock,
              sku: v.sku,
            }))}
            labels={{
              size: dict.product.size,
              color: dict.product.color,
              add: dict.product.addToCart,
              added: dict.product.added,
              selectSize: dict.product.selectSize,
              out: dict.product.outOfStock,
              sku: dict.product.sku,
            }}
          />
          <div className="mt-4">
            <WishlistButton productId={product.id} label={dict.nav.wishlist} />
          </div>
          <div className="mt-10 space-y-6 text-sm leading-relaxed">
            <section>
              <h2 className="text-[11px] tracking-[0.18em] uppercase">{dict.product.description}</h2>
              <p className="mt-2 whitespace-pre-line">{loc(product.description, locale)}</p>
            </section>
            <section>
              <h2 className="text-[11px] tracking-[0.18em] uppercase">{dict.product.materials}</h2>
              <p className="mt-2">{loc(product.materials, locale)}</p>
            </section>
            <section>
              <h2 className="text-[11px] tracking-[0.18em] uppercase">{dict.product.care}</h2>
              <p className="mt-2">{loc(product.care, locale)}</p>
            </section>
            <section>
              <h2 className="text-[11px] tracking-[0.18em] uppercase">{dict.product.fit}</h2>
              <p className="mt-2">{loc(product.fit, locale)}</p>
            </section>
            <section>
              <h2 className="text-[11px] tracking-[0.18em] uppercase">{dict.product.sizeGuide}</h2>
              <p className="mt-2">{loc(product.sizeGuide, locale)}</p>
            </section>
            <section>
              <h2 className="text-[11px] tracking-[0.18em] uppercase">{dict.product.delivery}</h2>
              <ul className="mt-2 space-y-1 text-stone-600">
                {zones.map((z) => (
                  <li key={z.id}>
                    {z.name}: {z.estimatedDays} {locale === "ar" ? "أيام" : locale === "fr" ? "jours" : "days"} ·{" "}
                    {formatMoney(z.fee, locale)}
                  </li>
                ))}
                <li>
                  {locale === "ar"
                    ? `توصيل مجاني ابتداءً من ${formatMoney(settings.freeShippingThreshold, locale)}`
                    : locale === "fr"
                      ? `Livraison offerte dès ${formatMoney(settings.freeShippingThreshold, locale)}`
                      : `Free delivery from ${formatMoney(settings.freeShippingThreshold, locale)}`}
                </li>
              </ul>
            </section>
          </div>
        </div>
      </div>

      <section className="mt-16">
        <h2 className="font-serif text-3xl">{dict.product.reviews}</h2>
        {approved.length === 0 && <p className="mt-4 text-stone-500">{dict.product.noReviews}</p>}
        <ul className="mt-6 space-y-6">
          {approved.map((r) => (
            <li key={r.id} className="border-b border-[var(--mz-line)] pb-4">
              <Stars value={r.rating} />
              {r.verifiedPurchase && <span className="ms-2 text-xs">{dict.product.verified}</span>}
              {r.title && <p className="mt-1 font-medium">{r.title}</p>}
              <p className="mt-1 text-sm text-stone-600">{r.body}</p>
            </li>
          ))}
        </ul>
        <ReviewForm
          productId={product.id}
          labels={{ writeReview: dict.product.writeReview, title: dict.product.rating }}
        />
      </section>

      <section className="mt-16">
        <h2 className="mb-8 font-serif text-3xl">{dict.product.related}</h2>
        <ProductGrid
          items={related.items.filter((i) => i.product.id !== product.id).slice(0, 4)}
          locale={locale}
          empty={dict.search.empty}
        />
      </section>
    </main>
  );
}
