import { cookies } from "next/headers";
import { ContactForm } from "@/components/client-ui";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { loc, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ContactPage() {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  return (
    <main className="container-mz grid gap-12 py-12 md:grid-cols-2">
      <div>
        <h1 className="font-serif text-4xl">{dict.pages.contact}</h1>
        <p className="mt-4 text-stone-600">{loc(settings.businessHours, locale)}</p>
        <p className="mt-4 text-sm leading-relaxed">
          {settings.address}
          <br />
          {settings.city}, {settings.country}
          <br />
          {settings.contactPhone}
          <br />
          {settings.contactEmail}
        </p>
        {settings.whatsapp && (
          <a
            className="mt-6 inline-block border border-[var(--mz-ink)] px-6 py-3 text-[12px] tracking-[0.16em] uppercase"
            href={`https://wa.me/${settings.whatsapp.replace(/\D/g, "")}`}
            target="_blank"
            rel="noreferrer"
          >
            {dict.pages.whatsapp}
          </a>
        )}
      </div>
      <ContactForm
        labels={{
          name: dict.checkout.name,
          email: dict.checkout.email,
          phone: dict.checkout.phone,
          send: dict.pages.send,
          sent: dict.pages.sent,
        }}
      />
    </main>
  );
}
