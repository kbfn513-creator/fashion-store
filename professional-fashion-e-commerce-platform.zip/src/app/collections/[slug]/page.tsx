import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { collections } from "@/db/schema";
import { FilterBar } from "@/components/client-ui";
import { Pagination, ProductGrid } from "@/components/catalog";
import { t } from "@/lib/i18n";
import { getFilterFacets, listProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { loc, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function CollectionPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { slug } = await params;
  const [col] = await db.select().from(collections).where(eq(collections.slug, slug)).limit(1);
  if (!col) notFound();
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const sp = await searchParams;
  const get = (k: string) => (typeof sp[k] === "string" ? (sp[k] as string) : undefined);
  const result = await listProducts({
    collectionSlug: slug,
    size: get("size"),
    color: get("color"),
    inStock: get("inStock") === "1",
    sort: get("sort"),
    page: Number(get("page") || 1),
  });
  const facets = await getFilterFacets(result.items.map((i) => i.product.id));
  return (
    <main className="container-mz py-12">
      <h1 className="font-serif text-4xl">{loc(col.name, locale)}</h1>
      <p className="mt-3 max-w-2xl text-stone-600">{loc(col.description, locale)}</p>
      <p className="mt-2 text-sm text-stone-500">
        {result.total} {dict.filters.products}
      </p>
      <FilterBar
        action={`/collections/${slug}`}
        sizes={facets.sizes}
        colors={facets.colors}
        brands={facets.brands}
        labels={dict.filters}
      />
      <ProductGrid items={result.items} locale={locale} empty={dict.search.empty} />
      <Pagination page={result.page} pageSize={result.pageSize} total={result.total} href={`/collections/${slug}`} />
    </main>
  );
}
