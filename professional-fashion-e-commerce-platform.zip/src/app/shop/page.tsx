import { cookies } from "next/headers";
import { FilterBar } from "@/components/client-ui";
import { Pagination, ProductGrid } from "@/components/catalog";
import { t } from "@/lib/i18n";
import { getFilterFacets, listProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ShopPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const sp = await searchParams;
  const get = (k: string) => (typeof sp[k] === "string" ? (sp[k] as string) : undefined);
  const result = await listProducts({
    q: get("q"),
    size: get("size"),
    color: get("color"),
    brand: get("brand"),
    inStock: get("inStock") === "1",
    minPrice: get("minPrice") ? Math.round(Number(get("minPrice")) * 100) : undefined,
    maxPrice: get("maxPrice") ? Math.round(Number(get("maxPrice")) * 100) : undefined,
    sort: get("sort"),
    page: Number(get("page") || 1),
  });
  const facets = await getFilterFacets();
  return (
    <main className="container-mz py-12">
      <p className="text-[11px] tracking-[0.2em] uppercase">{dict.nav.shop}</p>
      <h1 className="mt-2 font-serif text-4xl">{dict.nav.shop}</h1>
      <p className="mt-2 text-sm text-stone-500">
        {result.total} {dict.filters.products}
      </p>
      <FilterBar action="/shop" sizes={facets.sizes} colors={facets.colors} brands={facets.brands} labels={dict.filters} />
      <ProductGrid items={result.items} locale={locale} empty={dict.search.empty} />
      <Pagination page={result.page} pageSize={result.pageSize} total={result.total} href="/shop" />
    </main>
  );
}
