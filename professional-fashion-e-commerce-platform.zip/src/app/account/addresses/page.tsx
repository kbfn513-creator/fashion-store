import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { saveAddressAction } from "@/app/actions";
import { db } from "@/db";
import { addresses } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AddressesPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const rows = await db.select().from(addresses).where(eq(addresses.userId, user.id));
  return (
    <main className="container-mz py-12">
      <h1 className="font-serif text-4xl">{dict.account.addresses}</h1>
      <ul className="mt-6 space-y-3 text-sm">
        {rows.map((a) => (
          <li key={a.id} className="border border-[var(--mz-line)] p-4">
            {a.fullName} · {a.phone}
            <br />
            {a.street}, {a.city}, {a.region}, {a.country}
          </li>
        ))}
      </ul>
      <form action={async (fd) => { await saveAddressAction(fd); }} className="mt-8 max-w-lg space-y-3">
        <input name="fullName" defaultValue={user.name} required className="w-full border-b bg-transparent py-2 outline-none" />
        <input name="phone" required placeholder={dict.checkout.phone} className="w-full border-b bg-transparent py-2 outline-none" />
        <input name="street" required placeholder={dict.checkout.street} className="w-full border-b bg-transparent py-2 outline-none" />
        <input name="city" required placeholder={dict.checkout.city} className="w-full border-b bg-transparent py-2 outline-none" />
        <input name="region" required placeholder={dict.checkout.region} className="w-full border-b bg-transparent py-2 outline-none" />
        <input name="postalCode" placeholder={dict.checkout.postal} className="w-full border-b bg-transparent py-2 outline-none" />
        <input name="country" defaultValue="Morocco" className="w-full border-b bg-transparent py-2 outline-none" />
        <button className="bg-[var(--mz-ink)] px-6 py-2 text-[12px] tracking-[0.16em] text-[var(--mz-bg)] uppercase">
          {dict.account.save}
        </button>
      </form>
    </main>
  );
}
