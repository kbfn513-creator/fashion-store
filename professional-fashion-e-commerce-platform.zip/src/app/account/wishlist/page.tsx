import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { wishlists } from "@/db/schema";
import { ProductGrid } from "@/components/catalog";
import { getSessionUser } from "@/lib/auth";
import { t } from "@/lib/i18n";
import { getProductCardData } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function WishlistPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const rows = await db.select().from(wishlists).where(eq(wishlists.userId, user.id));
  const cards = await getProductCardData(rows.map((r) => r.productId));
  return (
    <main className="container-mz py-12">
      <h1 className="font-serif text-4xl">{dict.account.wishlist}</h1>
      <div className="mt-8">
        <ProductGrid items={cards} locale={locale} empty={dict.account.emptyWishlist} />
      </div>
    </main>
  );
}
