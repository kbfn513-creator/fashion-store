import Link from "next/link";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { redirect } from "next/navigation";
import { deleteAccountAction, logoutAction, updateProfileAction } from "@/app/actions";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { formatDate, formatMoney, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const myOrders = await db.select().from(orders).where(eq(orders.userId, user.id));
  const spent = myOrders.reduce((s, o) => s + o.total, 0);
  return (
    <main className="container-mz py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-[11px] tracking-[0.2em] uppercase">{dict.account.welcome}</p>
          <h1 className="font-serif text-4xl">{user.name}</h1>
        </div>
        <form action={logoutAction}>
          <button className="text-sm underline">{dict.account.logout}</button>
        </form>
      </div>
      <nav className="mt-6 flex gap-5 text-[12px] tracking-[0.16em] uppercase">
        <Link href="/account">{dict.account.profile}</Link>
        <Link href="/account/wishlist">{dict.account.wishlist}</Link>
        <Link href="/account/addresses">{dict.account.addresses}</Link>
      </nav>
      <p className="mt-4 text-sm text-stone-500">
        {myOrders.length} {dict.account.orders} · {formatMoney(spent, locale)}
      </p>
      <form action={async (fd) => { await updateProfileAction(fd); }} className="mt-8 max-w-lg space-y-4">
        <input name="name" defaultValue={user.name} className="w-full border-b bg-transparent py-2 outline-none" />
        <p className="text-sm text-stone-500">{user.email}</p>
        <input name="phone" placeholder={dict.account.phone} className="w-full border-b bg-transparent py-2 outline-none" />
        <button className="bg-[var(--mz-ink)] px-6 py-2 text-[12px] tracking-[0.16em] text-[var(--mz-bg)] uppercase">
          {dict.account.save}
        </button>
      </form>
      <h2 className="mt-12 font-serif text-2xl">{dict.account.orders}</h2>
      {myOrders.length === 0 ? (
        <p className="mt-4 text-stone-500">{dict.account.emptyOrders}</p>
      ) : (
        <ul className="mt-4 divide-y">
          {myOrders.map((o) => (
            <li key={o.id} className="flex justify-between py-3 text-sm">
              <Link href={`/order/${o.orderNumber}`}>{o.orderNumber}</Link>
              <span>
                {dict.status[o.status as keyof typeof dict.status]} · {formatMoney(o.total, locale)} ·{" "}
                {formatDate(o.createdAt, locale)}
              </span>
            </li>
          ))}
        </ul>
      )}
      <form action={async () => { await deleteAccountAction(); }} className="mt-12">
        <button className="text-xs text-red-800">{dict.account.deleteAccount}</button>
      </form>
    </main>
  );
}
