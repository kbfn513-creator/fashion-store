import Link from "next/link";
import { cookies } from "next/headers";
import { AuthForm } from "@/components/client-ui";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  return (
    <main className="container-mz py-16">
      <h1 className="text-center font-serif text-4xl">{dict.account.register}</h1>
      <AuthForm mode="register" labels={dict.account} />
      <p className="mt-6 text-center text-sm">
        {dict.account.hasAccount} <Link href="/login">{dict.account.login}</Link>
      </p>
    </main>
  );
}
