import Link from "next/link";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { banners, collections } from "@/db/schema";
import { ProductGrid } from "@/components/catalog";
import { t } from "@/lib/i18n";
import { listProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { loc, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const [hero] = await db.select().from(banners).where(eq(banners.key, "hero")).limit(1);
  const cols = await db.select().from(collections).where(eq(collections.isActive, true));
  const featured = await listProducts({ featured: true, pageSize: 8 });
  const arrivals = await listProducts({ newArrival: true, pageSize: 8 });
  const best = await listProducts({ bestSeller: true, pageSize: 8 });
  const sale = await listProducts({ collectionSlug: "sale", pageSize: 4 });

  return (
    <main>
      <section className="relative min-h-[78vh] overflow-hidden">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={hero?.image || settings.heroImage}
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/15 to-transparent" />
        <div className="container-mz relative flex min-h-[78vh] items-end pb-16 text-white">
          <div className="max-w-xl">
            <p className="text-[11px] tracking-[0.28em] uppercase">{loc(settings.tagline, locale)}</p>
            <h1 className="mt-3 font-serif text-5xl md:text-7xl">{loc(hero?.title || settings.seoTitle, locale)}</h1>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-white/85">
              {loc(hero?.subtitle || settings.seoDescription, locale)}
            </p>
            <Link
              href={hero?.ctaHref || "/shop"}
              className="mt-8 inline-block border border-white px-8 py-3 text-[12px] tracking-[0.22em] uppercase"
            >
              {loc(hero?.ctaLabel, locale) || dict.hero.shopNow}
            </Link>
          </div>
        </div>
      </section>

      <section className="container-mz py-16">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-serif text-3xl md:text-4xl">{dict.common.featured}</h2>
          <Link href="/shop" className="text-[11px] tracking-[0.18em] uppercase">
            {dict.common.viewAll}
          </Link>
        </div>
        <ProductGrid items={featured.items} locale={locale} empty={dict.search.empty} />
      </section>

      <section className="container-mz grid gap-4 py-6 md:grid-cols-3">
        {cols.slice(0, 3).map((c) => (
          <Link key={c.id} href={`/collections/${c.slug}`} className="group relative min-h-72 overflow-hidden bg-[var(--mz-muted)]">
            {c.image && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={c.image} alt="" className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-105" />
            )}
            <div className="absolute inset-0 bg-black/25" />
            <div className="relative flex h-full min-h-72 items-end p-6 text-white">
              <div>
                <p className="font-serif text-3xl">{loc(c.name, locale)}</p>
                <p className="mt-1 text-sm text-white/80">{loc(c.description, locale)}</p>
              </div>
            </div>
          </Link>
        ))}
      </section>

      <section className="container-mz py-16">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-serif text-3xl md:text-4xl">{dict.common.newArrivals}</h2>
          <Link href="/collections/new-arrivals" className="text-[11px] tracking-[0.18em] uppercase">
            {dict.common.viewAll}
          </Link>
        </div>
        <ProductGrid items={arrivals.items} locale={locale} empty={dict.search.empty} />
      </section>

      <section className="bg-[var(--mz-ink)] py-20 text-[var(--mz-bg)]">
        <div className="container-mz grid items-center gap-10 md:grid-cols-2">
          <div>
            <p className="text-[11px] tracking-[0.28em] uppercase">{dict.common.campaign}</p>
            <h2 className="mt-3 font-serif text-4xl md:text-5xl">{loc(settings.tagline, locale)}</h2>
            <p className="mt-4 max-w-md text-sm leading-relaxed text-[var(--mz-bg)]/75">
              {loc(settings.seoDescription, locale)}
            </p>
            <Link href="/collections/autumn-atelier" className="mt-8 inline-block border border-[var(--mz-bg)] px-8 py-3 text-[12px] tracking-[0.22em] uppercase">
              {dict.hero.explore}
            </Link>
          </div>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/images/products/wool-coat.jpg" alt="" className="h-[420px] w-full object-cover" />
        </div>
      </section>

      <section className="container-mz py-16">
        <div className="mb-8 flex items-end justify-between">
          <h2 className="font-serif text-3xl md:text-4xl">{dict.common.bestsellers}</h2>
          <Link href="/collections/bestsellers" className="text-[11px] tracking-[0.18em] uppercase">
            {dict.common.viewAll}
          </Link>
        </div>
        <ProductGrid items={best.items} locale={locale} empty={dict.search.empty} />
      </section>

      {sale.items.length > 0 && (
        <section className="container-mz pb-20">
          <h2 className="mb-8 font-serif text-3xl">{dict.nav.sale}</h2>
          <ProductGrid items={sale.items} locale={locale} empty={dict.search.empty} />
        </section>
      )}
    </main>
  );
}
