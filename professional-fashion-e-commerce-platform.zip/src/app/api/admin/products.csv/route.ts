import { getSessionUser, isStaff } from "@/lib/auth";
import { db } from "@/db";
import { products, productVariants } from "@/db/schema";
import { csvEscape } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!isStaff(user)) return new Response("Unauthorized", { status: 401 });
  const rows = await db.select().from(products);
  const variants = await db.select().from(productVariants);
  const header = ["sku", "slug", "name_fr", "status", "price", "sale_price", "variant_sku", "size", "color", "stock"];
  const lines = [header.join(",")];
  for (const p of rows) {
    const vs = variants.filter((v) => v.productId === p.id);
    if (!vs.length) {
      lines.push(
        [p.sku, p.slug, p.name.fr, p.status, (p.price / 100).toFixed(2), p.salePrice ? (p.salePrice / 100).toFixed(2) : "", "", "", "", ""].map(csvEscape).join(","),
      );
    } else {
      for (const v of vs) {
        lines.push(
          [
            p.sku,
            p.slug,
            p.name.fr,
            p.status,
            ((v.price ?? p.price) / 100).toFixed(2),
            (v.salePrice ?? p.salePrice) ? ((v.salePrice ?? p.salePrice)! / 100).toFixed(2) : "",
            v.sku,
            v.size || "",
            v.color || "",
            String(v.stock),
          ].map(csvEscape).join(","),
        );
      }
    }
  }
  return new Response(lines.join("\n"), {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": "attachment; filename=maison-zahra-products.csv",
    },
  });
}
