import { NextRequest } from "next/server";
import { searchProducts } from "@/lib/commerce";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const q = request.nextUrl.searchParams.get("q") || "";
  const items = await searchProducts(q, 8);
  return Response.json(
    items.map((p) => ({
      slug: p.slug,
      name: p.name,
      image: p.image,
    })),
  );
}
