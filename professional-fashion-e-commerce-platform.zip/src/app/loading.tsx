export default function Loading() {
  return (
    <div className="container-mz py-24 text-center text-sm tracking-[0.2em] uppercase text-stone-500">
      Loading…
    </div>
  );
}
