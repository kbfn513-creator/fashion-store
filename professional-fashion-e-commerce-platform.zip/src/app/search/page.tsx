import { cookies } from "next/headers";
import { ProductGrid } from "@/components/catalog";
import { t } from "@/lib/i18n";
import { listProducts } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import { parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : "";
  const result = await listProducts({ q, pageSize: 24 });
  return (
    <main className="container-mz py-12">
      <h1 className="font-serif text-4xl">{dict.search.results}</h1>
      <form className="mt-6">
        <input
          name="q"
          defaultValue={q}
          placeholder={dict.search.placeholder}
          className="w-full max-w-xl border-b border-[var(--mz-ink)] bg-transparent py-3 outline-none"
        />
      </form>
      <p className="mt-4 text-sm text-stone-500">
        {q ? `${result.total} · “${q}”` : ""}
      </p>
      <div className="mt-8">
        <ProductGrid items={result.items} locale={locale} empty={dict.search.empty} />
      </div>
    </main>
  );
}
