import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { pages } from "@/db/schema";
import { getSettings } from "@/lib/settings";
import { loc, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function CmsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [page] = await db.select().from(pages).where(eq(pages.slug, slug)).limit(1);
  if (!page || !page.isPublished) notFound();
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  return (
    <main className="container-mz max-w-3xl py-16">
      <h1 className="font-serif text-4xl">{loc(page.title, locale)}</h1>
      <article className="mt-8 whitespace-pre-line text-sm leading-8 text-stone-700">{loc(page.body, locale)}</article>
    </main>
  );
}
