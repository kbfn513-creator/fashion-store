import { cookies } from "next/headers";
import { forgotPasswordAction } from "@/app/actions";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ForgotPage() {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  return (
    <main className="container-mz max-w-md py-16">
      <h1 className="font-serif text-4xl">{dict.account.reset}</h1>
      <p className="mt-3 text-sm text-stone-600">{dict.account.resetHint}</p>
      <form action={async (fd) => { await forgotPasswordAction(fd); }} className="mt-8 space-y-4">
        <input name="email" type="email" required placeholder={dict.account.email} className="w-full border-b bg-transparent py-3 outline-none" />
        <button className="w-full bg-[var(--mz-ink)] py-3 text-[12px] tracking-[0.2em] text-[var(--mz-bg)] uppercase">
          {dict.account.reset}
        </button>
      </form>
    </main>
  );
}
