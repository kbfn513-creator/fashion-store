import Link from "next/link";
import { cookies } from "next/headers";
import { AuthForm } from "@/components/client-ui";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const sp = await searchParams;
  const next = typeof sp.next === "string" ? sp.next : "/account";
  return (
    <main className="container-mz py-16">
      <h1 className="text-center font-serif text-4xl">{dict.account.login}</h1>
      <AuthForm mode="login" next={next} labels={dict.account} />
      <p className="mt-6 text-center text-sm">
        <Link href="/forgot-password">{dict.account.forgot}</Link>
      </p>
      <p className="mt-3 text-center text-sm">
        {dict.account.noAccount} <Link href="/register">{dict.account.register}</Link>
      </p>
    </main>
  );
}
