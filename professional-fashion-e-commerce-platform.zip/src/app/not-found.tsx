import Link from "next/link";

export default function NotFound() {
  return (
    <main className="container-mz grid min-h-[60vh] place-items-center py-20 text-center">
      <div>
        <p className="text-[11px] tracking-[0.2em] uppercase">404</p>
        <h1 className="mt-3 font-serif text-4xl">This page has left the atelier.</h1>
        <Link href="/" className="mt-6 inline-block underline">
          Home
        </Link>
      </div>
    </main>
  );
}
