import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cormorant_Garamond, Outfit } from "next/font/google";
import { cookies, headers } from "next/headers";
import "./globals.css";
import { Footer, Header, MaintenanceGate } from "@/components/storefront";
import { ensureSeeded } from "@/db/seed";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import type { Locale } from "@/lib/types";
import { loc, parseLocale } from "@/lib/utils";

const serif = Cormorant_Garamond({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-serif",
  display: "swap",
});

const sans = Outfit({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-sans",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  try {
    await ensureSeeded();
    const settings = await getSettings();
    const store = await cookies();
    const locale = parseLocale(store.get("locale")?.value || settings.defaultLocale);
    return {
      title: {
        default: loc(settings.seoTitle, locale) || settings.storeName,
        template: `%s · ${settings.storeName}`,
      },
      description: loc(settings.seoDescription, locale),
      icons: settings.faviconUrl ? [{ rel: "icon", url: settings.faviconUrl }] : undefined,
      openGraph: {
        title: loc(settings.seoTitle, locale),
        description: loc(settings.seoDescription, locale),
        locale: locale === "ar" ? "ar_MA" : locale === "fr" ? "fr_MA" : "en_MA",
        type: "website",
      },
    };
  } catch {
    return { title: "Maison Zahra" };
  }
}

export default async function RootLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const settings = await getSettings();
  const store = await cookies();
  const locale = parseLocale(store.get("locale")?.value || settings.defaultLocale) as Locale;
  const dir = locale === "ar" ? "rtl" : "ltr";
  const dict = t(locale);
  const path = (await headers()).get("x-mz-path") || "";
  const isAdmin = path.startsWith("/admin");

  return (
    <html lang={locale} dir={dir} className={`${serif.variable} ${sans.variable}`}>
      <body
        className="min-h-screen antialiased"
        style={{
          ["--mz-bg" as string]: settings.backgroundColor,
          ["--mz-ink" as string]: settings.textColor,
          ["--mz-accent" as string]: settings.accentColor,
          ["--mz-muted" as string]: settings.mutedColor,
          background: isAdmin ? "#f4f1ec" : settings.backgroundColor,
          color: settings.textColor,
        }}
      >
        {isAdmin ? (
          children
        ) : (
          <MaintenanceGate enabled={settings.maintenanceMode} message={dict.common.maintenance}>
            <Header locale={locale} />
            {children}
            <Footer locale={locale} />
          </MaintenanceGate>
        )}
      </body>
    </html>
  );
}
