"use server";

import { revalidatePath } from "next/cache";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  addresses,
  contactMessages,
  newsletterSubscribers,
  passwordResetTokens,
  products,
  reviews,
  users,
  wishlists,
} from "@/db/schema";
import { createSession, destroySession, getSessionUser, hashPassword, randomToken, sha256, verifyPassword } from "@/lib/auth";
import { addToCart, applyCoupon, getCartView, placeOrder, updateCartItem } from "@/lib/commerce";
import { rateLimit } from "@/lib/rate-limit";
import { getSettings } from "@/lib/settings";
import type { Locale } from "@/lib/types";
import { getClientIp, moroccoPhoneValid, parseLocale } from "@/lib/utils";

async function sameOrigin(): Promise<boolean> {
  const h = await headers();
  const origin = h.get("origin");
  const host = h.get("host");
  if (!origin || !host) return true;
  try {
    return new URL(origin).host === host;
  } catch {
    return false;
  }
}

export async function setLocaleAction(locale: Locale) {
  const store = await cookies();
  store.set("locale", parseLocale(locale), { path: "/", maxAge: 60 * 60 * 24 * 365 });
  revalidatePath("/");
}

export async function addToCartAction(formData: FormData) {
  if (!(await sameOrigin())) return { error: "Invalid request" };
  const variantId = String(formData.get("variantId") || "");
  const quantity = Number(formData.get("quantity") || 1);
  try {
    await addToCart(variantId, quantity);
    revalidatePath("/cart");
    return { ok: true };
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Unable to add" };
  }
}

export async function updateCartAction(formData: FormData) {
  const itemId = String(formData.get("itemId") || "");
  const quantity = Number(formData.get("quantity") || 0);
  try {
    await updateCartItem(itemId, quantity);
    revalidatePath("/cart");
    revalidatePath("/checkout");
    return { ok: true };
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Unable to update" };
  }
}

export async function applyCouponAction(formData: FormData) {
  const code = String(formData.get("code") || "");
  try {
    await applyCoupon(code);
    revalidatePath("/cart");
    revalidatePath("/checkout");
    return { ok: true };
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Invalid coupon" };
  }
}

export async function checkoutAction(formData: FormData) {
  if (!(await sameOrigin())) return { error: "Invalid request" };
  const ip = await getClientIp();
  const limited = rateLimit(`checkout:${ip}`, 8, 10 * 60 * 1000);
  if (!limited.ok) return { error: "Too many attempts. Please wait." };
  try {
    const order = await placeOrder({
      name: String(formData.get("name") || ""),
      email: String(formData.get("email") || ""),
      phone: String(formData.get("phone") || ""),
      street: String(formData.get("street") || ""),
      city: String(formData.get("city") || ""),
      region: String(formData.get("region") || ""),
      postalCode: String(formData.get("postalCode") || ""),
      country: String(formData.get("country") || "Morocco"),
      note: String(formData.get("note") || ""),
      paymentMethod: "cod",
      idempotencyKey: String(formData.get("idempotencyKey") || crypto.randomUUID()),
      locale: parseLocale(String(formData.get("locale") || "fr")),
    });
    revalidatePath("/admin");
    redirect(`/order/${order.orderNumber}`);
  } catch (e) {
    return { error: e instanceof Error ? e.message : "Checkout failed" };
  }
}

export async function registerAction(formData: FormData) {
  const ip = await getClientIp();
  if (!rateLimit(`register:${ip}`, 5, 15 * 60 * 1000).ok) return { error: "Too many attempts." };
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const phone = String(formData.get("phone") || "").trim();
  const password = String(formData.get("password") || "");
  if (!name || !email || !password) return { error: "Missing fields" };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: "Invalid email" };
  if (password.length < 8) return { error: "Password must be at least 8 characters" };
  if (phone && !moroccoPhoneValid(phone)) return { error: "Invalid phone" };
  const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing) return { error: "An account with this email already exists." };
  const passwordHash = await hashPassword(password);
  const [user] = await db
    .insert(users)
    .values({
      name,
      email,
      phone: phone || null,
      passwordHash,
      role: "customer",
      status: "active",
    })
    .returning();
  await createSession({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    permissions: [],
  });
  redirect("/account");
}

export async function loginAction(formData: FormData) {
  const ip = await getClientIp();
  if (!rateLimit(`login:${ip}`, 8, 15 * 60 * 1000).ok) return { error: "Too many attempts." };
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");
  const next = String(formData.get("next") || "/account");
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user || user.status !== "active") return { error: "Invalid email or password." };
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) return { error: "Invalid email or password." };
  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
  await createSession({
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    permissions: user.permissions || [],
  });
  if (user.role === "admin" || user.role === "staff") {
    redirect(next.startsWith("/admin") ? next : "/admin");
  }
  redirect(next.startsWith("/") && !next.startsWith("//") ? next : "/account");
}

export async function logoutAction() {
  await destroySession();
  redirect("/");
}

export async function forgotPasswordAction(formData: FormData) {
  const ip = await getClientIp();
  if (!rateLimit(`forgot:${ip}`, 5, 15 * 60 * 1000).ok) return { error: "Too many attempts." };
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (user) {
    const token = randomToken();
    await db.insert(passwordResetTokens).values({
      userId: user.id,
      tokenHash: sha256(token),
      expiresAt: new Date(Date.now() + 60 * 60 * 1000),
    });
    if (!process.env.SMTP_HOST) {
      console.info("Password reset token created. SMTP is not configured; email was not sent.");
    }
  }
  return { ok: true };
}

export async function resetPasswordAction(formData: FormData) {
  const token = String(formData.get("token") || "");
  const password = String(formData.get("password") || "");
  if (password.length < 8) return { error: "Password must be at least 8 characters" };
  const [row] = await db
    .select()
    .from(passwordResetTokens)
    .where(eq(passwordResetTokens.tokenHash, sha256(token)))
    .limit(1);
  if (!row || row.usedAt || row.expiresAt.getTime() < Date.now()) return { error: "Invalid or expired token" };
  const passwordHash = await hashPassword(password);
  await db.update(users).set({ passwordHash, updatedAt: new Date() }).where(eq(users.id, row.userId));
  await db.update(passwordResetTokens).set({ usedAt: new Date() }).where(eq(passwordResetTokens.id, row.id));
  return { ok: true };
}

export async function toggleWishlistAction(productId: string) {
  const user = await getSessionUser();
  if (!user) return { error: "auth" };
  const [existing] = await db
    .select()
    .from(wishlists)
    .where(and(eq(wishlists.userId, user.id), eq(wishlists.productId, productId)))
    .limit(1);
  if (existing) await db.delete(wishlists).where(eq(wishlists.id, existing.id));
  else await db.insert(wishlists).values({ userId: user.id, productId });
  revalidatePath("/account/wishlist");
  return { ok: true, saved: !existing };
}

export async function saveAddressAction(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  const phone = String(formData.get("phone") || "");
  if (!moroccoPhoneValid(phone)) return { error: "Invalid phone" };
  await db.insert(addresses).values({
    userId: user.id,
    fullName: String(formData.get("fullName") || user.name),
    phone,
    street: String(formData.get("street") || ""),
    city: String(formData.get("city") || ""),
    region: String(formData.get("region") || ""),
    postalCode: String(formData.get("postalCode") || ""),
    country: String(formData.get("country") || "Morocco"),
    isDefault: true,
  });
  revalidatePath("/account");
  return { ok: true };
}

export async function updateProfileAction(formData: FormData) {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  await db
    .update(users)
    .set({
      name: String(formData.get("name") || user.name),
      phone: String(formData.get("phone") || "") || null,
      updatedAt: new Date(),
    })
    .where(eq(users.id, user.id));
  revalidatePath("/account");
  return { ok: true };
}

export async function deleteAccountAction() {
  const user = await getSessionUser();
  if (!user || user.role !== "customer") return { error: "Not allowed" };
  await db.delete(users).where(eq(users.id, user.id));
  await destroySession();
  redirect("/");
}

export async function contactAction(formData: FormData) {
  const ip = await getClientIp();
  if (!rateLimit(`contact:${ip}`, 5, 15 * 60 * 1000).ok) return { error: "Too many attempts." };
  const website = String(formData.get("website") || "");
  if (website) return { ok: true };
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const subject = String(formData.get("subject") || "").trim();
  const message = String(formData.get("message") || "").trim();
  if (!name || !email || !subject || !message) return { error: "Missing fields" };
  await db.insert(contactMessages).values({
    name,
    email,
    phone: String(formData.get("phone") || "") || null,
    subject,
    message,
  });
  return { ok: true };
}

export async function newsletterAction(formData: FormData) {
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const locale = parseLocale(String(formData.get("locale") || "fr"));
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { error: "Invalid email" };
  await db
    .insert(newsletterSubscribers)
    .values({ email, locale, consentedAt: new Date() })
    .onConflictDoNothing();
  return { ok: true };
}

export async function reviewAction(formData: FormData) {
  const user = await getSessionUser();
  if (!user) return { error: "auth" };
  const productId = String(formData.get("productId") || "");
  const rating = Number(formData.get("rating") || 0);
  const body = String(formData.get("body") || "").trim();
  if (rating < 1 || rating > 5 || body.length < 8) return { error: "Invalid review" };
  const [product] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!product) return { error: "Product not found" };
  await db.insert(reviews).values({
    productId,
    userId: user.id,
    rating,
    title: String(formData.get("title") || "") || null,
    body,
    status: "pending",
    verifiedPurchase: false,
  });
  revalidatePath(`/products/${product.slug}`);
  return { ok: true };
}

export async function quoteCartAction(city?: string) {
  return getCartView(city);
}

export async function getPublicSettings() {
  const s = await getSettings();
  return {
    storeName: s.storeName,
    currency: s.currency,
    whatsapp: s.whatsapp,
    codEnabled: s.codEnabled,
    cardEnabled: s.cardEnabled,
    freeShippingThreshold: s.freeShippingThreshold,
  };
}
