import { deleteCouponAction, saveCouponAction } from "@/app/admin/actions";
import { AdminDeleteButton } from "@/components/client-ui";
import { db } from "@/db";
import { coupons } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function PromotionsPage() {
  const rows = await db.select().from(coupons);
  return (
    <div>
      <h1 className="font-serif text-4xl">Promotions</h1>
      <form action={saveCouponAction} className="mt-6 grid max-w-3xl gap-3 md:grid-cols-3">
        <input name="code" required placeholder="CODE" className="border bg-white p-2 uppercase" />
        <select name="type" className="border bg-white p-2">
          <option value="percent">Percent (e.g. 10)</option>
          <option value="fixed">Fixed MAD</option>
          <option value="free_shipping">Free shipping</option>
        </select>
        <input name="value" type="number" step="0.01" defaultValue={10} className="border bg-white p-2" />
        <input name="minOrder" type="number" step="0.01" placeholder="Min order MAD" className="border bg-white p-2" />
        <input name="maxUses" type="number" placeholder="Max uses" className="border bg-white p-2" />
        <input name="perCustomerLimit" type="number" defaultValue={1} className="border bg-white p-2" />
        <input name="startsAt" type="datetime-local" className="border bg-white p-2" />
        <input name="endsAt" type="datetime-local" className="border bg-white p-2" />
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" name="isActive" defaultChecked /> Active
        </label>
        <button className="bg-[#1c1917] px-4 py-2 text-white md:col-span-3">Save coupon</button>
      </form>
      <ul className="mt-8 space-y-3 text-sm">
        {rows.map((c) => (
          <li key={c.id} className="flex justify-between border-b py-2">
            <span>
              {c.code} · {c.type} · {c.type === "percent" ? `${c.value / 100}%` : c.value / 100} · used {c.usedCount}
              {c.maxUses ? `/${c.maxUses}` : ""}
            </span>
            <AdminDeleteButton action={async () => { await deleteCouponAction(c.id); }} />
          </li>
        ))}
      </ul>
    </div>
  );
}
