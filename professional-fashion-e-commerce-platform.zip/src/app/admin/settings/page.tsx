import { saveSettingsAction, saveShippingZoneAction, saveStaffAction } from "@/app/admin/actions";
import { db } from "@/db";
import { shippingZones, users } from "@/db/schema";
import { getSettings } from "@/lib/settings";
import { STAFF_PERMISSIONS } from "@/lib/types";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const s = await getSettings();
  const zones = await db.select().from(shippingZones);
  const staff = await db.select().from(users).where(eq(users.role, "staff"));
  const loc3 = (key: string, value: { fr: string; ar: string; en: string }) => (
    <>
      <input name={`${key}_fr`} defaultValue={value.fr} className="border bg-white p-2" />
      <input name={`${key}_ar`} defaultValue={value.ar} className="border bg-white p-2" />
      <input name={`${key}_en`} defaultValue={value.en} className="border bg-white p-2" />
    </>
  );
  return (
    <div className="max-w-3xl space-y-12">
      <h1 className="font-serif text-4xl">Store settings</h1>
      <form action={saveSettingsAction} className="grid gap-3">
        <input name="storeName" defaultValue={s.storeName} className="border bg-white p-2" />
        <input name="logoText" defaultValue={s.logoText} className="border bg-white p-2" />
        <input name="logoUrl" defaultValue={s.logoUrl || ""} placeholder="Logo URL" className="border bg-white p-2" />
        <input name="heroImage" defaultValue={s.heroImage} className="border bg-white p-2" />
        {loc3("tagline", s.tagline)}
        {loc3("announcement", s.announcement)}
        <label>
          <input type="checkbox" name="announcementEnabled" defaultChecked={s.announcementEnabled} /> Announcement bar
        </label>
        <div className="grid grid-cols-4 gap-2">
          <input name="primaryColor" defaultValue={s.primaryColor} className="border bg-white p-2" />
          <input name="accentColor" defaultValue={s.accentColor} className="border bg-white p-2" />
          <input name="backgroundColor" defaultValue={s.backgroundColor} className="border bg-white p-2" />
          <input name="textColor" defaultValue={s.textColor} className="border bg-white p-2" />
        </div>
        <select name="defaultLocale" defaultValue={s.defaultLocale} className="border bg-white p-2">
          <option value="fr">fr</option>
          <option value="ar">ar</option>
          <option value="en">en</option>
        </select>
        <input name="currency" defaultValue={s.currency} className="border bg-white p-2" />
        <input name="country" defaultValue={s.country} className="border bg-white p-2" />
        <input name="timezone" defaultValue={s.timezone} className="border bg-white p-2" />
        <input name="taxRateBps" type="number" defaultValue={s.taxRateBps} className="border bg-white p-2" />
        <label>
          <input type="checkbox" name="taxInclusive" defaultChecked={s.taxInclusive} /> Prices include tax
        </label>
        <input name="freeShippingThreshold" type="number" step="0.01" defaultValue={s.freeShippingThreshold / 100} className="border bg-white p-2" />
        <input name="contactEmail" defaultValue={s.contactEmail} className="border bg-white p-2" />
        <input name="contactPhone" defaultValue={s.contactPhone} className="border bg-white p-2" />
        <input name="whatsapp" defaultValue={s.whatsapp} className="border bg-white p-2" />
        <input name="address" defaultValue={s.address} className="border bg-white p-2" />
        <input name="city" defaultValue={s.city} className="border bg-white p-2" />
        {loc3("businessHours", s.businessHours)}
        <input name="instagram" defaultValue={s.instagram} className="border bg-white p-2" />
        <input name="facebook" defaultValue={s.facebook} className="border bg-white p-2" />
        <input name="tiktok" defaultValue={s.tiktok} className="border bg-white p-2" />
        <input name="orderPrefix" defaultValue={s.orderPrefix} className="border bg-white p-2" />
        {loc3("invoiceFooter", s.invoiceFooter)}
        {loc3("seoTitle", s.seoTitle)}
        {loc3("seoDescription", s.seoDescription)}
        {loc3("footerNote", s.footerNote)}
        <label>
          <input type="checkbox" name="codEnabled" defaultChecked={s.codEnabled} /> Cash on delivery
        </label>
        <label>
          <input type="checkbox" name="cardEnabled" defaultChecked={s.cardEnabled} /> Card (requires gateway keys)
        </label>
        <label>
          <input type="checkbox" name="restoreStockOnCancel" defaultChecked={s.restoreStockOnCancel} /> Restore stock on cancel
        </label>
        <label>
          <input type="checkbox" name="restoreStockOnRefund" defaultChecked={s.restoreStockOnRefund} /> Restore stock on refund
        </label>
        <label>
          <input type="checkbox" name="maintenanceMode" defaultChecked={s.maintenanceMode} /> Maintenance mode
        </label>
        <input name="lowStockThreshold" type="number" defaultValue={s.lowStockThreshold} className="border bg-white p-2" />
        <button className="bg-[#1c1917] px-4 py-3 text-white">Save settings</button>
      </form>

      <section>
        <h2 className="font-serif text-3xl">Shipping zones</h2>
        {zones.map((z) => (
          <form key={z.id} action={saveShippingZoneAction} className="mt-4 grid gap-2 border-b pb-4">
            <input type="hidden" name="id" value={z.id} />
            <input name="name" defaultValue={z.name} className="border bg-white p-2" />
            <input name="cities" defaultValue={z.cities.join(", ")} className="border bg-white p-2" />
            <input name="fee" type="number" step="0.01" defaultValue={z.fee / 100} className="border bg-white p-2" />
            <input name="estimatedDays" defaultValue={z.estimatedDays} className="border bg-white p-2" />
            <label>
              <input type="checkbox" name="isActive" defaultChecked={z.isActive} /> Active
            </label>
            <button className="underline">Save zone</button>
          </form>
        ))}
        <form action={saveShippingZoneAction} className="mt-4 grid gap-2">
          <input name="name" placeholder="New zone" className="border bg-white p-2" />
          <input name="cities" placeholder="Cities, comma separated (empty = rest of country)" className="border bg-white p-2" />
          <input name="fee" type="number" step="0.01" placeholder="Fee MAD" className="border bg-white p-2" />
          <input name="estimatedDays" defaultValue="3–7" className="border bg-white p-2" />
          <label>
            <input type="checkbox" name="isActive" defaultChecked /> Active
          </label>
          <button className="underline">Add zone</button>
        </form>
      </section>

      <section>
        <h2 className="font-serif text-3xl">Staff</h2>
        <form action={saveStaffAction} className="mt-4 grid gap-2">
          <input name="name" placeholder="Name" className="border bg-white p-2" />
          <input name="email" type="email" required placeholder="Email" className="border bg-white p-2" />
          <input name="password" type="password" placeholder="Password (10+ chars)" className="border bg-white p-2" />
          <div className="flex flex-wrap gap-3 text-sm">
            {STAFF_PERMISSIONS.map((p) => (
              <label key={p}>
                <input type="checkbox" name="permission" value={p} /> {p}
              </label>
            ))}
          </div>
          <button className="bg-[#1c1917] px-4 py-2 text-white">Save staff</button>
        </form>
        <ul className="mt-4 text-sm">
          {staff.map((u) => (
            <li key={u.id}>
              {u.name} · {u.email} · {(u.permissions || []).join(", ")}
            </li>
          ))}
        </ul>
      </section>

      <section className="text-sm leading-relaxed text-stone-600">
        <h2 className="font-serif text-2xl text-stone-900">Payments & email</h2>
        <p className="mt-2">
          Cash on delivery is fully operational. Online card payments are not marked successful unless a real provider
          is connected. To enable cards later, set gateway secrets in environment variables (never in the client) and
          implement webhook signature verification in <code>/api/payments/webhook</code>.
        </p>
        <p className="mt-2">
          Order emails are not sent unless SMTP_HOST is configured. The application will not claim that a message was
          delivered when no provider is connected.
        </p>
        <p className="mt-2">
          Backups: dump PostgreSQL regularly (<code>pg_dump</code>) and store off-site. Restore with <code>psql</code>.
        </p>
      </section>
    </div>
  );
}
