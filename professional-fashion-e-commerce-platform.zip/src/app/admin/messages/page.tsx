import { desc } from "drizzle-orm";
import { markMessageReadAction } from "@/app/admin/actions";
import { db } from "@/db";
import { contactMessages, newsletterSubscribers } from "@/db/schema";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function MessagesPage() {
  const rows = await db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt));
  const news = await db.select().from(newsletterSubscribers);
  return (
    <div>
      <h1 className="font-serif text-4xl">Messages</h1>
      <ul className="mt-6 space-y-4">
        {rows.map((m) => (
          <li key={m.id} className="border-b py-3 text-sm">
            <p>
              {m.name} · {m.email} · {m.status} · {formatDate(m.createdAt, "fr")}
            </p>
            <p className="mt-1 font-medium">{m.subject}</p>
            <p className="mt-1">{m.message}</p>
            <form action={async () => { await markMessageReadAction(m.id); }}>
              <button className="mt-2 text-xs underline">Mark read</button>
            </form>
          </li>
        ))}
      </ul>
      <h2 className="mt-10 font-serif text-2xl">Newsletter consent</h2>
      <ul className="mt-3 text-sm">
        {news.map((n) => (
          <li key={n.id}>
            {n.email} · {n.locale} · {n.unsubscribedAt ? "unsubscribed" : "subscribed"}
          </li>
        ))}
      </ul>
    </div>
  );
}
