import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { formatMoney } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminOrdersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : "";
  const status = typeof sp.status === "string" ? sp.status : "";
  let rows = await db.select().from(orders).orderBy(desc(orders.createdAt));
  if (status) rows = rows.filter((o) => o.status === status);
  if (q) {
    const n = q.toLowerCase();
    rows = rows.filter(
      (o) =>
        o.orderNumber.toLowerCase().includes(n) ||
        o.email.toLowerCase().includes(n) ||
        o.phone.includes(q) ||
        o.customerName.toLowerCase().includes(n),
    );
  }
  return (
    <div>
      <h1 className="font-serif text-4xl">Orders</h1>
      <form className="mt-4 flex gap-3 text-sm">
        <input name="q" defaultValue={q} placeholder="Search number, email, phone" className="border bg-white/80 px-3 py-2" />
        <select name="status" defaultValue={status} className="border bg-white/80 px-3 py-2">
          <option value="">All</option>
          {["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "returned"].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <button className="border px-3">Filter</button>
      </form>
      <table className="mt-6 w-full text-left text-sm">
        <thead>
          <tr className="border-b text-[11px] uppercase tracking-[0.14em] text-stone-500">
            <th className="py-2">Order</th>
            <th>Customer</th>
            <th>Status</th>
            <th>Payment</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((o) => (
            <tr key={o.id} className="border-b">
              <td className="py-3">
                <Link href={`/admin/orders/${o.id}`}>{o.orderNumber}</Link>
              </td>
              <td>
                {o.customerName}
                <br />
                <span className="text-xs text-stone-500">{o.email}</span>
              </td>
              <td>{o.status}</td>
              <td>
                {o.paymentMethod} / {o.paymentStatus}
              </td>
              <td>{formatMoney(o.total, "fr")}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
