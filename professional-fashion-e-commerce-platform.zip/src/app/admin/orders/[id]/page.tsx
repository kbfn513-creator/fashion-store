import Link from "next/link";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { recordRefundAction, saveOrderNoteAction, saveShipmentAction, updateOrderStatusAction } from "@/app/admin/actions";
import { db } from "@/db";
import { orderItems, orderStatusHistory, orders, payments, refunds, shipments } from "@/db/schema";
import { formatDate, formatMoney } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminOrderDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (!order) notFound();
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
  const history = await db.select().from(orderStatusHistory).where(eq(orderStatusHistory.orderId, id));
  const pays = await db.select().from(payments).where(eq(payments.orderId, id));
  const ships = await db.select().from(shipments).where(eq(shipments.orderId, id));
  const refs = await db.select().from(refunds).where(eq(refunds.orderId, id));
  const addr = order.shippingAddress;
  return (
    <div className="max-w-4xl">
      <div className="flex items-center justify-between">
        <h1 className="font-serif text-4xl">{order.orderNumber}</h1>
        <Link href={`/admin/orders/${order.id}/invoice`} className="underline">
          Invoice / packing slip
        </Link>
      </div>
      <p className="mt-2 text-sm text-stone-500">
        {order.customerName} · {order.email} · {order.phone}
      </p>
      <p className="mt-1 text-sm">
        {addr.street}, {addr.city}, {addr.region}, {addr.country}
      </p>
      <form action={updateOrderStatusAction} className="mt-6 flex flex-wrap gap-3">
        <input type="hidden" name="orderId" value={order.id} />
        <select name="status" defaultValue={order.status} className="border bg-white p-2">
          {["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "returned"].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <input name="note" placeholder="Note to history" className="border bg-white px-3" />
        <button className="bg-[#1c1917] px-4 py-2 text-white">Update status</button>
      </form>
      <ul className="mt-8 divide-y text-sm">
        {items.map((i) => (
          <li key={i.id} className="flex justify-between py-3">
            <span>
              {i.name} · {i.sku} · {i.color} · {i.size} × {i.quantity}
            </span>
            <span>{formatMoney(i.total, "fr")}</span>
          </li>
        ))}
      </ul>
      <dl className="mt-4 space-y-1 text-sm">
        <div className="flex justify-between">
          <dt>Subtotal</dt>
          <dd>{formatMoney(order.subtotal, "fr")}</dd>
        </div>
        <div className="flex justify-between">
          <dt>Discount</dt>
          <dd>-{formatMoney(order.discount, "fr")}</dd>
        </div>
        <div className="flex justify-between">
          <dt>Shipping</dt>
          <dd>{formatMoney(order.shippingFee, "fr")}</dd>
        </div>
        <div className="flex justify-between font-medium">
          <dt>Total</dt>
          <dd>{formatMoney(order.total, "fr")}</dd>
        </div>
      </dl>
      <form action={saveShipmentAction} className="mt-8 grid gap-2 md:grid-cols-4">
        <input type="hidden" name="orderId" value={order.id} />
        <input name="carrier" placeholder="Carrier" className="border bg-white p-2" />
        <input name="trackingNumber" placeholder="Tracking (manual)" className="border bg-white p-2" />
        <input name="estimatedDays" placeholder="ETA days" className="border bg-white p-2" />
        <button className="bg-[#1c1917] text-white">Record shipment</button>
      </form>
      <p className="mt-2 text-xs text-stone-500">Tracking is recorded manually. Live carrier tracking is not connected.</p>
      {ships.map((s) => (
        <p key={s.id} className="mt-2 text-sm">
          {s.carrier} · {s.trackingNumber} · {s.shippedAt ? formatDate(s.shippedAt, "fr") : ""}
        </p>
      ))}
      <form action={saveOrderNoteAction} className="mt-8">
        <input type="hidden" name="orderId" value={order.id} />
        <textarea name="internalNote" defaultValue={order.internalNote || ""} className="w-full border bg-white p-3" />
        <button className="mt-2 underline">Save internal note</button>
      </form>
      <form action={recordRefundAction} className="mt-8 flex gap-2">
        <input type="hidden" name="orderId" value={order.id} />
        <input name="amount" type="number" step="0.01" placeholder="Refund MAD" className="border bg-white p-2" />
        <input name="reason" placeholder="Reason" className="border bg-white p-2" />
        <button className="border px-3">Record refund</button>
      </form>
      <p className="mt-2 text-xs text-stone-500">
        COD refunds are recorded in the ledger only. Card refunds require a connected payment provider.
      </p>
      <h2 className="mt-8 font-serif text-2xl">History</h2>
      <ul className="mt-2 text-sm">
        {history.map((h) => (
          <li key={h.id}>
            {h.status} · {formatDate(h.createdAt, "fr")} · {h.note}
          </li>
        ))}
      </ul>
      <h2 className="mt-6 font-serif text-2xl">Payments</h2>
      <ul className="text-sm">
        {pays.map((p) => (
          <li key={p.id}>
            {p.provider} · {p.method} · {p.status} · {formatMoney(p.amount, "fr")} · {p.providerRef}
          </li>
        ))}
        {refs.map((r) => (
          <li key={r.id}>
            Refund {formatMoney(r.amount, "fr")} · {r.status}
          </li>
        ))}
      </ul>
    </div>
  );
}
