import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { getSettings } from "@/lib/settings";
import { formatDate, formatMoney, loc } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function InvoicePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (!order) notFound();
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, id));
  const settings = await getSettings();
  return (
    <main className="mx-auto max-w-3xl bg-white p-10 text-stone-900">
      <div className="flex justify-between">
        <div>
          <p className="font-serif text-3xl">{settings.storeName}</p>
          <p className="text-sm">
            {settings.address}, {settings.city}
          </p>
        </div>
        <div className="text-right text-sm">
          <p>Invoice {order.orderNumber}</p>
          <p>{formatDate(order.createdAt, "fr")}</p>
          <p className="no-print mt-2 text-xs">Use the browser print dialog for invoice / packing slip.</p>
        </div>
      </div>
      <div className="mt-8 text-sm">
        <p>
          {order.customerName}
          <br />
          {order.shippingAddress.street}
          <br />
          {order.shippingAddress.city} {order.shippingAddress.region}
          <br />
          {order.phone}
        </p>
      </div>
      <table className="mt-8 w-full text-left text-sm">
        <thead>
          <tr className="border-b">
            <th className="py-2">Item</th>
            <th>Qty</th>
            <th>Unit</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          {items.map((i) => (
            <tr key={i.id} className="border-b">
              <td className="py-2">
                {i.name} {i.size} {i.color}
                <br />
                <span className="text-xs">{i.sku}</span>
              </td>
              <td>{i.quantity}</td>
              <td>{formatMoney(i.unitPrice, "fr")}</td>
              <td>{formatMoney(i.total, "fr")}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="mt-6 text-right text-lg">Total {formatMoney(order.total, "fr")}</p>
      <p className="mt-8 text-xs">{loc(settings.invoiceFooter, "fr")}</p>
      <p className="no-print mt-6 text-sm">
        Packing slip: {items.map((i) => `${i.quantity}× ${i.name} (${i.size || ""} ${i.color || ""})`).join(" · ")}
      </p>
    </main>
  );
}
