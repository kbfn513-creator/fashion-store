"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLogs,
  banners,
  categories,
  collections,
  contactMessages,
  coupons,
  inventoryMovements,
  orderStatusHistory,
  orders,
  pages,
  payments,
  productCollections,
  productImages,
  products,
  productVariants,
  refunds,
  reviews,
  shipments,
  shippingZones,
  storeSettings,
  users,
  type Localized,
} from "@/db/schema";
import { can, getSessionUser, hashPassword, isStaff } from "@/lib/auth";
import { restoreStockForOrder } from "@/lib/commerce";
import { getSettings, invalidateSettingsCache } from "@/lib/settings";
import type { StoreSettingsData } from "@/lib/types";
import { slugify } from "@/lib/utils";

async function requireAdmin(permission?: string) {
  const user = await getSessionUser();
  if (!isStaff(user)) redirect("/admin/login");
  if (permission && !can(user, permission)) throw new Error("Forbidden");
  return user!;
}

async function audit(actorId: string, action: string, entity: string, entityId?: string, meta?: Record<string, unknown>) {
  await db.insert(auditLogs).values({ actorId, action, entity, entityId, meta });
}

function locFromForm(form: FormData, key: string): Localized {
  return {
    en: String(form.get(`${key}_en`) || ""),
    fr: String(form.get(`${key}_fr`) || ""),
    ar: String(form.get(`${key}_ar`) || ""),
  };
}

export async function saveProductAction(formData: FormData) {
  const user = await requireAdmin("products");
  const id = String(formData.get("id") || "");
  const name = locFromForm(formData, "name");
  const slug = slugify(String(formData.get("slug") || name.en || name.fr));
  const payload = {
    slug,
    sku: String(formData.get("sku") || ""),
    barcode: String(formData.get("barcode") || "") || null,
    brand: String(formData.get("brand") || "Maison Zahra"),
    categoryId: String(formData.get("categoryId") || "") || null,
    name,
    description: locFromForm(formData, "description"),
    materials: locFromForm(formData, "materials"),
    care: locFromForm(formData, "care"),
    fit: locFromForm(formData, "fit"),
    sizeGuide: locFromForm(formData, "sizeGuide"),
    tags: String(formData.get("tags") || "")
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean),
    price: Math.round(Number(formData.get("price") || 0) * 100),
    salePrice: formData.get("salePrice") ? Math.round(Number(formData.get("salePrice")) * 100) : null,
    costPrice: formData.get("costPrice") ? Math.round(Number(formData.get("costPrice")) * 100) : null,
    status: (String(formData.get("status") || "draft") as "draft" | "published" | "archived"),
    featured: formData.get("featured") === "on",
    newArrival: formData.get("newArrival") === "on",
    bestSeller: formData.get("bestSeller") === "on",
    lowStockThreshold: Number(formData.get("lowStockThreshold") || 5),
    publishedAt: String(formData.get("status")) === "published" ? new Date() : null,
    updatedAt: new Date(),
  };
  let productId = id;
  if (id) {
    await db.update(products).set(payload).where(eq(products.id, id));
  } else {
    const [created] = await db.insert(products).values(payload).returning();
    productId = created.id;
  }

  const imageUrl = String(formData.get("imageUrl") || "").trim();
  if (imageUrl) {
    const existing = await db.select().from(productImages).where(eq(productImages.productId, productId));
    if (!existing.length) {
      await db.insert(productImages).values({
        productId,
        url: imageUrl,
        alt: name.en || name.fr,
        sortOrder: 0,
        isMain: true,
      });
    }
  }

  const extraImages = String(formData.get("extraImages") || "")
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
  for (const [i, url] of extraImages.entries()) {
    await db.insert(productImages).values({
      productId,
      url,
      alt: name.en || name.fr,
      sortOrder: i + 1,
      isMain: false,
    });
  }

  const variantsJson = String(formData.get("variantsJson") || "[]");
  let variants: Array<{
    id?: string;
    sku: string;
    size?: string;
    color?: string;
    colorHex?: string;
    price?: number;
    salePrice?: number;
    stock: number;
  }> = [];
  try {
    variants = JSON.parse(variantsJson);
  } catch {
    variants = [];
  }
  const existingVariants = await db.select().from(productVariants).where(eq(productVariants.productId, productId));
  const keepIds = new Set(variants.map((v) => v.id).filter(Boolean));
  for (const old of existingVariants) {
    if (!keepIds.has(old.id)) await db.delete(productVariants).where(eq(productVariants.id, old.id));
  }
  for (const v of variants) {
    const row = {
      productId,
      sku: v.sku,
      size: v.size || null,
      color: v.color || null,
      colorHex: v.colorHex || null,
      price: v.price != null ? Math.round(v.price * 100) : null,
      salePrice: v.salePrice != null ? Math.round(v.salePrice * 100) : null,
      stock: Number(v.stock || 0),
      isActive: true,
    };
    if (v.id && existingVariants.some((e) => e.id === v.id)) {
      const prev = existingVariants.find((e) => e.id === v.id)!;
      await db.update(productVariants).set(row).where(eq(productVariants.id, v.id));
      if (prev.stock !== row.stock) {
        await db.insert(inventoryMovements).values({
          variantId: v.id,
          quantity: row.stock - prev.stock,
          reason: "adjustment",
          userId: user.id,
          note: "Admin product edit",
        });
      }
    } else {
      const [created] = await db.insert(productVariants).values(row).returning();
      await db.insert(inventoryMovements).values({
        variantId: created.id,
        quantity: row.stock,
        reason: "import",
        userId: user.id,
        note: "Initial stock",
      });
    }
  }

  const collectionIds = formData.getAll("collectionId").map(String).filter(Boolean);
  await db.delete(productCollections).where(eq(productCollections.productId, productId));
  if (collectionIds.length) {
    await db.insert(productCollections).values(collectionIds.map((collectionId) => ({ productId, collectionId })));
  }

  await audit(user.id, id ? "update" : "create", "product", productId);
  revalidatePath("/admin/products");
  redirect("/admin/products");
}

export async function duplicateProductAction(productId: string) {
  const user = await requireAdmin("products");
  const [p] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!p) throw new Error("Not found");
  const [copy] = await db
    .insert(products)
    .values({
      slug: `${p.slug}-copy`,
      sku: `${p.sku}-COPY`,
      barcode: p.barcode,
      brand: p.brand,
      categoryId: p.categoryId,
      name: { en: `${p.name.en} (copy)`, fr: `${p.name.fr} (copie)`, ar: `${p.name.ar} (نسخة)` },
      description: p.description,
      materials: p.materials,
      care: p.care,
      fit: p.fit,
      sizeGuide: p.sizeGuide,
      tags: p.tags,
      price: p.price,
      salePrice: p.salePrice,
      costPrice: p.costPrice,
      taxRateBps: p.taxRateBps,
      status: "draft",
      featured: false,
      newArrival: false,
      bestSeller: false,
      lowStockThreshold: p.lowStockThreshold,
    })
    .returning();
  const images = await db.select().from(productImages).where(eq(productImages.productId, productId));
  if (images.length) {
    await db.insert(productImages).values(
      images.map((i) => ({
        productId: copy.id,
        url: i.url,
        alt: i.alt,
        sortOrder: i.sortOrder,
        isMain: i.isMain,
      })),
    );
  }
  const variants = await db.select().from(productVariants).where(eq(productVariants.productId, productId));
  for (const v of variants) {
    await db.insert(productVariants).values({
      productId: copy.id,
      sku: `${v.sku}-C`,
      size: v.size,
      color: v.color,
      colorHex: v.colorHex,
      price: v.price,
      salePrice: v.salePrice,
      stock: v.stock,
      barcode: v.barcode,
      isActive: v.isActive,
    });
  }
  await audit(user.id, "duplicate", "product", copy.id);
  revalidatePath("/admin/products");
  redirect(`/admin/products/${copy.id}`);
}

export async function deleteProductAction(productId: string) {
  const user = await requireAdmin("products");
  await db.delete(products).where(eq(products.id, productId));
  await audit(user.id, "delete", "product", productId);
  revalidatePath("/admin/products");
}

export async function setProductStatusAction(productId: string, status: "draft" | "published" | "archived") {
  const user = await requireAdmin("products");
  await db
    .update(products)
    .set({ status, publishedAt: status === "published" ? new Date() : null, updatedAt: new Date() })
    .where(eq(products.id, productId));
  await audit(user.id, "status", "product", productId, { status });
  revalidatePath("/admin/products");
}

export async function saveCategoryAction(formData: FormData) {
  const user = await requireAdmin("content");
  const id = String(formData.get("id") || "");
  const values = {
    slug: slugify(String(formData.get("slug") || formData.get("name_en") || "")),
    name: locFromForm(formData, "name"),
    description: locFromForm(formData, "description"),
    image: String(formData.get("image") || "") || null,
    sortOrder: Number(formData.get("sortOrder") || 0),
    isActive: formData.get("isActive") === "on",
  };
  if (id) await db.update(categories).set(values).where(eq(categories.id, id));
  else await db.insert(categories).values(values);
  await audit(user.id, id ? "update" : "create", "category", id || undefined);
  revalidatePath("/admin/categories");
}

export async function deleteCategoryAction(id: string) {
  const user = await requireAdmin("content");
  await db.delete(categories).where(eq(categories.id, id));
  await audit(user.id, "delete", "category", id);
  revalidatePath("/admin/categories");
}

export async function saveCollectionAction(formData: FormData) {
  const user = await requireAdmin("content");
  const id = String(formData.get("id") || "");
  const values = {
    slug: slugify(String(formData.get("slug") || formData.get("name_en") || "")),
    name: locFromForm(formData, "name"),
    description: locFromForm(formData, "description"),
    image: String(formData.get("image") || "") || null,
    sortOrder: Number(formData.get("sortOrder") || 0),
    isActive: formData.get("isActive") === "on",
  };
  if (id) await db.update(collections).set(values).where(eq(collections.id, id));
  else await db.insert(collections).values(values);
  await audit(user.id, id ? "update" : "create", "collection", id || undefined);
  revalidatePath("/admin/collections");
}

export async function deleteCollectionAction(id: string) {
  const user = await requireAdmin("content");
  await db.delete(collections).where(eq(collections.id, id));
  await audit(user.id, "delete", "collection", id);
  revalidatePath("/admin/collections");
}

export async function adjustInventoryAction(formData: FormData) {
  const user = await requireAdmin("inventory");
  const variantId = String(formData.get("variantId") || "");
  const quantity = Number(formData.get("quantity") || 0);
  const note = String(formData.get("note") || "");
  const [variant] = await db.select().from(productVariants).where(eq(productVariants.id, variantId)).limit(1);
  if (!variant) throw new Error("Variant not found");
  await db.update(productVariants).set({ stock: variant.stock + quantity }).where(eq(productVariants.id, variantId));
  await db.insert(inventoryMovements).values({
    variantId,
    quantity,
    reason: "adjustment",
    note,
    userId: user.id,
  });
  await audit(user.id, "adjust", "inventory", variantId, { quantity });
  revalidatePath("/admin/inventory");
}

export async function updateOrderStatusAction(formData: FormData) {
  const user = await requireAdmin("orders");
  const orderId = String(formData.get("orderId") || "");
  const status = String(formData.get("status") || "") as typeof orders.$inferSelect.status;
  const note = String(formData.get("note") || "");
  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) throw new Error("Order not found");
  const settings = await getSettings();
  await db.update(orders).set({ status, updatedAt: new Date() }).where(eq(orders.id, orderId));
  await db.insert(orderStatusHistory).values({ orderId, status, note: note || null, actorId: user.id });
  if (status === "cancelled" && order.status !== "cancelled" && settings.restoreStockOnCancel) {
    await restoreStockForOrder(orderId, "cancellation");
  }
  if (status === "returned" && order.status !== "returned" && settings.restoreStockOnRefund) {
    await restoreStockForOrder(orderId, "return");
  }
  if (status === "delivered" && order.paymentMethod === "cod") {
    await db.update(orders).set({ paymentStatus: "paid" }).where(eq(orders.id, orderId));
    await db.update(payments).set({ status: "paid" }).where(eq(payments.orderId, orderId));
  }
  await audit(user.id, "status", "order", orderId, { status });
  revalidatePath(`/admin/orders/${orderId}`);
  revalidatePath("/admin/orders");
}

export async function saveShipmentAction(formData: FormData) {
  const user = await requireAdmin("orders");
  const orderId = String(formData.get("orderId") || "");
  await db.insert(shipments).values({
    orderId,
    carrier: String(formData.get("carrier") || "") || null,
    trackingNumber: String(formData.get("trackingNumber") || "") || null,
    method: String(formData.get("method") || "") || null,
    estimatedDays: String(formData.get("estimatedDays") || "") || null,
    shippedAt: new Date(),
  });
  await db.update(orders).set({ status: "shipped", updatedAt: new Date() }).where(eq(orders.id, orderId));
  await db.insert(orderStatusHistory).values({
    orderId,
    status: "shipped",
    note: "Shipment recorded",
    actorId: user.id,
  });
  await audit(user.id, "ship", "order", orderId);
  revalidatePath(`/admin/orders/${orderId}`);
}

export async function saveOrderNoteAction(formData: FormData) {
  const user = await requireAdmin("orders");
  const orderId = String(formData.get("orderId") || "");
  await db
    .update(orders)
    .set({ internalNote: String(formData.get("internalNote") || ""), updatedAt: new Date() })
    .where(eq(orders.id, orderId));
  await audit(user.id, "note", "order", orderId);
  revalidatePath(`/admin/orders/${orderId}`);
}

export async function recordRefundAction(formData: FormData) {
  const user = await requireAdmin("orders");
  const orderId = String(formData.get("orderId") || "");
  const amount = Math.round(Number(formData.get("amount") || 0) * 100);
  const reason = String(formData.get("reason") || "");
  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) throw new Error("Order not found");
  await db.insert(refunds).values({ orderId, amount, reason, status: "recorded" });
  const nextStatus = amount >= order.total ? "refunded" : "partially_refunded";
  await db.update(orders).set({ paymentStatus: nextStatus, updatedAt: new Date() }).where(eq(orders.id, orderId));
  const settings = await getSettings();
  if (settings.restoreStockOnRefund) await restoreStockForOrder(orderId, "return");
  await audit(user.id, "refund", "order", orderId, { amount });
  revalidatePath(`/admin/orders/${orderId}`);
}

export async function saveCouponAction(formData: FormData) {
  const user = await requireAdmin("promotions");
  const id = String(formData.get("id") || "");
  const values = {
    code: String(formData.get("code") || "").trim().toUpperCase(),
    type: String(formData.get("type") || "percent") as "percent" | "fixed" | "free_shipping",
    value: String(formData.get("type")) === "percent" ? Math.round(Number(formData.get("value") || 0) * 100) : Math.round(Number(formData.get("value") || 0) * 100),
    minOrder: Math.round(Number(formData.get("minOrder") || 0) * 100),
    maxUses: formData.get("maxUses") ? Number(formData.get("maxUses")) : null,
    perCustomerLimit: Number(formData.get("perCustomerLimit") || 1),
    isActive: formData.get("isActive") === "on",
    startsAt: formData.get("startsAt") ? new Date(String(formData.get("startsAt"))) : null,
    endsAt: formData.get("endsAt") ? new Date(String(formData.get("endsAt"))) : null,
  };
  if (id) await db.update(coupons).set(values).where(eq(coupons.id, id));
  else await db.insert(coupons).values(values);
  await audit(user.id, id ? "update" : "create", "coupon", id || undefined);
  revalidatePath("/admin/promotions");
}

export async function deleteCouponAction(id: string) {
  const user = await requireAdmin("promotions");
  await db.delete(coupons).where(eq(coupons.id, id));
  await audit(user.id, "delete", "coupon", id);
  revalidatePath("/admin/promotions");
}

export async function moderateReviewAction(id: string, status: "approved" | "hidden") {
  const user = await requireAdmin("reviews");
  await db.update(reviews).set({ status }).where(eq(reviews.id, id));
  await audit(user.id, "moderate", "review", id, { status });
  revalidatePath("/admin/reviews");
}

export async function savePageAction(formData: FormData) {
  const user = await requireAdmin("content");
  const id = String(formData.get("id") || "");
  const values = {
    slug: slugify(String(formData.get("slug") || "")),
    title: locFromForm(formData, "title"),
    body: locFromForm(formData, "body"),
    seoDescription: locFromForm(formData, "seo"),
    isPublished: formData.get("isPublished") === "on",
    updatedAt: new Date(),
  };
  if (id) await db.update(pages).set(values).where(eq(pages.id, id));
  else await db.insert(pages).values(values);
  await audit(user.id, id ? "update" : "create", "page", id || undefined);
  revalidatePath("/admin/content");
}

export async function saveBannerAction(formData: FormData) {
  const user = await requireAdmin("content");
  const id = String(formData.get("id") || "");
  const values = {
    key: String(formData.get("key") || "hero"),
    image: String(formData.get("image") || "") || null,
    title: locFromForm(formData, "title"),
    subtitle: locFromForm(formData, "subtitle"),
    ctaLabel: locFromForm(formData, "cta"),
    ctaHref: String(formData.get("ctaHref") || ""),
    isActive: formData.get("isActive") === "on",
  };
  if (id) await db.update(banners).set(values).where(eq(banners.id, id));
  else await db.insert(banners).values(values);
  await audit(user.id, "update", "banner", id || undefined);
  revalidatePath("/admin/content");
  revalidatePath("/");
}

export async function saveSettingsAction(formData: FormData) {
  const user = await requireAdmin("settings");
  const current = await getSettings();
  const next: StoreSettingsData = {
    ...current,
    storeName: String(formData.get("storeName") || current.storeName),
    logoText: String(formData.get("logoText") || current.logoText),
    logoUrl: String(formData.get("logoUrl") || "") || null,
    announcementEnabled: formData.get("announcementEnabled") === "on",
    announcement: locFromForm(formData, "announcement"),
    tagline: locFromForm(formData, "tagline"),
    primaryColor: String(formData.get("primaryColor") || current.primaryColor),
    accentColor: String(formData.get("accentColor") || current.accentColor),
    backgroundColor: String(formData.get("backgroundColor") || current.backgroundColor),
    textColor: String(formData.get("textColor") || current.textColor),
    defaultLocale: (String(formData.get("defaultLocale") || current.defaultLocale) as StoreSettingsData["defaultLocale"]),
    currency: String(formData.get("currency") || current.currency),
    country: String(formData.get("country") || current.country),
    timezone: String(formData.get("timezone") || current.timezone),
    taxInclusive: formData.get("taxInclusive") === "on",
    taxRateBps: Number(formData.get("taxRateBps") || current.taxRateBps),
    freeShippingThreshold: Math.round(Number(formData.get("freeShippingThreshold") || 0) * 100),
    contactEmail: String(formData.get("contactEmail") || current.contactEmail),
    contactPhone: String(formData.get("contactPhone") || current.contactPhone),
    whatsapp: String(formData.get("whatsapp") || current.whatsapp),
    address: String(formData.get("address") || current.address),
    city: String(formData.get("city") || current.city),
    businessHours: locFromForm(formData, "businessHours"),
    instagram: String(formData.get("instagram") || ""),
    facebook: String(formData.get("facebook") || ""),
    tiktok: String(formData.get("tiktok") || ""),
    maintenanceMode: formData.get("maintenanceMode") === "on",
    orderPrefix: String(formData.get("orderPrefix") || current.orderPrefix),
    invoiceFooter: locFromForm(formData, "invoiceFooter"),
    codEnabled: formData.get("codEnabled") === "on",
    cardEnabled: formData.get("cardEnabled") === "on",
    lowStockThreshold: Number(formData.get("lowStockThreshold") || current.lowStockThreshold),
    restoreStockOnCancel: formData.get("restoreStockOnCancel") === "on",
    restoreStockOnRefund: formData.get("restoreStockOnRefund") === "on",
    heroImage: String(formData.get("heroImage") || current.heroImage),
    seoTitle: locFromForm(formData, "seoTitle"),
    seoDescription: locFromForm(formData, "seoDescription"),
    footerNote: locFromForm(formData, "footerNote"),
  };
  await db
    .insert(storeSettings)
    .values({ id: 1, data: next, updatedAt: new Date() })
    .onConflictDoUpdate({ target: storeSettings.id, set: { data: next, updatedAt: new Date() } });
  invalidateSettingsCache();
  await audit(user.id, "update", "settings", "1");
  revalidatePath("/");
  revalidatePath("/admin/settings");
}

export async function saveShippingZoneAction(formData: FormData) {
  const user = await requireAdmin("settings");
  const id = String(formData.get("id") || "");
  const values = {
    name: String(formData.get("name") || ""),
    cities: String(formData.get("cities") || "")
      .split(",")
      .map((c) => c.trim())
      .filter(Boolean),
    fee: Math.round(Number(formData.get("fee") || 0) * 100),
    estimatedDays: String(formData.get("estimatedDays") || "2–5"),
    isActive: formData.get("isActive") === "on",
    sortOrder: Number(formData.get("sortOrder") || 0),
  };
  if (id) await db.update(shippingZones).set(values).where(eq(shippingZones.id, id));
  else await db.insert(shippingZones).values(values);
  await audit(user.id, "update", "shipping", id || undefined);
  revalidatePath("/admin/settings");
}

export async function markMessageReadAction(id: string) {
  await requireAdmin("messages");
  await db.update(contactMessages).set({ status: "read" }).where(eq(contactMessages.id, id));
  revalidatePath("/admin/messages");
}

export async function saveStaffAction(formData: FormData) {
  const user = await requireAdmin("settings");
  if (user.role !== "admin") throw new Error("Forbidden");
  const email = String(formData.get("email") || "").toLowerCase();
  const name = String(formData.get("name") || "");
  const password = String(formData.get("password") || "");
  const permissions = formData.getAll("permission").map(String);
  const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing) {
    await db
      .update(users)
      .set({
        name,
        role: "staff",
        permissions,
        ...(password ? { passwordHash: await hashPassword(password) } : {}),
      })
      .where(eq(users.id, existing.id));
  } else {
    if (password.length < 10) throw new Error("Staff password must be at least 10 characters");
    await db.insert(users).values({
      email,
      name,
      passwordHash: await hashPassword(password),
      role: "staff",
      status: "active",
      permissions,
    });
  }
  await audit(user.id, "upsert", "staff", email);
  revalidatePath("/admin/settings");
}

export async function setCustomerStatusAction(id: string, status: "active" | "disabled") {
  const user = await requireAdmin("customers");
  await db.update(users).set({ status }).where(and(eq(users.id, id), eq(users.role, "customer")));
  await audit(user.id, "status", "customer", id, { status });
  revalidatePath("/admin/customers");
}
