import { saveBannerAction, savePageAction } from "@/app/admin/actions";
import { db } from "@/db";
import { banners, pages } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function ContentPage() {
  const cms = await db.select().from(pages);
  const hero = (await db.select().from(banners))[0];
  return (
    <div className="space-y-12">
      <section>
        <h1 className="font-serif text-4xl">Homepage banner</h1>
        <form action={saveBannerAction} className="mt-4 grid max-w-3xl gap-2">
          {hero && <input type="hidden" name="id" value={hero.id} />}
          <input name="key" defaultValue={hero?.key || "hero"} className="border bg-white p-2" />
          <input name="image" defaultValue={hero?.image || ""} placeholder="Image URL" className="border bg-white p-2" />
          <input name="title_fr" defaultValue={hero?.title.fr} className="border bg-white p-2" />
          <input name="title_ar" defaultValue={hero?.title.ar} className="border bg-white p-2" />
          <input name="title_en" defaultValue={hero?.title.en} className="border bg-white p-2" />
          <input name="subtitle_fr" defaultValue={hero?.subtitle?.fr} className="border bg-white p-2" />
          <input name="subtitle_ar" defaultValue={hero?.subtitle?.ar} className="border bg-white p-2" />
          <input name="subtitle_en" defaultValue={hero?.subtitle?.en} className="border bg-white p-2" />
          <input name="cta_fr" defaultValue={hero?.ctaLabel?.fr} className="border bg-white p-2" />
          <input name="cta_ar" defaultValue={hero?.ctaLabel?.ar} className="border bg-white p-2" />
          <input name="cta_en" defaultValue={hero?.ctaLabel?.en} className="border bg-white p-2" />
          <input name="ctaHref" defaultValue={hero?.ctaHref || ""} className="border bg-white p-2" />
          <label>
            <input type="checkbox" name="isActive" defaultChecked={hero?.isActive ?? true} /> Active
          </label>
          <button className="bg-[#1c1917] px-4 py-2 text-white">Save banner</button>
        </form>
      </section>
      <section>
        <h2 className="font-serif text-3xl">Pages</h2>
        {cms.map((p) => (
          <form key={p.id} action={savePageAction} className="mt-6 grid max-w-3xl gap-2 border-b pb-6">
            <input type="hidden" name="id" value={p.id} />
            <input name="slug" defaultValue={p.slug} className="border bg-white p-2" />
            <input name="title_fr" defaultValue={p.title.fr} className="border bg-white p-2" />
            <input name="title_ar" defaultValue={p.title.ar} className="border bg-white p-2" />
            <input name="title_en" defaultValue={p.title.en} className="border bg-white p-2" />
            <textarea name="body_fr" defaultValue={p.body.fr} className="min-h-32 border bg-white p-2" />
            <textarea name="body_ar" defaultValue={p.body.ar} className="min-h-32 border bg-white p-2" />
            <textarea name="body_en" defaultValue={p.body.en} className="min-h-32 border bg-white p-2" />
            <input name="seo_fr" defaultValue={p.seoDescription?.fr} className="border bg-white p-2" />
            <input name="seo_ar" defaultValue={p.seoDescription?.ar} className="border bg-white p-2" />
            <input name="seo_en" defaultValue={p.seoDescription?.en} className="border bg-white p-2" />
            <label>
              <input type="checkbox" name="isPublished" defaultChecked={p.isPublished} /> Published
            </label>
            <button className="bg-[#1c1917] px-4 py-2 text-white">Save page</button>
          </form>
        ))}
      </section>
    </div>
  );
}
