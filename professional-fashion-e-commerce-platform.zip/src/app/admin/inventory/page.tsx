import { desc } from "drizzle-orm";
import { adjustInventoryAction } from "@/app/admin/actions";
import { db } from "@/db";
import { inventoryMovements, products, productVariants } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function InventoryPage() {
  const variants = await db.select().from(productVariants);
  const prods = await db.select().from(products);
  const moves = await db.select().from(inventoryMovements).orderBy(desc(inventoryMovements.createdAt)).limit(40);
  return (
    <div>
      <h1 className="font-serif text-4xl">Inventory</h1>
      <table className="mt-6 w-full text-left text-sm">
        <thead>
          <tr className="border-b text-[11px] uppercase tracking-[0.14em] text-stone-500">
            <th className="py-2">SKU</th>
            <th>Product</th>
            <th>Variant</th>
            <th>Stock</th>
            <th>Adjust</th>
          </tr>
        </thead>
        <tbody>
          {variants.map((v) => {
            const p = prods.find((x) => x.id === v.productId);
            const low = v.stock <= (p?.lowStockThreshold ?? 5);
            return (
              <tr key={v.id} className="border-b">
                <td className="py-2">{v.sku}</td>
                <td>{p?.name.fr}</td>
                <td>
                  {v.size} {v.color}
                </td>
                <td className={low ? "text-red-800" : ""}>{v.stock}</td>
                <td>
                  <form action={adjustInventoryAction} className="flex gap-1">
                    <input type="hidden" name="variantId" value={v.id} />
                    <input name="quantity" type="number" placeholder="+/-" className="w-20 border bg-white px-2 py-1" />
                    <input name="note" placeholder="note" className="border bg-white px-2 py-1" />
                    <button className="text-xs underline">Apply</button>
                  </form>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <h2 className="mt-10 font-serif text-2xl">Audit trail</h2>
      <ul className="mt-3 space-y-1 text-sm">
        {moves.map((m) => (
          <li key={m.id}>
            {m.createdAt.toISOString().slice(0, 16)} · {m.reason} · {m.quantity} · {m.note}
          </li>
        ))}
      </ul>
    </div>
  );
}
