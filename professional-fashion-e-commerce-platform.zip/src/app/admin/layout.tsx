import Link from "next/link";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { logoutAction } from "@/app/actions";
import { getSessionUser, isStaff } from "@/lib/auth";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Overview" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/inventory", label: "Inventory" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/customers", label: "Customers" },
  { href: "/admin/promotions", label: "Promotions" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/collections", label: "Collections" },
  { href: "/admin/reviews", label: "Reviews" },
  { href: "/admin/content", label: "Content" },
  { href: "/admin/messages", label: "Messages" },
  { href: "/admin/settings", label: "Settings" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const path = (await headers()).get("x-mz-path") || "";
  if (path === "/admin/login") return <>{children}</>;
  const user = await getSessionUser();
  if (!isStaff(user)) redirect("/admin/login");
  const settings = await getSettings();
  return (
    <div className="admin-grid min-h-screen bg-[#efe8dc] text-stone-900">
      <aside className="border-e border-stone-300 bg-[#1c1917] p-6 text-[#f6f1ea]">
        <Link href="/admin" className="font-serif text-xl tracking-[0.12em] uppercase">
          {settings.storeName}
        </Link>
        <p className="mt-1 text-[10px] tracking-[0.18em] uppercase text-stone-400">Atelier console</p>
        <nav className="mt-8 grid gap-2 text-sm">
          {NAV.map((item) => (
            <Link key={item.href} href={item.href} className="rounded px-2 py-1.5 hover:bg-white/10">
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="mt-10 text-xs text-stone-400">
          <p>{user!.name}</p>
          <p>{user!.role}</p>
          <form action={logoutAction} className="mt-3">
            <button className="underline">Sign out</button>
          </form>
          <Link href="/" className="mt-3 block underline">
            View store
          </Link>
        </div>
      </aside>
      <div className="p-6 md:p-10">{children}</div>
    </div>
  );
}
