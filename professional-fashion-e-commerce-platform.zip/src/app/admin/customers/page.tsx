import { desc, eq } from "drizzle-orm";
import { setCustomerStatusAction } from "@/app/admin/actions";
import { db } from "@/db";
import { orders, users } from "@/db/schema";
import { formatMoney } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function CustomersPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q.toLowerCase() : "";
  let rows = await db.select().from(users).where(eq(users.role, "customer")).orderBy(desc(users.createdAt));
  if (q) rows = rows.filter((u) => u.email.includes(q) || u.name.toLowerCase().includes(q) || (u.phone || "").includes(q));
  const allOrders = await db.select().from(orders);
  return (
    <div>
      <h1 className="font-serif text-4xl">Customers</h1>
      <form className="mt-4">
        <input name="q" defaultValue={q} placeholder="Search name, email, phone" className="border bg-white px-3 py-2" />
      </form>
      <table className="mt-6 w-full text-left text-sm">
        <thead>
          <tr className="border-b text-[11px] uppercase tracking-[0.14em] text-stone-500">
            <th className="py-2">Customer</th>
            <th>Orders</th>
            <th>Spend</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((u) => {
            const mine = allOrders.filter((o) => o.userId === u.id || o.email === u.email);
            return (
              <tr key={u.id} className="border-b">
                <td className="py-3">
                  {u.name}
                  <br />
                  <span className="text-xs text-stone-500">{u.email}</span>
                </td>
                <td>{mine.length}</td>
                <td>{formatMoney(mine.reduce((s, o) => s + o.total, 0), "fr")}</td>
                <td>
                  {u.status}
                  <form
                    action={async () => {
                      await setCustomerStatusAction(u.id, u.status === "active" ? "disabled" : "active");
                    }}
                  >
                    <button className="text-xs underline">{u.status === "active" ? "Disable" : "Enable"}</button>
                  </form>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
