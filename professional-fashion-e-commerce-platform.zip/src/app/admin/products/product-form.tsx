import { saveProductAction } from "@/app/admin/actions";
import { VariantEditor } from "@/components/client-ui";
import type { categories, collections, productImages, products, productVariants } from "@/db/schema";

type Product = typeof products.$inferSelect;
type Variant = typeof productVariants.$inferSelect;
type Image = typeof productImages.$inferSelect;
type Category = typeof categories.$inferSelect;
type Collection = typeof collections.$inferSelect;

export function ProductForm({
  product,
  variants,
  images,
  cats,
  cols,
  selectedCollections,
}: {
  product?: Product;
  variants: Variant[];
  images: Image[];
  cats: Category[];
  cols: Collection[];
  selectedCollections: string[];
}) {
  const locField = (label: string, key: string, value?: { en: string; fr: string; ar: string }, area = false) => (
    <fieldset className="grid gap-2 md:grid-cols-3">
      {(["fr", "ar", "en"] as const).map((l) =>
        area ? (
          <textarea
            key={l}
            name={`${key}_${l}`}
            defaultValue={value?.[l] || ""}
            placeholder={`${label} ${l}`}
            className="min-h-24 w-full border bg-white/80 p-2 text-sm"
          />
        ) : (
          <input
            key={l}
            name={`${key}_${l}`}
            defaultValue={value?.[l] || ""}
            placeholder={`${label} ${l}`}
            className="w-full border bg-white/80 p-2 text-sm"
          />
        ),
      )}
    </fieldset>
  );

  return (
    <form action={saveProductAction} className="mt-6 max-w-4xl space-y-6">
      {product && <input type="hidden" name="id" value={product.id} />}
      {locField("Name", "name", product?.name)}
      {locField("Description", "description", product?.description, true)}
      {locField("Materials", "materials", product?.materials || undefined)}
      {locField("Care", "care", product?.care || undefined)}
      {locField("Fit", "fit", product?.fit || undefined)}
      {locField("Size guide", "sizeGuide", product?.sizeGuide || undefined)}
      <div className="grid gap-3 md:grid-cols-3">
        <input name="slug" defaultValue={product?.slug} placeholder="slug" className="border bg-white/80 p-2" />
        <input name="sku" required defaultValue={product?.sku} placeholder="SKU" className="border bg-white/80 p-2" />
        <input name="brand" defaultValue={product?.brand || "Maison Zahra"} className="border bg-white/80 p-2" />
      </div>
      <div className="grid gap-3 md:grid-cols-4">
        <input name="price" type="number" step="0.01" required defaultValue={product ? product.price / 100 : ""} placeholder="Price MAD" className="border bg-white/80 p-2" />
        <input name="salePrice" type="number" step="0.01" defaultValue={product?.salePrice ? product.salePrice / 100 : ""} placeholder="Sale MAD" className="border bg-white/80 p-2" />
        <input name="costPrice" type="number" step="0.01" defaultValue={product?.costPrice ? product.costPrice / 100 : ""} placeholder="Cost MAD" className="border bg-white/80 p-2" />
        <input name="lowStockThreshold" type="number" defaultValue={product?.lowStockThreshold ?? 5} className="border bg-white/80 p-2" />
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        <select name="categoryId" defaultValue={product?.categoryId || ""} className="border bg-white/80 p-2">
          <option value="">Category</option>
          {cats.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name.fr}
            </option>
          ))}
        </select>
        <select name="status" defaultValue={product?.status || "draft"} className="border bg-white/80 p-2">
          <option value="draft">draft</option>
          <option value="published">published</option>
          <option value="archived">archived</option>
        </select>
      </div>
      <div className="flex flex-wrap gap-4 text-sm">
        <label>
          <input type="checkbox" name="featured" defaultChecked={product?.featured} /> Featured
        </label>
        <label>
          <input type="checkbox" name="newArrival" defaultChecked={product?.newArrival} /> New
        </label>
        <label>
          <input type="checkbox" name="bestSeller" defaultChecked={product?.bestSeller} /> Bestseller
        </label>
      </div>
      <div>
        <p className="text-xs uppercase tracking-[0.14em]">Collections</p>
        <div className="mt-2 flex flex-wrap gap-3 text-sm">
          {cols.map((c) => (
            <label key={c.id}>
              <input type="checkbox" name="collectionId" value={c.id} defaultChecked={selectedCollections.includes(c.id)} /> {c.name.fr}
            </label>
          ))}
        </div>
      </div>
      <input name="tags" defaultValue={(product?.tags || []).join(", ")} placeholder="tags, comma separated" className="w-full border bg-white/80 p-2" />
      <input name="imageUrl" placeholder="Main image URL" defaultValue={images[0]?.url} className="w-full border bg-white/80 p-2" />
      <textarea name="extraImages" placeholder="Additional image URLs, one per line" className="w-full border bg-white/80 p-2" />
      <div>
        <p className="mb-2 text-xs uppercase tracking-[0.14em]">Variants (SKU, size, color, hex, stock, price override)</p>
        <VariantEditor
          initial={
            variants.length
              ? variants
              : [{ sku: "", size: "M", color: "", colorHex: "", stock: 0 }]
          }
        />
      </div>
      <button className="bg-[#1c1917] px-6 py-3 text-[12px] tracking-[0.18em] text-white uppercase">Save product</button>
    </form>
  );
}
