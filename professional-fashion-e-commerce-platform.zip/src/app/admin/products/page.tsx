import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { deleteProductAction, duplicateProductAction, setProductStatusAction } from "@/app/admin/actions";
import { AdminDeleteButton } from "@/components/client-ui";
import { db } from "@/db";
import { productImages, products } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  const rows = await db.select().from(products).orderBy(desc(products.createdAt));
  const images = await db.select().from(productImages);
  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-serif text-4xl">Products</h1>
        <div className="flex gap-3 text-sm">
          <a href="/api/admin/products.csv" className="underline">
            Export CSV
          </a>
          <Link href="/admin/products/new" className="bg-[#1c1917] px-4 py-2 text-[11px] tracking-[0.16em] text-white uppercase">
            New product
          </Link>
        </div>
      </div>
      <div className="mt-8 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b text-[11px] tracking-[0.14em] uppercase text-stone-500">
              <th className="py-2">Product</th>
              <th>SKU</th>
              <th>Status</th>
              <th>Price</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((p) => {
              const img = images.find((i) => i.productId === p.id && i.isMain) || images.find((i) => i.productId === p.id);
              return (
                <tr key={p.id} className="border-b border-stone-200">
                  <td className="py-3">
                    <Link href={`/admin/products/${p.id}`} className="flex items-center gap-3">
                      {img && (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={img.url} alt="" className="h-12 w-10 object-cover" />
                      )}
                      {p.name.fr}
                    </Link>
                  </td>
                  <td>{p.sku}</td>
                  <td>{p.status}</td>
                  <td>{(p.price / 100).toFixed(2)} MAD</td>
                  <td className="space-x-2 text-xs">
                    <form action={async () => { await setProductStatusAction(p.id, p.status === "published" ? "draft" : "published"); }} className="inline">
                      <button className="underline">{p.status === "published" ? "Unpublish" : "Publish"}</button>
                    </form>
                    <form action={async () => { await duplicateProductAction(p.id); }} className="inline">
                      <button className="underline">Duplicate</button>
                    </form>
                    <form action={async () => { await setProductStatusAction(p.id, "archived"); }} className="inline">
                      <button className="underline">Archive</button>
                    </form>
                    <AdminDeleteButton action={async () => { await deleteProductAction(p.id); }} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
