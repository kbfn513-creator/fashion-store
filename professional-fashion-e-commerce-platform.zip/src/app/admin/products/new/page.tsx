import { db } from "@/db";
import { categories, collections } from "@/db/schema";
import { ProductForm } from "../product-form";

export const dynamic = "force-dynamic";

export default async function NewProductPage() {
  const cats = await db.select().from(categories);
  const cols = await db.select().from(collections);
  return (
    <div>
      <h1 className="font-serif text-4xl">New product</h1>
      <ProductForm variants={[]} images={[]} cats={cats} cols={cols} selectedCollections={[]} />
    </div>
  );
}
