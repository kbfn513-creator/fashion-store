import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { categories, collections, productCollections, productImages, products, productVariants } from "@/db/schema";
import { ProductForm } from "../product-form";

export const dynamic = "force-dynamic";

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [product] = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!product) notFound();
  const variants = await db.select().from(productVariants).where(eq(productVariants.productId, id));
  const images = await db.select().from(productImages).where(eq(productImages.productId, id));
  const cats = await db.select().from(categories);
  const cols = await db.select().from(collections);
  const links = await db.select().from(productCollections).where(eq(productCollections.productId, id));
  return (
    <div>
      <h1 className="font-serif text-4xl">Edit product</h1>
      <ProductForm
        product={product}
        variants={variants}
        images={images}
        cats={cats}
        cols={cols}
        selectedCollections={links.map((l) => l.collectionId)}
      />
    </div>
  );
}
