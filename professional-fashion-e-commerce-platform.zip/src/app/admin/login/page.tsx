import { AuthForm } from "@/components/client-ui";
import { getSessionUser, isStaff } from "@/lib/auth";
import { redirect } from "next/navigation";

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  const user = await getSessionUser();
  if (isStaff(user)) redirect("/admin");
  return (
    <main className="grid min-h-screen place-items-center bg-[#1c1917] px-6 text-[#f6f1ea]">
      <div className="w-full max-w-md">
        <p className="text-center font-serif text-4xl tracking-[0.12em] uppercase">Maison Zahra</p>
        <p className="mt-2 text-center text-[11px] tracking-[0.2em] uppercase text-stone-400">Atelier access</p>
        <div className="mt-8 rounded-2xl bg-[#f6f1ea] p-8 text-stone-900">
          <AuthForm
            mode="login"
            next="/admin"
            labels={{
              login: "Sign in",
              register: "Register",
              name: "Name",
              email: "Email",
              phone: "Phone",
              password: "Password",
            }}
          />
        </div>
      </div>
    </main>
  );
}
