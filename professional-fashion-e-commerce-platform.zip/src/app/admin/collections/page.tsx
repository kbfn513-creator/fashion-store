import { deleteCollectionAction, saveCollectionAction } from "@/app/admin/actions";
import { AdminDeleteButton } from "@/components/client-ui";
import { db } from "@/db";
import { collections } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function CollectionsPage() {
  const rows = await db.select().from(collections);
  return (
    <div>
      <h1 className="font-serif text-4xl">Collections</h1>
      <form action={saveCollectionAction} className="mt-6 grid max-w-3xl gap-2">
        <input name="name_fr" placeholder="Name FR" className="border bg-white p-2" />
        <input name="name_ar" placeholder="Name AR" className="border bg-white p-2" />
        <input name="name_en" placeholder="Name EN" className="border bg-white p-2" />
        <input name="description_fr" placeholder="Desc FR" className="border bg-white p-2" />
        <input name="description_ar" placeholder="Desc AR" className="border bg-white p-2" />
        <input name="description_en" placeholder="Desc EN" className="border bg-white p-2" />
        <input name="slug" placeholder="slug" className="border bg-white p-2" />
        <input name="image" placeholder="image URL" className="border bg-white p-2" />
        <input name="sortOrder" type="number" defaultValue={0} className="border bg-white p-2" />
        <label>
          <input type="checkbox" name="isActive" defaultChecked /> Active
        </label>
        <button className="bg-[#1c1917] px-4 py-2 text-white">Save</button>
      </form>
      <ul className="mt-8 space-y-2 text-sm">
        {rows.map((c) => (
          <li key={c.id} className="flex justify-between border-b py-2">
            {c.name.fr} / {c.slug}
            <AdminDeleteButton action={async () => { await deleteCollectionAction(c.id); }} />
          </li>
        ))}
      </ul>
    </div>
  );
}
