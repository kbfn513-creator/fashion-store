import Link from "next/link";
import { and, desc, eq, gte, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { notifications, orderItems, orders, productVariants, users } from "@/db/schema";
import { formatMoney } from "@/lib/utils";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function AdminHome({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const from = typeof sp.from === "string" ? new Date(sp.from) : new Date(Date.now() - 30 * 86400000);
  const to = typeof sp.to === "string" ? new Date(sp.to) : new Date();
  const status = typeof sp.status === "string" ? sp.status : "";
  const conditions = [gte(orders.createdAt, from), lte(orders.createdAt, to)];
  if (status) conditions.push(eq(orders.status, status as typeof orders.$inferSelect.status));

  const rows = await db
    .select()
    .from(orders)
    .where(and(...conditions))
    .orderBy(desc(orders.createdAt));
  const gross = rows.reduce((s, o) => s + o.subtotal, 0);
  const discounts = rows.reduce((s, o) => s + o.discount, 0);
  const refunded = rows.filter((o) => o.paymentStatus === "refunded" || o.paymentStatus === "partially_refunded");
  const refunds = refunded.reduce((s, o) => s + o.total, 0);
  const net = rows.filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.total, 0);
  const aov = rows.length ? Math.round(net / rows.length) : 0;
  const newCustomers = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(users)
    .where(and(eq(users.role, "customer"), gte(users.createdAt, from)));
  const recent = rows.slice(0, 8);
  const low = await db
    .select()
    .from(productVariants)
    .where(sql`${productVariants.stock} <= 5`)
    .limit(8);
  const best = await db
    .select({
      name: orderItems.name,
      qty: sql<number>`sum(${orderItems.quantity})::int`,
    })
    .from(orderItems)
    .groupBy(orderItems.name)
    .orderBy(sql`sum(${orderItems.quantity}) desc`)
    .limit(5);
  const notes = await db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(6);
  const settings = await getSettings();
  const byDay = new Map<string, number>();
  for (const o of rows) {
    const key = o.createdAt.toISOString().slice(0, 10);
    byDay.set(key, (byDay.get(key) || 0) + o.total);
  }
  const chart = [...byDay.entries()].slice(-14);
  const max = Math.max(1, ...chart.map((c) => c[1]));

  return (
    <div>
      <h1 className="font-serif text-4xl">Overview</h1>
      <form className="mt-4 flex flex-wrap gap-3 text-sm">
        <input type="date" name="from" defaultValue={from.toISOString().slice(0, 10)} className="border bg-transparent px-2 py-1" />
        <input type="date" name="to" defaultValue={to.toISOString().slice(0, 10)} className="border bg-transparent px-2 py-1" />
        <select name="status" defaultValue={status} className="border bg-transparent px-2 py-1">
          <option value="">All statuses</option>
          {["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "returned"].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <button className="border px-3 py-1">Filter</button>
      </form>
      <div className="mt-8 grid gap-4 md:grid-cols-4">
        {[
          ["Gross sales", formatMoney(gross, "fr", settings.currency)],
          ["Discounts", formatMoney(discounts, "fr", settings.currency)],
          ["Refunds (approx.)", formatMoney(refunds, "fr", settings.currency)],
          ["Net sales", formatMoney(net, "fr", settings.currency)],
          ["Orders", String(rows.length)],
          ["AOV", formatMoney(aov, "fr", settings.currency)],
          ["New customers", String(newCustomers[0]?.count || 0)],
          ["Low stock SKUs", String(low.length)],
        ].map(([k, v]) => (
          <div key={k} className="border border-stone-300 bg-white/70 p-4">
            <p className="text-[11px] tracking-[0.16em] uppercase text-stone-500">{k}</p>
            <p className="mt-2 font-serif text-3xl">{v}</p>
          </div>
        ))}
      </div>
      <div className="mt-10 border border-stone-300 bg-white/70 p-4">
        <p className="text-[11px] tracking-[0.16em] uppercase">Sales (period)</p>
        <div className="mt-4 flex h-40 items-end gap-1">
          {chart.map(([day, val]) => (
            <div key={day} className="flex-1 bg-[#1c1917]" style={{ height: `${(val / max) * 100}%` }} title={`${day}: ${val}`} />
          ))}
        </div>
      </div>
      <div className="mt-10 grid gap-8 lg:grid-cols-2">
        <section>
          <h2 className="font-serif text-2xl">Recent orders</h2>
          <ul className="mt-3 divide-y text-sm">
            {recent.map((o) => (
              <li key={o.id} className="flex justify-between py-2">
                <Link href={`/admin/orders/${o.id}`}>{o.orderNumber}</Link>
                <span>
                  {o.status} · {formatMoney(o.total, "fr", settings.currency)}
                </span>
              </li>
            ))}
          </ul>
        </section>
        <section>
          <h2 className="font-serif text-2xl">Bestsellers</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {best.map((b) => (
              <li key={b.name}>
                {b.name} · {b.qty}
              </li>
            ))}
          </ul>
          <h2 className="mt-8 font-serif text-2xl">Low stock</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {low.map((v) => (
              <li key={v.id}>
                {v.sku} · {v.size} {v.color} · {v.stock}
              </li>
            ))}
          </ul>
        </section>
      </div>
      <section className="mt-10">
        <h2 className="font-serif text-2xl">Alerts</h2>
        <ul className="mt-3 space-y-2 text-sm">
          {notes.map((n) => (
            <li key={n.id}>
              {n.title} — {n.body}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
