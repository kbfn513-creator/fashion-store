import { desc } from "drizzle-orm";
import { moderateReviewAction } from "@/app/admin/actions";
import { db } from "@/db";
import { reviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export default async function ReviewsPage() {
  const rows = await db.select().from(reviews).orderBy(desc(reviews.createdAt));
  return (
    <div>
      <h1 className="font-serif text-4xl">Reviews</h1>
      <ul className="mt-6 space-y-4">
        {rows.map((r) => (
          <li key={r.id} className="border-b py-3 text-sm">
            <p>
              ★ {r.rating} · {r.status} {r.verifiedPurchase ? "· verified" : ""}
            </p>
            <p className="mt-1">{r.body}</p>
            <div className="mt-2 flex gap-3">
              <form action={async () => { await moderateReviewAction(r.id, "approved"); }}>
                <button className="underline">Approve</button>
              </form>
              <form action={async () => { await moderateReviewAction(r.id, "hidden"); }}>
                <button className="underline">Hide</button>
              </form>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
