import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { orderItems, orders } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { t } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { formatMoney, formatDate, parseLocale } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function OrderPage({ params }: { params: Promise<{ number: string }> }) {
  const { number } = await params;
  const [order] = await db.select().from(orders).where(eq(orders.orderNumber, number)).limit(1);
  if (!order) notFound();
  const user = await getSessionUser();
  if (user && user.role === "customer" && order.userId && order.userId !== user.id) notFound();
  const settings = await getSettings();
  const locale = parseLocale((await cookies()).get("locale")?.value || settings.defaultLocale);
  const dict = t(locale);
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, order.id));
  const statusLabel = dict.status[order.status as keyof typeof dict.status] || order.status;
  return (
    <main className="container-mz max-w-3xl py-12">
      <p className="text-[11px] tracking-[0.2em] uppercase">{dict.order.confirmed}</p>
      <h1 className="mt-2 font-serif text-4xl">{dict.order.thanks}</h1>
      <p className="mt-4 text-stone-600">{dict.order.track}</p>
      <dl className="mt-8 grid gap-3 text-sm md:grid-cols-2">
        <div>
          <dt className="text-stone-500">{dict.order.number}</dt>
          <dd className="text-lg">{order.orderNumber}</dd>
        </div>
        <div>
          <dt className="text-stone-500">{dict.order.status}</dt>
          <dd>{statusLabel}</dd>
        </div>
        <div>
          <dt className="text-stone-500">{dict.order.payment}</dt>
          <dd>
            {order.paymentMethod === "cod" ? dict.checkout.cod : order.paymentMethod} · {order.paymentStatus}
          </dd>
        </div>
        <div>
          <dt className="text-stone-500">Date</dt>
          <dd>{formatDate(order.createdAt, locale)}</dd>
        </div>
      </dl>
      <h2 className="mt-10 font-serif text-2xl">{dict.order.items}</h2>
      <ul className="mt-4 space-y-3">
        {items.map((item) => (
          <li key={item.id} className="flex justify-between border-b border-[var(--mz-line)] py-3 text-sm">
            <span>
              {item.name} · {item.sku} · {item.color} · {item.size} × {item.quantity}
            </span>
            <span>{formatMoney(item.total, locale)}</span>
          </li>
        ))}
      </ul>
      <dl className="mt-6 space-y-2 text-sm">
        <div className="flex justify-between">
          <dt>{dict.cart.subtotal}</dt>
          <dd>{formatMoney(order.subtotal, locale)}</dd>
        </div>
        <div className="flex justify-between">
          <dt>{dict.cart.discount}</dt>
          <dd>-{formatMoney(order.discount, locale)}</dd>
        </div>
        <div className="flex justify-between">
          <dt>{dict.cart.shipping}</dt>
          <dd>{formatMoney(order.shippingFee, locale)}</dd>
        </div>
        <div className="flex justify-between text-lg">
          <dt>{dict.cart.total}</dt>
          <dd>{formatMoney(order.total, locale)}</dd>
        </div>
      </dl>
    </main>
  );
}
