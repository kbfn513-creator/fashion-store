import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  banners,
  categories,
  collections,
  coupons,
  pages,
  productCollections,
  productImages,
  products,
  productVariants,
  shippingZones,
  storeSettings,
  users,
  type Localized,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { defaultSettings } from "@/lib/settings";

function L(en: string, fr: string, ar: string): Localized {
  return { en, fr, ar };
}

let seeding: Promise<void> | null = null;

export async function ensureSeeded() {
  const [existing] = await db.select().from(storeSettings).limit(1);
  if (existing) return;
  if (!seeding) seeding = seedAll().finally(() => {
    seeding = null;
  });
  await seeding;
}

async function seedAll() {
  await db.insert(storeSettings).values({ id: 1, data: defaultSettings });

  const adminEmail = (process.env.ADMIN_EMAIL || "atelier@maisonzahra.ma").toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (adminPassword && adminPassword.length >= 10) {
    const passwordHash = await hashPassword(adminPassword);
    await db.insert(users).values({
      email: adminEmail,
      passwordHash,
      name: "Atelier Admin",
      role: "admin",
      status: "active",
      emailVerifiedAt: new Date(),
    });
  }

  const [women] = await db
    .insert(categories)
    .values({
      slug: "women",
      image: "/images/hero.jpg",
      name: L("Women", "Femme", "نساء"),
      description: L(
        "Tailored silhouettes, quiet luxury and atelier finishing.",
        "Silhouettes structurées, luxe silencieux et finitions d’atelier.",
        "قصات مفصّلة، فخامة هادئة وتشطيب مشغلي.",
      ),
      sortOrder: 1,
    })
    .returning();
  const [men] = await db
    .insert(categories)
    .values({
      slug: "men",
      image: "/images/products/oxford-shirt.jpg",
      name: L("Men", "Homme", "رجال"),
      description: L(
        "Refined essentials for the contemporary Moroccan wardrobe.",
        "Essentiels raffinés pour le vestiaire marocain contemporain.",
        "أساسيات راقية للخزانة المغربية المعاصرة.",
      ),
      sortOrder: 2,
    })
    .returning();
  const [kids] = await db
    .insert(categories)
    .values({
      slug: "kids",
      image: "/images/products/knit-sweater.jpg",
      name: L("Kids", "Enfant", "أطفال"),
      description: L("Soft, considered pieces for little ones.", "Pièces douces et soignées pour les enfants.", "قطع ناعمة ومدروسة للصغار."),
      sortOrder: 3,
    })
    .returning();
  const [shoes] = await db
    .insert(categories)
    .values({
      slug: "shoes",
      image: "/images/products/ankle-boots.jpg",
      name: L("Shoes", "Chaussures", "أحذية"),
      description: L("Leather crafted to be worn for years.", "Cuirs travaillés pour durer des années.", "جلود صُنعت لتُرتدى لسنوات."),
      sortOrder: 4,
    })
    .returning();
  const [accessories] = await db
    .insert(categories)
    .values({
      slug: "accessories",
      image: "/images/products/tote-bag.jpg",
      name: L("Accessories", "Accessoires", "إكسسوارات"),
      description: L("Jewellery, leather and finishing details.", "Bijoux, cuir et détails de finition.", "مجوهرات وجلد وتفاصيل إتمام."),
      sortOrder: 5,
    })
    .returning();

  const [newArrivals] = await db
    .insert(collections)
    .values({
      slug: "new-arrivals",
      image: "/images/hero.jpg",
      name: L("New arrivals", "Nouveautés", "وصل حديثاً"),
      description: L("The latest from the Casablanca atelier.", "Les dernières pièces de l’atelier de Casablanca.", "أحدث قطع مشغل الدار البيضاء."),
      sortOrder: 1,
    })
    .returning();
  const [bestsellers] = await db
    .insert(collections)
    .values({
      slug: "bestsellers",
      image: "/images/products/wool-coat.jpg",
      name: L("Bestsellers", "Best-sellers", "الأكثر مبيعاً"),
      description: L("The pieces clients return for.", "Les pièces que nos clientes redemandent.", "القطع التي يعود إليها الزبناء."),
      sortOrder: 2,
    })
    .returning();
  const [sale] = await db
    .insert(collections)
    .values({
      slug: "sale",
      image: "/images/products/linen-dress.jpg",
      name: L("Sale", "Soldes", "تخفيضات"),
      description: L("Selected atelier pieces at a quieter price.", "Pièces d’atelier à prix adouci.", "قطع مختارة بسعر أهدأ."),
      sortOrder: 3,
    })
    .returning();
  const [autumn] = await db
    .insert(collections)
    .values({
      slug: "autumn-atelier",
      image: "/images/products/knit-sweater.jpg",
      name: L("Autumn atelier", "Atelier d’automne", "مشغل الخريف"),
      description: L("Camel, ivory and charcoal for the cooler months.", "Camel, ivoire et charcoal pour la saison fraîche.", "جملي وعاجي وفحمي لأشهر البرد."),
      sortOrder: 4,
    })
    .returning();

  type SeedProduct = {
    slug: string;
    sku: string;
    brand: string;
    categoryId: string;
    collections: string[];
    name: Localized;
    description: Localized;
    materials: Localized;
    care: Localized;
    fit: Localized;
    sizeGuide: Localized;
    tags: string[];
    price: number;
    salePrice?: number;
    costPrice: number;
    featured?: boolean;
    newArrival?: boolean;
    bestSeller?: boolean;
    images: { url: string; alt: string }[];
    variants: { sku: string; size?: string; color?: string; colorHex?: string; stock: number; price?: number; salePrice?: number }[];
  };

  const catalog: SeedProduct[] = [
    {
      slug: "chemise-soie-ivoire",
      sku: "MZ-W-BL-001",
      brand: "Maison Zahra",
      categoryId: women.id,
      collections: [newArrivals.id, bestsellers.id, autumn.id],
      name: L("Ivoire silk blouse", "Chemise en soie ivoire", "بلوزة حرير عاجية"),
      description: L(
        "A fluid silk blouse with a quiet collar and mother-of-pearl buttons. Cut in the Casablanca atelier for a precise shoulder and an easy drape.",
        "Chemise de soie fluide, col discret et boutons de nacre. Coupée dans l’atelier de Casablanca pour une épaule nette et une chute souple.",
        "بلوزة حرير سائلة بياقة هادئة وأزرار صدف. قُصت في مشغل الدار البيضاء لكتف دقيق وانسدال مريح.",
      ),
      materials: L("100% silk twill", "100 % twill de soie", "تويل حرير 100٪"),
      care: L("Dry clean only. Cool iron on reverse.", "Nettoyage à sec uniquement. Fer doux sur l’envers.", "تنظيف جاف فقط. كيّ خفيف من الخلف."),
      fit: L("Relaxed through the body. Model wears size S.", "Coupe décontractée. Le mannequin porte une taille S.", "قصة مريحة. العارضة ترتدي مقاس S."),
      sizeGuide: L("XS 34 · S 36 · M 38 · L 40 · XL 42 (FR)", "XS 34 · S 36 · M 38 · L 40 · XL 42 (FR)", "XS 34 · S 36 · M 38 · L 40 · XL 42"),
      tags: ["silk", "blouse", "women", "atelier"],
      price: 189000,
      costPrice: 72000,
      featured: true,
      newArrival: true,
      bestSeller: true,
      images: [{ url: "/images/products/silk-blouse.jpg", alt: "Ivoire silk blouse" }],
      variants: [
        { sku: "MZ-W-BL-001-XS-IV", size: "XS", color: "Ivoire", colorHex: "#f4efe6", stock: 8 },
        { sku: "MZ-W-BL-001-S-IV", size: "S", color: "Ivoire", colorHex: "#f4efe6", stock: 14 },
        { sku: "MZ-W-BL-001-M-IV", size: "M", color: "Ivoire", colorHex: "#f4efe6", stock: 16 },
        { sku: "MZ-W-BL-001-L-IV", size: "L", color: "Ivoire", colorHex: "#f4efe6", stock: 9 },
        { sku: "MZ-W-BL-001-XL-IV", size: "XL", color: "Ivoire", colorHex: "#f4efe6", stock: 4 },
      ],
    },
    {
      slug: "manteau-laine-charcoal",
      sku: "MZ-W-CT-014",
      brand: "Maison Zahra",
      categoryId: women.id,
      collections: [bestsellers.id, autumn.id],
      name: L("Charcoal wool coat", "Manteau de laine charcoal", "معطف صوف فحمي"),
      description: L(
        "A structured wool overcoat with a concealed placket and a mid-calf length. Fully lined, with a belted option at the waist.",
        "Manteau de laine structuré, patte de boutonnage dissimulée, longueur mi-mollet. Entièrement doublé, ceinture optionnelle.",
        "معطف صوف مهيكل بأزرار مخفية وطول منتصف الساق. مبطّن بالكامل مع خيار حزام عند الخصر.",
      ),
      materials: L("80% wool, 20% cashmere. Viscose lining.", "80 % laine, 20 % cachemire. Doublure viscose.", "80٪ صوف، 20٪ كشمير. بطانة فيسكوز."),
      care: L("Dry clean. Store on a wide hanger.", "Nettoyage à sec. Conserver sur cintre large.", "تنظيف جاف. يُعلّق على شماعة عريضة."),
      fit: L("Tailored. We recommend your usual size.", "Coupe tailleur. Prenez votre taille habituelle.", "قصة مفصّلة. نوصي بمقاسك المعتاد."),
      sizeGuide: L("S 36 · M 38 · L 40 · XL 42", "S 36 · M 38 · L 40 · XL 42", "S 36 · M 38 · L 40 · XL 42"),
      tags: ["coat", "wool", "women", "winter"],
      price: 429000,
      costPrice: 180000,
      featured: true,
      bestSeller: true,
      images: [{ url: "/images/products/wool-coat.jpg", alt: "Charcoal wool coat" }],
      variants: [
        { sku: "MZ-W-CT-014-S-CH", size: "S", color: "Charcoal", colorHex: "#2b2b2b", stock: 6 },
        { sku: "MZ-W-CT-014-M-CH", size: "M", color: "Charcoal", colorHex: "#2b2b2b", stock: 8 },
        { sku: "MZ-W-CT-014-L-CH", size: "L", color: "Charcoal", colorHex: "#2b2b2b", stock: 5 },
        { sku: "MZ-W-CT-014-XL-CH", size: "XL", color: "Charcoal", colorHex: "#2b2b2b", stock: 3 },
      ],
    },
    {
      slug: "robe-lin-sable",
      sku: "MZ-W-DR-008",
      brand: "Maison Zahra",
      categoryId: women.id,
      collections: [newArrivals.id, sale.id],
      name: L("Sand linen midi dress", "Robe midi en lin sable", "فستان كتان رملي"),
      description: L(
        "A breathable linen midi with a modest neckline and side pockets. Designed for late summer in Marrakech and coastal evenings in Tangier.",
        "Robe midi en lin respirant, encolure modeste et poches latérales. Pensée pour la fin d’été à Marrakech et les soirs de Tanger.",
        "فستان كتان متوسط الطول بياقة محتشمة وجيوب جانبية. صُمم لصيف مراكش وأمسيات طنجة.",
      ),
      materials: L("100% European linen", "100 % lin européen", "كتان أوروبي 100٪"),
      care: L("Machine wash cold, gentle. Line dry.", "Lavage machine à froid, délicat. Séchage à l’air.", "غسيل بارد لطيف. تجفيف هوائي."),
      fit: L("Easy A-line. True to size.", "Trapèze souple. Taille normale.", "قصة A مريحة. مطابق للمقاس."),
      sizeGuide: L("XS–XL", "XS–XL", "XS–XL"),
      tags: ["dress", "linen", "women", "summer"],
      price: 159000,
      salePrice: 119000,
      costPrice: 54000,
      featured: true,
      newArrival: true,
      images: [{ url: "/images/products/linen-dress.jpg", alt: "Sand linen midi dress" }],
      variants: [
        { sku: "MZ-W-DR-008-XS-SD", size: "XS", color: "Sand", colorHex: "#d9c7a8", stock: 7, salePrice: 119000 },
        { sku: "MZ-W-DR-008-S-SD", size: "S", color: "Sand", colorHex: "#d9c7a8", stock: 11, salePrice: 119000 },
        { sku: "MZ-W-DR-008-M-SD", size: "M", color: "Sand", colorHex: "#d9c7a8", stock: 10, salePrice: 119000 },
        { sku: "MZ-W-DR-008-L-SD", size: "L", color: "Sand", colorHex: "#d9c7a8", stock: 6, salePrice: 119000 },
      ],
    },
    {
      slug: "robe-soiree-noir-or",
      sku: "MZ-W-EV-003",
      brand: "Maison Zahra",
      categoryId: women.id,
      collections: [bestsellers.id],
      name: L("Noir & or evening gown", "Robe de soirée noir et or", "فستان سهرة أسود وذهبي"),
      description: L(
        "A floor-length gown in black crepe with restrained gold embroidery at the neckline. Made for weddings, galas and the medina at night.",
        "Robe longue en crêpe noir, broderie d’or retenue à l’encolure. Pour les mariages, les galas et la médina la nuit.",
        "فستان طويل من الكريب الأسود بتطريز ذهبي هادئ عند العنق. للمناسبات والمدينة ليلاً.",
      ),
      materials: L("Crepe with silk lining", "Crêpe, doublure soie", "كريب وبطانة حرير"),
      care: L("Professional dry clean.", "Nettoyage à sec professionnel.", "تنظيف جاف متخصص."),
      fit: L("Fitted through the bodice, fluid skirt.", "Buste ajusté, jupe fluide.", "صدر ضيق وتنورة سائلة."),
      sizeGuide: L("S–XL. See size guide.", "S–XL. Voir le guide.", "S–XL. راجعي دليل المقاسات."),
      tags: ["gown", "evening", "women"],
      price: 389000,
      costPrice: 150000,
      featured: true,
      bestSeller: true,
      images: [{ url: "/images/products/evening-gown.jpg", alt: "Black evening gown" }],
      variants: [
        { sku: "MZ-W-EV-003-S-BK", size: "S", color: "Noir", colorHex: "#111111", stock: 4 },
        { sku: "MZ-W-EV-003-M-BK", size: "M", color: "Noir", colorHex: "#111111", stock: 5 },
        { sku: "MZ-W-EV-003-L-BK", size: "L", color: "Noir", colorHex: "#111111", stock: 3 },
        { sku: "MZ-W-EV-003-XL-BK", size: "XL", color: "Noir", colorHex: "#111111", stock: 2 },
      ],
    },
    {
      slug: "chemise-oxford-blanche",
      sku: "MZ-M-SH-021",
      brand: "Maison Zahra",
      categoryId: men.id,
      collections: [bestsellers.id, newArrivals.id],
      name: L("White oxford shirt", "Chemise oxford blanche", "قميص أكسفورد أبيض"),
      description: L(
        "A precise oxford in compact cotton. Mother-of-pearl buttons, a clean placket and a collar that holds without stiffness.",
        "Oxford précis en coton compact. Boutons de nacre, patte nette, col qui tient sans rigidité.",
        "قميص أكسفورد من قطن متماسك. أزرار صدف وياقة ثابتة دون تكلف.",
      ),
      materials: L("100% compact cotton", "100 % coton compact", "قطن مدمج 100٪"),
      care: L("Machine wash 30°C. Warm iron.", "Lavage 30 °C. Fer tiède.", "غسيل 30°. كيّ متوسط."),
      fit: L("Slim, not tight. Take your usual size.", "Coupe slim, non serrée.", "قصة نحيفة غير ضيقة."),
      sizeGuide: L("S 37 · M 39 · L 41 · XL 43", "S 37 · M 39 · L 41 · XL 43", "S 37 · M 39 · L 41 · XL 43"),
      tags: ["shirt", "men", "cotton"],
      price: 89000,
      costPrice: 28000,
      featured: true,
      bestSeller: true,
      newArrival: true,
      images: [{ url: "/images/products/oxford-shirt.jpg", alt: "White oxford shirt" }],
      variants: [
        { sku: "MZ-M-SH-021-S-WH", size: "S", color: "Blanc", colorHex: "#f7f7f5", stock: 12 },
        { sku: "MZ-M-SH-021-M-WH", size: "M", color: "Blanc", colorHex: "#f7f7f5", stock: 18 },
        { sku: "MZ-M-SH-021-L-WH", size: "L", color: "Blanc", colorHex: "#f7f7f5", stock: 14 },
        { sku: "MZ-M-SH-021-XL-WH", size: "XL", color: "Blanc", colorHex: "#f7f7f5", stock: 7 },
      ],
    },
    {
      slug: "pantalon-tailleur-stone",
      sku: "MZ-M-TR-009",
      brand: "Maison Zahra",
      categoryId: men.id,
      collections: [autumn.id],
      name: L("Stone tailored trousers", "Pantalon tailleur stone", "بنطلون مفصل حجري"),
      description: L(
        "Pressed wool-blend trousers with a medium rise and a clean break. Side adjusters, no belt required.",
        "Pantalon mélange laine, taille moyenne, cassure nette. Ajusteurs latéraux, sans ceinture.",
        "بنطلون من مزيج صوف بخصر متوسط وكسر نظيف. ضوابط جانبية دون حاجة لحزام.",
      ),
      materials: L("Wool blend with stretch", "Mélange laine stretch", "مزيج صوف بمرونة"),
      care: L("Dry clean. Hang after wear.", "Nettoyage à sec.", "تنظيف جاف."),
      fit: L("Tapered. True to size.", "Fuselé. Taille normale.", "قصة مدببة. مطابق للمقاس."),
      sizeGuide: L("46–54 IT", "46–54 IT", "46–54"),
      tags: ["trousers", "men", "tailoring"],
      price: 149000,
      costPrice: 52000,
      images: [{ url: "/images/products/oxford-shirt.jpg", alt: "Stone tailored trousers" }],
      variants: [
        { sku: "MZ-M-TR-009-46-ST", size: "46", color: "Stone", colorHex: "#c5b9a5", stock: 6 },
        { sku: "MZ-M-TR-009-48-ST", size: "48", color: "Stone", colorHex: "#c5b9a5", stock: 9 },
        { sku: "MZ-M-TR-009-50-ST", size: "50", color: "Stone", colorHex: "#c5b9a5", stock: 8 },
        { sku: "MZ-M-TR-009-52-ST", size: "52", color: "Stone", colorHex: "#c5b9a5", stock: 4 },
      ],
    },
    {
      slug: "pull-merinos-camel",
      sku: "MZ-U-KN-011",
      brand: "Maison Zahra",
      categoryId: men.id,
      collections: [newArrivals.id, autumn.id, bestsellers.id],
      name: L("Camel merino knit", "Pull merinos camel", "كنزة ميرينو جملية"),
      description: L(
        "Fine-gauge merino with a dry hand and a crew neck that sits cleanly under a coat. Unisex sizing.",
        "Mérinos fine jauge, main sèche, col rond qui se glisse sous un manteau. Tailles unisexes.",
        "ميرينو ناعم بملمس جاف وياقة دائرية تحت المعطف. مقاسات للجنسين.",
      ),
      materials: L("100% extrafine merino", "100 % mérinos extrafin", "ميرينو فائق النعومة 100٪"),
      care: L("Hand wash cold. Dry flat.", "Lavage main à froid. Séchage à plat.", "غسيل يدوي بارد. تجفيف مسطح."),
      fit: L("Regular. Unisex.", "Coupe droite. Unisexe.", "قصة عادية. للجنسين."),
      sizeGuide: L("S–XL", "S–XL", "S–XL"),
      tags: ["knit", "merino", "unisex"],
      price: 129000,
      costPrice: 48000,
      featured: true,
      newArrival: true,
      bestSeller: true,
      images: [{ url: "/images/products/knit-sweater.jpg", alt: "Camel merino knit" }],
      variants: [
        { sku: "MZ-U-KN-011-S-CM", size: "S", color: "Camel", colorHex: "#c4a574", stock: 10 },
        { sku: "MZ-U-KN-011-M-CM", size: "M", color: "Camel", colorHex: "#c4a574", stock: 13 },
        { sku: "MZ-U-KN-011-L-CM", size: "L", color: "Camel", colorHex: "#c4a574", stock: 9 },
        { sku: "MZ-U-KN-011-XL-CM", size: "XL", color: "Camel", colorHex: "#c4a574", stock: 2 },
      ],
    },
    {
      slug: "ensemble-coton-enfant",
      sku: "MZ-K-ST-004",
      brand: "Maison Zahra",
      categoryId: kids.id,
      collections: [newArrivals.id],
      name: L("Kids cotton set", "Ensemble coton enfant", "طقم قطن للأطفال"),
      description: L(
        "A two-piece cotton set in warm sand, with a soft waist and room to move. Designed without harsh hardware.",
        "Ensemble deux pièces en coton sable, taille douce, aisance de mouvement. Sans quincaillerie agressive.",
        "طقم قطني بلون رملي دافئ، خصر ناعم ومساحة للحركة.",
      ),
      materials: L("Organic cotton jersey", "Jersey de coton biologique", "جيرسي قطن عضوي"),
      care: L("Machine wash 30°C.", "Lavage 30 °C.", "غسيل 30°."),
      fit: L("Relaxed kids fit.", "Coupe confort enfant.", "قصة مريحة للأطفال."),
      sizeGuide: L("4Y · 6Y · 8Y · 10Y", "4A · 6A · 8A · 10A", "4 · 6 · 8 · 10 سنوات"),
      tags: ["kids", "cotton", "set"],
      price: 69000,
      costPrice: 22000,
      newArrival: true,
      images: [{ url: "/images/products/knit-sweater.jpg", alt: "Kids cotton set" }],
      variants: [
        { sku: "MZ-K-ST-004-4-SD", size: "4Y", color: "Sand", colorHex: "#d9c7a8", stock: 8 },
        { sku: "MZ-K-ST-004-6-SD", size: "6Y", color: "Sand", colorHex: "#d9c7a8", stock: 10 },
        { sku: "MZ-K-ST-004-8-SD", size: "8Y", color: "Sand", colorHex: "#d9c7a8", stock: 7 },
        { sku: "MZ-K-ST-004-10-SD", size: "10Y", color: "Sand", colorHex: "#d9c7a8", stock: 5 },
      ],
    },
    {
      slug: "bottines-cuir-cognac",
      sku: "MZ-S-BT-006",
      brand: "Maison Zahra",
      categoryId: shoes.id,
      collections: [bestsellers.id, autumn.id],
      name: L("Cognac leather ankle boots", "Bottines en cuir cognac", "بوت كاحل جلد كونياك"),
      description: L(
        "Italian leather ankle boots on a stable block heel. Lined in kidskin, with a hidden zipper.",
        "Bottines en cuir italien, talon block stable. Doublure chevreau, fermeture dissimulée.",
        "بوت كاحل من جلد إيطالي بكعب ثابت وبطانة ناعمة وسحاب مخفي.",
      ),
      materials: L("Full-grain calf leather", "Cuir de veau pleine fleur", "جلد عجل كامل الحبيبات"),
      care: L("Wipe, condition, use shoe trees.", "Essuyer, nourrir, utiliser des embauchoirs.", "امسحي ودلّكي واستخدمي قوالب الأحذية."),
      fit: L("True to size. Narrow last.", "Taille normale. Forme étroite.", "مطابق للمقاس. قالب ضيق."),
      sizeGuide: L("EU 36–41", "EU 36–41", "36–41"),
      tags: ["boots", "leather", "shoes"],
      price: 219000,
      costPrice: 90000,
      featured: true,
      bestSeller: true,
      images: [{ url: "/images/products/ankle-boots.jpg", alt: "Cognac leather ankle boots" }],
      variants: [
        { sku: "MZ-S-BT-006-36-CG", size: "36", color: "Cognac", colorHex: "#8a5a32", stock: 4 },
        { sku: "MZ-S-BT-006-37-CG", size: "37", color: "Cognac", colorHex: "#8a5a32", stock: 6 },
        { sku: "MZ-S-BT-006-38-CG", size: "38", color: "Cognac", colorHex: "#8a5a32", stock: 8 },
        { sku: "MZ-S-BT-006-39-CG", size: "39", color: "Cognac", colorHex: "#8a5a32", stock: 7 },
        { sku: "MZ-S-BT-006-40-CG", size: "40", color: "Cognac", colorHex: "#8a5a32", stock: 5 },
        { sku: "MZ-S-BT-006-41-CG", size: "41", color: "Cognac", colorHex: "#8a5a32", stock: 3 },
      ],
    },
    {
      slug: "mocassins-daim-taupe",
      sku: "MZ-S-LF-002",
      brand: "Maison Zahra",
      categoryId: shoes.id,
      collections: [newArrivals.id, sale.id],
      name: L("Taupe suede loafers", "Mocassins en daim taupe", "حذاء سويدي رمادي دافئ"),
      description: L(
        "Unlined suede loafers with a flexible leather sole. For the office in Rabat and weekends in Essaouira.",
        "Mocassins en daim non doublés, semelle cuir souple. Pour le bureau à Rabat et les week-ends à Essaouira.",
        "حذاء سويدي غير مبطّن بنعل جلد مرن. للمكتب في الرباط وعطل الصويرة.",
      ),
      materials: L("Calf suede, leather sole", "Daim de veau, semelle cuir", "سويد عجل ونعل جلد"),
      care: L("Brush suede. Protect from rain.", "Brosser le daim. Protéger de la pluie.", "فرّش السويد. احمه من المطر."),
      fit: L("Slightly generous. Consider half a size down.", "Un peu généreux.", "واسع قليلاً."),
      sizeGuide: L("EU 40–45", "EU 40–45", "40–45"),
      tags: ["loafers", "suede", "men", "shoes"],
      price: 179000,
      salePrice: 149000,
      costPrice: 70000,
      newArrival: true,
      images: [{ url: "/images/products/ankle-boots.jpg", alt: "Taupe suede loafers" }],
      variants: [
        { sku: "MZ-S-LF-002-40-TP", size: "40", color: "Taupe", colorHex: "#8b7d6b", stock: 5, salePrice: 149000 },
        { sku: "MZ-S-LF-002-41-TP", size: "41", color: "Taupe", colorHex: "#8b7d6b", stock: 7, salePrice: 149000 },
        { sku: "MZ-S-LF-002-42-TP", size: "42", color: "Taupe", colorHex: "#8b7d6b", stock: 8, salePrice: 149000 },
        { sku: "MZ-S-LF-002-43-TP", size: "43", color: "Taupe", colorHex: "#8b7d6b", stock: 6, salePrice: 149000 },
        { sku: "MZ-S-LF-002-44-TP", size: "44", color: "Taupe", colorHex: "#8b7d6b", stock: 3, salePrice: 149000 },
      ],
    },
    {
      slug: "cabas-cuir-tan",
      sku: "MZ-A-BG-010",
      brand: "Maison Zahra",
      categoryId: accessories.id,
      collections: [bestsellers.id, newArrivals.id],
      name: L("Structured tan tote", "Cabas structuré tan", "حقيبة يد جلدية"),
      description: L(
        "A structured tote in vegetable-tanned leather. Fits a 13-inch laptop, a scarf and the day.",
        "Cabas structuré en cuir tanné végétal. Contient un ordinateur 13\", un foulard et la journée.",
        "حقيبة مهيكلة من جلد مدبوغ نباتياً. تتسع لحاسوب 13 إنش ووشاح واليوم.",
      ),
      materials: L("Vegetable-tanned leather", "Cuir tanné végétal", "جلد مدبوغ نباتياً"),
      care: L("Condition leather twice a year.", "Nourrir le cuir deux fois par an.", "دلّكي الجلد مرتين في السنة."),
      fit: L("One size", "Taille unique", "مقاس واحد"),
      sizeGuide: L("36 × 28 × 14 cm", "36 × 28 × 14 cm", "36 × 28 × 14 سم"),
      tags: ["bag", "leather", "accessories"],
      price: 249000,
      costPrice: 95000,
      featured: true,
      bestSeller: true,
      newArrival: true,
      images: [{ url: "/images/products/tote-bag.jpg", alt: "Structured tan tote" }],
      variants: [
        { sku: "MZ-A-BG-010-OS-TN", size: "OS", color: "Tan", colorHex: "#b08454", stock: 11 },
        { sku: "MZ-A-BG-010-OS-BK", size: "OS", color: "Noir", colorHex: "#1a1a1a", stock: 7 },
      ],
    },
    {
      slug: "creoles-or-atelier",
      sku: "MZ-A-JW-007",
      brand: "Maison Zahra",
      categoryId: accessories.id,
      collections: [bestsellers.id],
      name: L("Atelier gold hoops", "Créoles or atelier", "حلقات ذهب المشغل"),
      description: L(
        "Medium gold-tone hoops with a hinged closure. Polished, not loud — made to be worn every day.",
        "Créoles moyennes, fermoir charnière. Polies, jamais tapageuses — à porter chaque jour.",
        "حلقات متوسطة بذهبية دافئة وإغلاق مفصلي. لامعة دون مبالغة — للارتداء اليومي.",
      ),
      materials: L("Gold-plated brass, nickel-free", "Laiton doré, sans nickel", "نحاس مطلي بالذهب، خالٍ من النيكل"),
      care: L("Avoid perfume and water. Wipe after wear.", "Éviter parfum et eau.", "تجنّبي العطر والماء."),
      fit: L("4.5 cm diameter", "Diamètre 4,5 cm", "قطر 4.5 سم"),
      sizeGuide: L("One size", "Taille unique", "مقاس واحد"),
      tags: ["jewellery", "gold", "accessories"],
      price: 59000,
      costPrice: 14000,
      featured: true,
      bestSeller: true,
      images: [{ url: "/images/products/gold-earrings.jpg", alt: "Gold hoop earrings" }],
      variants: [{ sku: "MZ-A-JW-007-OS-GD", size: "OS", color: "Or", colorHex: "#c4a574", stock: 22 }],
    },
    {
      slug: "foulard-cachemire",
      sku: "MZ-A-SC-012",
      brand: "Maison Zahra",
      categoryId: accessories.id,
      collections: [autumn.id, sale.id],
      name: L("Ivory cashmere scarf", "Foulard cachemire ivoire", "وشاح كشمير عاجي"),
      description: L(
        "A lightweight cashmere scarf with hand-finished edges. Enough warmth for the Atlas, enough lightness for the city.",
        "Foulard cachemire léger, bords finis main. Assez chaud pour l’Atlas, assez léger pour la ville.",
        "وشاح كشمير خفيف بحواف يدوية. دفء للأطلس وخفة للمدينة.",
      ),
      materials: L("100% cashmere", "100 % cachemire", "كشمير 100٪"),
      care: L("Dry clean or hand wash cold.", "Nettoyage à sec ou lavage main.", "تنظيف جاف أو غسيل يدوي."),
      fit: L("180 × 70 cm", "180 × 70 cm", "180 × 70 سم"),
      sizeGuide: L("One size", "Taille unique", "مقاس واحد"),
      tags: ["scarf", "cashmere", "accessories"],
      price: 99000,
      salePrice: 79000,
      costPrice: 36000,
      images: [{ url: "/images/products/silk-blouse.jpg", alt: "Ivory cashmere scarf" }],
      variants: [
        { sku: "MZ-A-SC-012-OS-IV", size: "OS", color: "Ivoire", colorHex: "#f4efe6", stock: 9, salePrice: 79000 },
        { sku: "MZ-A-SC-012-OS-CM", size: "OS", color: "Camel", colorHex: "#c4a574", stock: 6, salePrice: 79000 },
      ],
    },
    {
      slug: "ceinture-cuir-noire",
      sku: "MZ-A-BL-005",
      brand: "Maison Zahra",
      categoryId: accessories.id,
      collections: [bestsellers.id],
      name: L("Black leather belt", "Ceinture en cuir noire", "حزام جلد أسود"),
      description: L(
        "A 3 cm belt in glazed calf, with a brushed gold buckle. Cut to be worn with tailoring or denim.",
        "Ceinture 3 cm en veau glacé, boucle or brossé. Pour le tailleur comme le denim.",
        "حزام 3 سم من جلد العجل مع إبزيم ذهبي مطفي. للتفصيل أو الدنيم.",
      ),
      materials: L("Glazed calf leather", "Cuir de veau glacé", "جلد عجل لامع"),
      care: L("Wipe with a soft cloth.", "Essuyer avec un chiffon doux.", "امسح بقطعة قماش ناعمة."),
      fit: L("Choose your usual waist.", "Choisissez votre tour de taille.", "اختَر مقاس خصرك المعتاد."),
      sizeGuide: L("80 · 85 · 90 · 95 cm", "80 · 85 · 90 · 95 cm", "80 · 85 · 90 · 95 سم"),
      tags: ["belt", "leather", "accessories"],
      price: 69000,
      costPrice: 22000,
      bestSeller: true,
      images: [{ url: "/images/products/tote-bag.jpg", alt: "Black leather belt" }],
      variants: [
        { sku: "MZ-A-BL-005-80-BK", size: "80", color: "Noir", colorHex: "#1a1a1a", stock: 8 },
        { sku: "MZ-A-BL-005-85-BK", size: "85", color: "Noir", colorHex: "#1a1a1a", stock: 10 },
        { sku: "MZ-A-BL-005-90-BK", size: "90", color: "Noir", colorHex: "#1a1a1a", stock: 7 },
        { sku: "MZ-A-BL-005-95-BK", size: "95", color: "Noir", colorHex: "#1a1a1a", stock: 4 },
      ],
    },
  ];

  for (const item of catalog) {
    const [product] = await db
      .insert(products)
      .values({
        slug: item.slug,
        sku: item.sku,
        brand: item.brand,
        categoryId: item.categoryId,
        name: item.name,
        description: item.description,
        materials: item.materials,
        care: item.care,
        fit: item.fit,
        sizeGuide: item.sizeGuide,
        tags: item.tags,
        price: item.price,
        salePrice: item.salePrice,
        costPrice: item.costPrice,
        status: "published",
        featured: !!item.featured,
        newArrival: !!item.newArrival,
        bestSeller: !!item.bestSeller,
        publishedAt: new Date(),
        saleStartsAt: item.salePrice ? new Date(Date.now() - 86400000) : null,
        saleEndsAt: item.salePrice ? new Date(Date.now() + 86400000 * 45) : null,
      })
      .returning();

    await db.insert(productImages).values(
      item.images.map((img, i) => ({
        productId: product.id,
        url: img.url,
        alt: img.alt,
        sortOrder: i,
        isMain: i === 0,
      })),
    );
    await db.insert(productVariants).values(
      item.variants.map((v) => ({
        productId: product.id,
        sku: v.sku,
        size: v.size || null,
        color: v.color || null,
        colorHex: v.colorHex || null,
        price: v.price,
        salePrice: v.salePrice,
        stock: v.stock,
        isActive: true,
      })),
    );
    if (item.collections.length) {
      await db.insert(productCollections).values(
        item.collections.map((collectionId) => ({ productId: product.id, collectionId })),
      );
    }
  }

  await db.insert(shippingZones).values([
    {
      name: "Casablanca-Settat",
      cities: ["Casablanca", "Mohammedia", "El Jadida", "Settat", "Berrechid", "Bouskoura"],
      fee: 2500,
      estimatedDays: "1–2",
      sortOrder: 1,
    },
    {
      name: "Rabat-Salé-Kénitra",
      cities: ["Rabat", "Salé", "Témara", "Kénitra", "Skhirat"],
      fee: 3000,
      estimatedDays: "1–3",
      sortOrder: 2,
    },
    {
      name: "Marrakech-Safi",
      cities: ["Marrakech", "Safi", "Essaouira"],
      fee: 3500,
      estimatedDays: "2–4",
      sortOrder: 3,
    },
    {
      name: "Grandes villes",
      cities: ["Fès", "Tanger", "Agadir", "Meknès", "Oujda", "Tétouan", "Nador", "Ouarzazate"],
      fee: 4000,
      estimatedDays: "2–5",
      sortOrder: 4,
    },
    {
      name: "Reste du Maroc",
      cities: [],
      fee: 5500,
      estimatedDays: "3–7",
      sortOrder: 5,
    },
  ]);

  await db.insert(coupons).values([
    {
      code: "ATELIER10",
      type: "percent",
      value: 1000,
      minOrder: 50000,
      maxUses: 200,
      perCustomerLimit: 2,
      isActive: true,
      startsAt: new Date(Date.now() - 86400000),
      endsAt: new Date(Date.now() + 86400000 * 90),
    },
    {
      code: "WELCOME50",
      type: "fixed",
      value: 5000,
      minOrder: 30000,
      maxUses: 500,
      perCustomerLimit: 1,
      isActive: true,
    },
    {
      code: "LIVRAISON",
      type: "free_shipping",
      value: 0,
      minOrder: 0,
      maxUses: 300,
      perCustomerLimit: 3,
      isActive: true,
    },
  ]);

  await db.insert(banners).values([
    {
      key: "hero",
      image: "/images/hero.jpg",
      title: L("Autumn atelier", "Atelier d’automne", "مشغل الخريف"),
      subtitle: L(
        "Wool, silk and leather — cut in Casablanca, made to be kept.",
        "Laine, soie et cuir — coupés à Casablanca, conçus pour durer.",
        "صوف وحرير وجلد — تُقص في الدار البيضاء لتُحفظ.",
      ),
      ctaLabel: L("Shop the collection", "Découvrir la collection", "تسوّق المجموعة"),
      ctaHref: "/collections/autumn-atelier",
      isActive: true,
      sortOrder: 1,
    },
  ]);

  await db.insert(pages).values([
    {
      slug: "about",
      title: L("The house", "La maison", "الدار"),
      seoDescription: L("The story of Maison Zahra.", "L’histoire de Maison Zahra.", "قصة ميزون زهرة."),
      body: L(
        "Maison Zahra is a Casablanca atelier for clothing, shoes and accessories. We work in small quantities, with wool, silk, linen and vegetable-tanned leather. The house is bilingual in spirit — Arabic, French and English — and Moroccan in its sense of proportion, light and hospitality.\n\nThis catalogue contains sample pieces so you can operate the store immediately. Replace them from the admin dashboard with your own photography and stock.",
        "Maison Zahra est un atelier casablancais de prêt-à-porter, chaussures et accessoires. Nous travaillons en petites quantités, la laine, la soie, le lin et le cuir tanné végétal. La maison parle arabe, français et anglais, et reste marocaine dans sa mesure, sa lumière et son hospitalité.\n\nCe catalogue contient des pièces d’exemple pour que la boutique fonctionne immédiatement. Remplacez-les depuis le tableau de bord.",
        "ميزون زهرة مشغل في الدار البيضاء للملابس والأحذية والإكسسوارات. نعمل بكميات محدودة، بالصوف والحرير والكتان والجلد المدبوغ نباتياً.\n\nتحتوي هذه القائمة على قطع تجريبية لتشغيل المتجر فوراً. يمكن استبدالها من لوحة التحكم.",
      ),
    },
    {
      slug: "faq",
      title: L("Client questions", "Questions clientes", "أسئلة الزبناء"),
      body: L(
        "How long is delivery?\nMost cities receive orders in 1–5 working days according to the shipping zone.\n\nDo you offer cash on delivery?\nYes. COD is available across Morocco when enabled by the store owner.\n\nCan I return a piece?\nUnworn items with tags may be returned within 14 days. See the returns policy.\n\nAre prices in MAD?\nYes. Prices are in Moroccan dirhams and include VAT unless the owner configures otherwise.",
        "Délais de livraison ?\n1 à 5 jours ouvrés selon la zone.\n\nPaiement à la livraison ?\nOui, dans tout le Maroc lorsque l’option est activée.\n\nRetours ?\nArticles non portés, étiquettes intactes, sous 14 jours.\n\nPrix en MAD ?\nOui, en dirhams marocains, TTC par défaut.",
        "مدة التوصيل؟\nمن 1 إلى 5 أيام عمل حسب المنطقة.\n\nهل يتوفر الدفع عند الاستلام؟\nنعم في المغرب عندما يفعّله صاحب المتجر.\n\nهل يمكن الإرجاع؟\nالقطع غير المستخدمة خلال 14 يوماً.\n\nهل الأسعار بالدرهم؟\nنعم، وتشمل الضريبة ما لم يُضبط خلاف ذلك.",
      ),
    },
    {
      slug: "size-guide",
      title: L("Size guide", "Guide des tailles", "دليل المقاسات"),
      body: L(
        "Women ready-to-wear (FR): XS 34 · S 36 · M 38 · L 40 · XL 42.\nMen shirts: S 37 · M 39 · L 41 · XL 43.\nShoes: European sizing.\nIf you are between sizes, we recommend the larger size for coats and the smaller size for tailored trousers.\nEach product page also includes a piece-specific note.",
        "Femme (FR) : XS 34 · S 36 · M 38 · L 40 · XL 42.\nChemises homme : S 37 · M 39 · L 41 · XL 43.\nChaussures : pointure EU.\nEn cas de doute, prenez la taille au-dessus pour les manteaux.",
        "ملابس النساء (FR): XS 34 · S 36 · M 38 · L 40 · XL 42.\nقمصان الرجال: S 37 · M 39 · L 41 · XL 43.\nالأحذية بالمقاس الأوروبي.",
      ),
    },
    {
      slug: "shipping",
      title: L("Shipping policy", "Politique de livraison", "سياسة الشحن"),
      body: L(
        "We deliver throughout Morocco. Delivery fees are calculated at checkout from the store’s shipping zones. Free delivery applies above the threshold configured by the owner (800 MAD in the sample settings).\nDelivery estimates are not live carrier tracking. Once a shipment is created, the administrator may add a tracking number and carrier name.\nRemote areas may require additional time.",
        "Livraison dans tout le Maroc. Les frais sont calculés à la commande selon les zones. La livraison offerte s’applique au-delà du seuil configuré (800 MAD dans les réglages d’exemple).\nLes délais indiqués ne constituent pas un suivi transporteur en direct.",
        "نوصل في جميع أنحاء المغرب. تُحسب رسوم التوصيل عند الطلب حسب المناطق. التوصيل المجاني فوق العتبة المحددة (800 درهم في الإعدادات التجريبية).\nالتقديرات ليست تتبعاً مباشراً لشركة الشحن.",
      ),
    },
    {
      slug: "returns",
      title: L("Returns & refunds", "Retours & remboursements", "الإرجاع والاسترداد"),
      body: L(
        "You may request a return within 14 days of delivery for unworn items with original tags. Underwear and earrings cannot be returned for hygiene reasons.\nCash-on-delivery orders are refunded according to the method agreed with client care (store credit or bank transfer). Card refunds are only processed when a real payment provider is connected.\nThe store owner can restore stock automatically on eligible cancellations and refunds.",
        "Retour possible sous 14 jours pour les articles non portés avec étiquettes. Sous-vêtements et boucles d’oreilles exclus.\nLes commandes en paiement à la livraison sont remboursées selon le mode convenu avec le service client.",
        "يمكن طلب الإرجاع خلال 14 يوماً للقطع غير المستخدمة مع العلامات الأصلية. لا يُرجع الذهب المستعمل للأذن لأسباب صحية.\nطلبات الدفع عند الاستلام تُسترد بالطريقة المتفق عليها مع خدمة الزبناء.",
      ),
    },
    {
      slug: "privacy",
      title: L("Privacy policy", "Politique de confidentialité", "سياسة الخصوصية"),
      body: L(
        "Maison Zahra collects the information required to fulfil orders: name, phone, email, delivery address and order history. We do not store raw card numbers or CVV data.\nAccount passwords are hashed. Administrators can export or delete a customer profile on request.\nThis sample policy must be reviewed by the store owner and counsel before production use. It is not a substitute for legal advice under Moroccan Law 09-08 or consumer protection rules.",
        "Maison Zahra collecte les informations nécessaires à la commande. Nous ne stockons pas les numéros de carte ni les cryptogrammes. Les mots de passe sont hachés.\nCette page d’exemple doit être relue par le propriétaire et un conseil avant toute mise en production.",
        "تجمع ميزون زهرة البيانات اللازمة لتنفيذ الطلبات. لا نخزّن أرقام البطاقات أو رمز CVV. كلمات المرور مشفّرة بالتجزئة.\nيجب مراجعة هذه الصفحة التجريبية من المالك ومستشار قانوني قبل الإنتاج.",
      ),
    },
    {
      slug: "terms",
      title: L("Terms & conditions", "Conditions générales", "الشروط والأحكام"),
      body: L(
        "Orders are offers to purchase that the atelier may accept or refuse (for example if an item is out of stock). Contract formation occurs when the order is confirmed.\nPrices are in MAD. Cash on delivery remains payable on receipt. Title passes on full payment.\nThese sample terms are provided so the store can operate; they must be replaced with owner-approved legal terms before relying on them in commerce.",
        "Les commandes constituent des offres d’achat que l’atelier peut accepter ou refuser. Les prix sont en MAD. Le paiement à la livraison reste dû à réception.\nCes conditions d’exemple doivent être remplacées par des conditions validées par le propriétaire.",
        "الطلبات عروض شراء يمكن للمشغل قبولها أو رفضها. الأسعار بالدرهم. الدفع عند الاستلام مستحق عند التسليم.\nهذه شروط تجريبية يجب استبدالها بشروط يعتمدها المالك.",
      ),
    },
  ]);
}

export async function seedIfNeeded() {
  await ensureSeeded();
}
