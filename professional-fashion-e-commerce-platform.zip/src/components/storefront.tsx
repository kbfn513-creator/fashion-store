import Link from "next/link";
import { cookies } from "next/headers";
import { desc, eq } from "drizzle-orm";
import { Heart, Search, ShoppingBag, User } from "lucide-react";
import { db } from "@/db";
import { cartItems, carts, pages } from "@/db/schema";
import { getSessionUser, isStaff } from "@/lib/auth";
import { t } from "@/lib/i18n";
import { getNavData } from "@/lib/queries";
import { getSettings } from "@/lib/settings";
import type { Locale } from "@/lib/types";
import { loc } from "@/lib/utils";
import { LanguageSwitcher, MobileNav, NewsletterForm, SearchBox } from "@/components/client-ui";

export async function Header({ locale }: { locale: Locale }) {
  const settings = await getSettings();
  const dict = t(locale);
  const { categories, collections } = await getNavData();
  const user = await getSessionUser();
  const store = await cookies();
  const sessionId = store.get("mz_cart")?.value;
  let cartCount = 0;
  if (sessionId) {
    const [cart] = await db.select().from(carts).where(eq(carts.sessionId, sessionId)).limit(1);
    if (cart) {
      const items = await db.select().from(cartItems).where(eq(cartItems.cartId, cart.id));
      cartCount = items.reduce((s, i) => s + i.quantity, 0);
    }
  }

  const links = [
    { href: "/collections/new-arrivals", label: dict.nav.newArrivals },
    ...categories.slice(0, 5).map((c) => ({ href: `/category/${c.slug}`, label: loc(c.name, locale) })),
    { href: "/collections/sale", label: dict.nav.sale },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-[var(--mz-line)] bg-[var(--mz-bg)]/92 backdrop-blur">
      {settings.announcementEnabled && (
        <div className="bg-[var(--mz-ink)] px-4 py-2 text-center text-[11px] tracking-[0.16em] text-[var(--mz-bg)] uppercase">
          {loc(settings.announcement, locale)}
        </div>
      )}
      <div className="container-mz flex items-center justify-between gap-4 py-4">
        <MobileNav links={links} locale={locale} storeName={settings.storeName} />
        <Link href="/" className="font-serif text-2xl tracking-[0.12em] uppercase md:text-[1.7rem]">
          {settings.logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={settings.logoUrl} alt={settings.storeName} className="h-9" />
          ) : (
            settings.logoText
          )}
        </Link>
        <nav className="hidden items-center gap-6 text-[12px] tracking-[0.18em] uppercase lg:flex">
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="hover:text-[var(--mz-accent)]">
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <SearchBox locale={locale} placeholder={dict.search.placeholder} />
          <LanguageSwitcher locale={locale} />
          <Link href={user ? "/account" : "/login"} aria-label={dict.nav.account} className="p-1">
            <User size={18} />
          </Link>
          <Link href="/account/wishlist" aria-label={dict.nav.wishlist} className="p-1">
            <Heart size={18} />
          </Link>
          <Link href="/cart" aria-label={dict.nav.cart} className="relative p-1">
            <ShoppingBag size={18} />
            {cartCount > 0 && (
              <span className="absolute -end-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-[var(--mz-ink)] px-1 text-[10px] text-[var(--mz-bg)]">
                {cartCount}
              </span>
            )}
          </Link>
          {isStaff(user) && (
            <Link href="/admin" className="hidden text-[11px] tracking-[0.14em] uppercase md:inline">
              Admin
            </Link>
          )}
        </div>
      </div>
      <div className="container-mz hidden pb-3 text-[11px] tracking-[0.16em] text-stone-500 uppercase md:block">
        {collections.slice(0, 4).map((c) => (
          <Link key={c.id} href={`/collections/${c.slug}`} className="me-5 hover:text-[var(--mz-ink)]">
            {loc(c.name, locale)}
          </Link>
        ))}
      </div>
    </header>
  );
}

export async function Footer({ locale }: { locale: Locale }) {
  const settings = await getSettings();
  const dict = t(locale);
  const legal = await db.select().from(pages).orderBy(desc(pages.updatedAt));
  return (
    <footer className="mt-20 border-t border-[var(--mz-line)] bg-[var(--mz-paper)]">
      <div className="container-mz grid gap-10 py-14 md:grid-cols-4">
        <div>
          <p className="font-serif text-2xl tracking-[0.12em] uppercase">{settings.storeName}</p>
          <p className="mt-3 max-w-xs text-sm leading-relaxed text-stone-600">{loc(settings.footerNote, locale)}</p>
          <p className="mt-4 text-sm text-stone-600">
            {settings.address}
            <br />
            {settings.city}, {settings.country}
            <br />
            {settings.contactPhone}
            <br />
            {settings.contactEmail}
          </p>
        </div>
        <div>
          <p className="text-[11px] tracking-[0.2em] uppercase">{dict.footer.shop}</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <Link href="/shop">{dict.nav.shop}</Link>
            </li>
            <li>
              <Link href="/collections/new-arrivals">{dict.nav.newArrivals}</Link>
            </li>
            <li>
              <Link href="/collections/sale">{dict.nav.sale}</Link>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-[11px] tracking-[0.2em] uppercase">{dict.footer.help}</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <Link href="/contact">{dict.pages.contact}</Link>
            </li>
            <li>
              <Link href="/p/faq">{dict.pages.faq}</Link>
            </li>
            <li>
              <Link href="/p/size-guide">{dict.pages.sizeGuide}</Link>
            </li>
            <li>
              <Link href="/p/shipping">{dict.pages.shipping}</Link>
            </li>
            {settings.whatsapp && (
              <li>
                <a href={`https://wa.me/${settings.whatsapp.replace(/\D/g, "")}`} target="_blank" rel="noreferrer">
                  {dict.pages.whatsapp}
                </a>
              </li>
            )}
          </ul>
        </div>
        <div>
          <p className="text-[11px] tracking-[0.2em] uppercase">{dict.footer.newsletter}</p>
          <p className="mt-3 text-sm text-stone-600">{dict.footer.newsletterHint}</p>
          <NewsletterForm locale={locale} label={dict.footer.subscribe} success={dict.footer.subscribed} />
          <div className="mt-6 flex gap-4 text-sm">
            {settings.instagram && (
              <a href={settings.instagram} target="_blank" rel="noreferrer">
                Instagram
              </a>
            )}
            {settings.facebook && (
              <a href={settings.facebook} target="_blank" rel="noreferrer">
                Facebook
              </a>
            )}
            {settings.tiktok && (
              <a href={settings.tiktok} target="_blank" rel="noreferrer">
                TikTok
              </a>
            )}
          </div>
        </div>
      </div>
      <div className="container-mz flex flex-wrap items-center justify-between gap-4 border-t border-[var(--mz-line)] py-6 text-xs text-stone-500">
        <p>
          © {new Date().getFullYear()} {settings.storeName}. {dict.footer.rights}
        </p>
        <div className="flex flex-wrap gap-4">
          {legal.map((p) => (
            <Link key={p.id} href={`/p/${p.slug}`}>
              {loc(p.title, locale)}
            </Link>
          ))}
        </div>
        <p>
          {dict.footer.payment}: COD{settings.cardEnabled ? " · Card" : ""}
        </p>
      </div>
    </footer>
  );
}

export function MaintenanceGate({
  enabled,
  message,
  children,
}: {
  enabled: boolean;
  message: string;
  children: React.ReactNode;
}) {
  if (!enabled) return <>{children}</>;
  return (
    <main className="grid min-h-screen place-items-center px-6">
      <div className="max-w-lg text-center">
        <p className="font-serif text-4xl">Maison Zahra</p>
        <p className="mt-4 text-stone-600">{message}</p>
      </div>
    </main>
  );
}
