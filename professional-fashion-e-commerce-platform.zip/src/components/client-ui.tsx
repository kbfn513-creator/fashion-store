"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState, useTransition } from "react";
import { Menu, Search, X } from "lucide-react";
import {
  addToCartAction,
  applyCouponAction,
  checkoutAction,
  contactAction,
  loginAction,
  newsletterAction,
  registerAction,
  reviewAction,
  setLocaleAction,
  toggleWishlistAction,
  updateCartAction,
} from "@/app/actions";
import type { Localized } from "@/db/schema";
import type { Locale } from "@/lib/types";
import { loc } from "@/lib/utils";

export function LanguageSwitcher({ locale }: { locale: Locale }) {
  return (
    <form
      action={async (fd) => {
        await setLocaleAction(String(fd.get("locale")) as Locale);
      }}
    >
      <label className="sr-only" htmlFor="locale">
        Language
      </label>
      <select
        id="locale"
        name="locale"
        defaultValue={locale}
        onChange={(e) => e.currentTarget.form?.requestSubmit()}
        className="bg-transparent text-[11px] tracking-[0.14em] uppercase outline-none"
      >
        <option value="fr">FR</option>
        <option value="ar">AR</option>
        <option value="en">EN</option>
      </select>
    </form>
  );
}

export function MobileNav({
  links,
  locale,
  storeName,
}: {
  links: { href: string; label: string }[];
  locale: Locale;
  storeName: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="lg:hidden">
      <button type="button" aria-label="Menu" onClick={() => setOpen(true)} className="p-1">
        <Menu size={20} />
      </button>
      {open && (
        <div className="fixed inset-0 z-50 bg-[var(--mz-bg)] p-6">
          <div className="flex items-center justify-between">
            <p className="font-serif text-xl tracking-[0.12em] uppercase">{storeName}</p>
            <button type="button" onClick={() => setOpen(false)} aria-label="Close">
              <X />
            </button>
          </div>
          <nav className="mt-10 grid gap-4 text-lg">
            {links.map((l) => (
              <Link key={l.href} href={l.href} onClick={() => setOpen(false)}>
                {l.label}
              </Link>
            ))}
            <Link href="/search" onClick={() => setOpen(false)}>
              {locale === "ar" ? "بحث" : locale === "fr" ? "Recherche" : "Search"}
            </Link>
          </nav>
        </div>
      )}
    </div>
  );
}

export function SearchBox({ locale, placeholder }: { locale: Locale; placeholder: string }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [items, setItems] = useState<Array<{ slug: string; name: Localized; image: string | null }>>([]);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (q.trim().length < 2) {
      setItems([]);
      return;
    }
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
      if (res.ok) setItems(await res.json());
    }, 220);
  }, [q]);

  return (
    <>
      <button type="button" aria-label="Search" className="p-1" onClick={() => setOpen(true)}>
        <Search size={18} />
      </button>
      {open && (
        <div className="fixed inset-0 z-50 bg-black/30 p-4" onClick={() => setOpen(false)}>
          <div
            className="mx-auto mt-16 max-w-xl rounded-2xl bg-[var(--mz-paper)] p-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <form action="/search">
              <input
                autoFocus
                name="q"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={placeholder}
                className="w-full border-b border-[var(--mz-line)] bg-transparent py-3 outline-none"
              />
            </form>
            <ul className="mt-3 max-h-80 overflow-auto">
              {items.map((item) => (
                <li key={item.slug}>
                  <Link
                    href={`/products/${item.slug}`}
                    className="flex items-center gap-3 py-2"
                    onClick={() => setOpen(false)}
                  >
                    {item.image && (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={item.image} alt="" className="h-12 w-10 object-cover" />
                    )}
                    <span>{loc(item.name, locale)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </>
  );
}

export function NewsletterForm({ locale, label, success }: { locale: Locale; label: string; success: string }) {
  const [msg, setMsg] = useState("");
  return (
    <form
      className="mt-4 flex gap-2"
      action={async (fd) => {
        fd.set("locale", locale);
        const res = await newsletterAction(fd);
        setMsg(res.ok ? success : res.error || "");
      }}
    >
      <input
        type="email"
        name="email"
        required
        placeholder="email"
        className="w-full border-b border-[var(--mz-ink)] bg-transparent py-2 text-sm outline-none"
      />
      <button type="submit" className="text-[11px] tracking-[0.16em] uppercase">
        {label}
      </button>
      {msg && <p className="sr-only">{msg}</p>}
    </form>
  );
}

export function AddToCartForm({
  variants,
  labels,
}: {
  variants: Array<{
    id: string;
    size: string | null;
    color: string | null;
    colorHex: string | null;
    stock: number;
    sku: string;
  }>;
  labels: {
    size: string;
    color: string;
    add: string;
    added: string;
    selectSize: string;
    out: string;
    sku: string;
  };
}) {
  const colors = useMemo(
    () => [...new Map(variants.filter((v) => v.color).map((v) => [v.color, v])).values()],
    [variants],
  );
  const [color, setColor] = useState(colors[0]?.color || null);
  const sizes = variants.filter((v) => (color ? v.color === color : true));
  const [size, setSize] = useState(sizes[0]?.size || null);
  const [qty, setQty] = useState(1);
  const [msg, setMsg] = useState("");
  const [pending, start] = useTransition();
  const selected =
    variants.find((v) => (color ? v.color === color : true) && (size ? v.size === size : true)) || variants[0];

  if (!selected) return <p>{labels.out}</p>;

  return (
    <form
      className="mt-6 space-y-5"
      action={(fd) => {
        start(async () => {
          const res = await addToCartAction(fd);
          setMsg(res.ok ? labels.added : res.error || "");
        });
      }}
    >
      <input type="hidden" name="variantId" value={selected.id} />
      {colors.length > 1 && (
        <fieldset>
          <legend className="text-[11px] tracking-[0.18em] uppercase">
            {labels.color}: {color}
          </legend>
          <div className="mt-2 flex gap-2">
            {colors.map((c) => (
              <button
                key={c.color}
                type="button"
                onClick={() => setColor(c.color)}
                aria-label={c.color || ""}
                className={`h-8 w-8 rounded-full border ${color === c.color ? "ring-2 ring-[var(--mz-ink)]" : ""}`}
                style={{ background: c.colorHex || "#ddd" }}
              />
            ))}
          </div>
        </fieldset>
      )}
      {sizes.some((s) => s.size) && (
        <fieldset>
          <legend className="text-[11px] tracking-[0.18em] uppercase">{labels.size}</legend>
          <div className="mt-2 flex flex-wrap gap-2">
            {sizes.map((s) => (
              <button
                key={s.id}
                type="button"
                disabled={s.stock < 1}
                onClick={() => setSize(s.size)}
                className={`min-w-12 border px-3 py-2 text-sm ${size === s.size ? "bg-[var(--mz-ink)] text-[var(--mz-bg)]" : ""} ${s.stock < 1 ? "opacity-30" : ""}`}
              >
                {s.size}
              </button>
            ))}
          </div>
        </fieldset>
      )}
      <div className="flex items-center gap-3">
        <label className="sr-only" htmlFor="qty">
          Qty
        </label>
        <input
          id="qty"
          name="quantity"
          type="number"
          min={1}
          max={Math.max(1, selected.stock)}
          value={qty}
          onChange={(e) => setQty(Number(e.target.value))}
          className="w-20 border border-[var(--mz-line)] bg-transparent px-3 py-3"
        />
        <button
          type="submit"
          disabled={pending || selected.stock < 1}
          className="flex-1 bg-[var(--mz-ink)] py-3 text-[12px] tracking-[0.2em] text-[var(--mz-bg)] uppercase disabled:opacity-40"
        >
          {selected.stock < 1 ? labels.out : pending ? "…" : labels.add}
        </button>
      </div>
      <p className="text-xs text-stone-500">
        {labels.sku} {selected.sku}
      </p>
      {msg && <p className="text-sm">{msg}</p>}
    </form>
  );
}

export function WishlistButton({ productId, label }: { productId: string; label: string }) {
  return (
    <button
      type="button"
      className="text-[11px] tracking-[0.16em] uppercase"
      onClick={async () => {
        const res = await toggleWishlistAction(productId);
        if (res.error === "auth") window.location.href = "/login";
      }}
    >
      {label}
    </button>
  );
}

export function CartControls({
  itemId,
  quantity,
  stock,
}: {
  itemId: string;
  quantity: number;
  stock: number;
}) {
  const [pending, start] = useTransition();
  return (
    <form
      className="flex items-center gap-2"
      action={(fd) => {
        start(async () => {
          await updateCartAction(fd);
        });
      }}
    >
      <input type="hidden" name="itemId" value={itemId} />
      <input
        type="number"
        name="quantity"
        defaultValue={quantity}
        min={0}
        max={stock}
        className="w-16 border border-[var(--mz-line)] bg-transparent px-2 py-1"
      />
      <button type="submit" className="text-xs underline" disabled={pending}>
        OK
      </button>
    </form>
  );
}

export function CouponForm({ label, current }: { label: string; current?: string | null }) {
  return (
    <form
      action={async (fd) => {
        await applyCouponAction(fd);
      }}
      className="mt-4 flex gap-2"
    >
      <input
        name="code"
        defaultValue={current || ""}
        placeholder="ATELIER10"
        className="flex-1 border-b border-[var(--mz-ink)] bg-transparent py-2 uppercase outline-none"
      />
      <button className="text-[11px] tracking-[0.16em] uppercase">{label}</button>
    </form>
  );
}

export function CheckoutForm({
  labels,
  cities,
  defaultName,
  defaultEmail,
  defaultPhone,
  locale,
}: {
  labels: Record<string, string>;
  cities: string[];
  defaultName?: string;
  defaultEmail?: string;
  defaultPhone?: string;
  locale: Locale;
}) {
  const [error, setError] = useState("");
  const [pending, start] = useTransition();
  const key = useMemo(() => crypto.randomUUID(), []);
  return (
    <form
      className="space-y-4"
      action={(fd) => {
        start(async () => {
          const res = await checkoutAction(fd);
          if (res?.error) setError(res.error);
        });
      }}
    >
      <input type="hidden" name="idempotencyKey" value={key} />
      <input type="hidden" name="locale" value={locale} />
      <h2 className="font-serif text-2xl">{labels.contact}</h2>
      <input name="name" required defaultValue={defaultName} placeholder={labels.name} className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      <input name="email" type="email" required defaultValue={defaultEmail} placeholder={labels.email} className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      <input name="phone" required defaultValue={defaultPhone} placeholder={labels.phone} className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      <h2 className="pt-4 font-serif text-2xl">{labels.delivery}</h2>
      <input name="street" required placeholder={labels.street} className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      <div className="grid gap-3 md:grid-cols-2">
        <select name="city" required className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" defaultValue="">
          <option value="" disabled>
            {labels.city}
          </option>
          {cities.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
        <input name="region" required placeholder={labels.region} className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      </div>
      <input name="postalCode" placeholder={labels.postal} className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      <input name="country" defaultValue="Morocco" className="w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      <textarea name="note" placeholder={labels.note} className="min-h-24 w-full border border-[var(--mz-line)] bg-transparent px-3 py-3 outline-none" />
      <h2 className="pt-4 font-serif text-2xl">{labels.method}</h2>
      <label className="flex items-start gap-3 border border-[var(--mz-line)] p-4">
        <input type="radio" name="paymentMethod" value="cod" defaultChecked />
        <span>
          <strong>{labels.cod}</strong>
          <br />
          <span className="text-sm text-stone-600">{labels.codHint}</span>
        </span>
      </label>
      <p className="text-sm text-stone-500">{labels.cardUnavailable}</p>
      <p className="text-xs text-stone-500">{labels.terms}</p>
      {error && <p className="text-sm text-red-800">{error}</p>}
      <button
        disabled={pending}
        className="w-full bg-[var(--mz-ink)] py-3 text-[12px] tracking-[0.2em] text-[var(--mz-bg)] uppercase"
      >
        {pending ? labels.placing : labels.placeOrder}
      </button>
    </form>
  );
}

export function AuthForm({
  mode,
  labels,
  next,
}: {
  mode: "login" | "register";
  labels: Record<string, string>;
  next?: string;
}) {
  const [error, setError] = useState("");
  return (
    <form
      className="mx-auto mt-8 max-w-md space-y-4"
      action={async (fd) => {
        const res = mode === "login" ? await loginAction(fd) : await registerAction(fd);
        if (res?.error) setError(res.error);
      }}
    >
      {next && <input type="hidden" name="next" value={next} />}
      {mode === "register" && <input name="name" required placeholder={labels.name} className="w-full border-b border-[var(--mz-ink)] bg-transparent py-3 outline-none" />}
      <input name="email" type="email" required placeholder={labels.email} className="w-full border-b border-[var(--mz-ink)] bg-transparent py-3 outline-none" />
      {mode === "register" && <input name="phone" placeholder={labels.phone} className="w-full border-b border-[var(--mz-ink)] bg-transparent py-3 outline-none" />}
      <input name="password" type="password" required minLength={8} placeholder={labels.password} className="w-full border-b border-[var(--mz-ink)] bg-transparent py-3 outline-none" />
      {error && <p className="text-sm text-red-800">{error}</p>}
      <button className="w-full bg-[var(--mz-ink)] py-3 text-[12px] tracking-[0.2em] text-[var(--mz-bg)] uppercase">
        {mode === "login" ? labels.login : labels.register}
      </button>
    </form>
  );
}

export function ContactForm({ labels }: { labels: Record<string, string> }) {
  const [msg, setMsg] = useState("");
  return (
    <form
      className="space-y-4"
      action={async (fd) => {
        const res = await contactAction(fd);
        setMsg(res.ok ? labels.sent : res.error || "");
      }}
    >
      <input name="website" className="hidden" tabIndex={-1} autoComplete="off" />
      <input name="name" required placeholder={labels.name} className="w-full border-b bg-transparent py-2 outline-none" />
      <input name="email" type="email" required placeholder={labels.email} className="w-full border-b bg-transparent py-2 outline-none" />
      <input name="phone" placeholder={labels.phone} className="w-full border-b bg-transparent py-2 outline-none" />
      <input name="subject" required placeholder="Subject" className="w-full border-b bg-transparent py-2 outline-none" />
      <textarea name="message" required className="min-h-32 w-full border-b bg-transparent py-2 outline-none" />
      <button className="bg-[var(--mz-ink)] px-8 py-3 text-[12px] tracking-[0.2em] text-[var(--mz-bg)] uppercase">
        {labels.send}
      </button>
      {msg && <p className="text-sm">{msg}</p>}
    </form>
  );
}

export function ReviewForm({ productId, labels }: { productId: string; labels: Record<string, string> }) {
  const [msg, setMsg] = useState("");
  return (
    <form
      className="mt-6 space-y-3"
      action={async (fd) => {
        const res = await reviewAction(fd);
        setMsg(res.ok ? "OK" : res.error || "");
        if (res.error === "auth") window.location.href = "/login";
      }}
    >
      <input type="hidden" name="productId" value={productId} />
      <select name="rating" className="border bg-transparent px-2 py-2" defaultValue="5">
        {[5, 4, 3, 2, 1].map((n) => (
          <option key={n} value={n}>
            {n}
          </option>
        ))}
      </select>
      <input name="title" placeholder={labels.title} className="w-full border-b bg-transparent py-2 outline-none" />
      <textarea name="body" required minLength={8} className="min-h-24 w-full border-b bg-transparent py-2 outline-none" />
      <button className="text-[11px] tracking-[0.16em] uppercase">{labels.writeReview}</button>
      {msg && <p className="text-sm">{msg}</p>}
    </form>
  );
}

export function Gallery({ images }: { images: { url: string; alt: string }[] }) {
  const [active, setActive] = useState(0);
  const [zoom, setZoom] = useState(false);
  const current = images[active] || images[0];
  if (!current) return <div className="aspect-[3/4] bg-[var(--mz-muted)]" />;
  return (
    <div>
      <button type="button" className="relative block w-full overflow-hidden" onClick={() => setZoom(true)}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={current.url} alt={current.alt} className="aspect-[3/4] w-full object-cover" />
      </button>
      <div className="mt-3 flex gap-2 overflow-auto">
        {images.map((img, i) => (
          <button key={img.url + i} type="button" onClick={() => setActive(i)} className={`h-20 w-16 overflow-hidden ${i === active ? "ring-1 ring-[var(--mz-ink)]" : ""}`}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img.url} alt="" className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
      {zoom && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-6" onClick={() => setZoom(false)}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={current.url} alt={current.alt} className="max-h-full max-w-full object-contain" />
        </div>
      )}
    </div>
  );
}

export function FilterBar({
  action,
  sizes,
  colors,
  brands,
  labels,
}: {
  action: string;
  sizes: string[];
  colors: { color: string; hex: string }[];
  brands: string[];
  labels: Record<string, string>;
}) {
  const router = useRouter();
  return (
    <form
      className="mb-8 grid gap-3 border border-[var(--mz-line)] p-4 md:grid-cols-6"
      action={action}
      onChange={(e) => {
        const form = e.currentTarget;
        const data = new FormData(form);
        const params = new URLSearchParams();
        for (const [k, v] of data.entries()) if (String(v)) params.set(k, String(v));
        router.push(`${action}?${params.toString()}`);
      }}
    >
      <select name="sort" className="bg-transparent text-sm" defaultValue="">
        <option value="">{labels.sort}</option>
        <option value="latest">{labels.latest}</option>
        <option value="price-asc">{labels.priceAsc}</option>
        <option value="price-desc">{labels.priceDesc}</option>
        <option value="popularity">{labels.popularity}</option>
      </select>
      <select name="size" className="bg-transparent text-sm" defaultValue="">
        <option value="">{labels.size}</option>
        {sizes.map((s) => (
          <option key={s}>{s}</option>
        ))}
      </select>
      <select name="color" className="bg-transparent text-sm" defaultValue="">
        <option value="">{labels.color}</option>
        {colors.map((c) => (
          <option key={c.color}>{c.color}</option>
        ))}
      </select>
      <select name="brand" className="bg-transparent text-sm" defaultValue="">
        <option value="">{labels.brand}</option>
        {brands.map((b) => (
          <option key={b}>{b}</option>
        ))}
      </select>
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="inStock" value="1" /> {labels.inStock}
      </label>
      <div className="flex gap-2">
        <input name="minPrice" type="number" placeholder="min" className="w-full bg-transparent text-sm" />
        <input name="maxPrice" type="number" placeholder="max" className="w-full bg-transparent text-sm" />
      </div>
    </form>
  );
}

export function AdminDeleteButton({ action }: { action: () => Promise<void> }) {
  return (
    <button
      type="button"
      className="text-xs text-red-800"
      onClick={async () => {
        if (confirm("Delete?")) await action();
      }}
    >
      Delete
    </button>
  );
}

export function VariantEditor({
  initial,
}: {
  initial: Array<{ id?: string; sku: string; size?: string | null; color?: string | null; colorHex?: string | null; stock: number; price?: number | null; salePrice?: number | null }>;
}) {
  const [rows, setRows] = useState(
    initial.map((v) => ({
      id: v.id,
      sku: v.sku,
      size: v.size || "",
      color: v.color || "",
      colorHex: v.colorHex || "",
      stock: v.stock,
      price: v.price != null ? v.price / 100 : "",
      salePrice: v.salePrice != null ? v.salePrice / 100 : "",
    })),
  );
  const json = JSON.stringify(
    rows.map((r) => ({
      id: r.id,
      sku: r.sku,
      size: r.size,
      color: r.color,
      colorHex: r.colorHex,
      stock: Number(r.stock),
      price: r.price === "" ? undefined : Number(r.price),
      salePrice: r.salePrice === "" ? undefined : Number(r.salePrice),
    })),
  );
  return (
    <div className="space-y-2">
      <input type="hidden" name="variantsJson" value={json} />
      {rows.map((r, i) => (
        <div key={i} className="grid grid-cols-7 gap-2 text-sm">
          <input value={r.sku} onChange={(e) => setRows(patch(rows, i, { sku: e.target.value }))} placeholder="SKU" className="admin-input" />
          <input value={r.size} onChange={(e) => setRows(patch(rows, i, { size: e.target.value }))} placeholder="Size" className="admin-input" />
          <input value={r.color} onChange={(e) => setRows(patch(rows, i, { color: e.target.value }))} placeholder="Color" className="admin-input" />
          <input value={r.colorHex} onChange={(e) => setRows(patch(rows, i, { colorHex: e.target.value }))} placeholder="#hex" className="admin-input" />
          <input type="number" value={r.stock} onChange={(e) => setRows(patch(rows, i, { stock: Number(e.target.value) }))} className="admin-input" />
          <input value={r.price} onChange={(e) => setRows(patch(rows, i, { price: e.target.value }))} placeholder="price" className="admin-input" />
          <button type="button" onClick={() => setRows(rows.filter((_, j) => j !== i))}>
            ×
          </button>
        </div>
      ))}
      <button
        type="button"
        className="text-xs underline"
        onClick={() =>
          setRows([...rows, { id: undefined, sku: "", size: "", color: "", colorHex: "", stock: 0, price: "", salePrice: "" }])
        }
      >
        Add variant
      </button>
    </div>
  );
}

function patch<T>(rows: T[], i: number, next: Partial<T>): T[] {
  return rows.map((r, idx) => (idx === i ? { ...r, ...next } : r));
}
