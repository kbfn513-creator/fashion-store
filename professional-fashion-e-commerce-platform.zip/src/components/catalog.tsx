import Link from "next/link";
import { t } from "@/lib/i18n";
import type { Locale } from "@/lib/types";
import { discountPercent, formatMoney, loc } from "@/lib/utils";
import type { getProductCardData } from "@/lib/queries";

type Card = Awaited<ReturnType<typeof getProductCardData>>[number];

export function ProductCard({ card, locale }: { card: Card; locale: Locale }) {
  const dict = t(locale);
  const pct = discountPercent(card.minPrice, card.compareAt);
  return (
    <article className="group">
      <Link href={`/products/${card.product.slug}`} className="img-zoom block bg-[var(--mz-muted)]">
        {card.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={card.image}
            alt={loc(card.product.name, locale)}
            className="aspect-[3/4] w-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="aspect-[3/4]" />
        )}
      </Link>
      <div className="mt-3 flex items-start justify-between gap-3">
        <div>
          <Link href={`/products/${card.product.slug}`} className="text-sm">
            {loc(card.product.name, locale)}
          </Link>
          <p className="mt-1 text-sm">
            {card.compareAt && (
              <span className="me-2 text-stone-400 line-through">{formatMoney(card.compareAt, locale)}</span>
            )}
            <span>{formatMoney(card.minPrice, locale)}</span>
          </p>
        </div>
        <div className="flex gap-1">
          {card.colors.slice(0, 4).map((c) => (
            <span key={c.color} className="h-2.5 w-2.5 rounded-full border" style={{ background: c.hex }} title={c.color} />
          ))}
        </div>
      </div>
      <div className="mt-2 flex flex-wrap gap-1 text-[10px] tracking-[0.14em] uppercase text-stone-500">
        {card.product.newArrival && <span>{dict.product.new}</span>}
        {card.product.bestSeller && <span>{dict.product.bestseller}</span>}
        {pct && <span className="text-[var(--mz-accent)]">-{pct}%</span>}
        {card.sizes.length > 0 && <span>{card.sizes.join(" · ")}</span>}
        {card.ratingCount > 0 && <span>★ {card.ratingAvg.toFixed(1)}</span>}
      </div>
    </article>
  );
}

export function ProductGrid({
  items,
  locale,
  empty,
}: {
  items: Card[];
  locale: Locale;
  empty: string;
}) {
  if (!items.length) {
    return <p className="py-20 text-center text-stone-500">{empty}</p>;
  }
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4">
      {items.map((card) => (
        <ProductCard key={card.product.id} card={card} locale={locale} />
      ))}
    </div>
  );
}

export function Pagination({
  page,
  pageSize,
  total,
  href,
}: {
  page: number;
  pageSize: number;
  total: number;
  href: string;
}) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  if (pages <= 1) return null;
  const base = href.includes("?") ? `${href}&` : `${href}?`;
  return (
    <nav className="mt-12 flex justify-center gap-3 text-sm">
      {page > 1 && <Link href={`${base}page=${page - 1}`}>←</Link>}
      <span>
        {page} / {pages}
      </span>
      {page < pages && <Link href={`${base}page=${page + 1}`}>→</Link>}
    </nav>
  );
}

export function Stars({ value }: { value: number }) {
  return (
    <span aria-label={`${value} / 5`} className="text-[var(--mz-accent)]">
      {"★★★★★".slice(0, Math.round(value))}
      <span className="text-stone-300">{"★★★★★".slice(Math.round(value))}</span>
    </span>
  );
}
